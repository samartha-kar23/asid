#!/bin/bash
pushd
cd ~/workspace/asid/asid_backend/ci
fly set-pipeline -t asid --pipeline asid -c ci.yml -l credentials.yml
popd

