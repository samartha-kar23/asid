#!/bin/sh
echo Running MySQL base setup
pushd "$PWD"
cd $PROJECT_HOME/scripts
mysql -u asiduser -p$PROJECT_PASSWD < resources/init.sql
popd
