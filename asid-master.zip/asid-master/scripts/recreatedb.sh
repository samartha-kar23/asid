#!/bin/sh
echo Creating MySQL database annew
pushd "$PWD"
cd $PROJECT_HOME/scripts
mysql -u asiduser -p$PROJECT_PASSWD asidmock < resources/purge.sql
popd
