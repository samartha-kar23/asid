#!/bin/sh
echo Running ASID setup
cd ~
PROJECT_HOME="$PWD/workspace/asid"
# include parse_yaml function
cd "$PROJECT_HOME"
cd scripts
# reading credentials into variables
echo "
export PATH="$PATH:$PROJECT_HOME/scripts"
export PROJECT_HOME=$PROJECT_HOME
export SPRING_PROFILES_ACTIVE=local

">~/asidsettings.tmp
ruby export_credentials.rb

git config core.hooksPath scripts/hooks
