#!/bin/sh
cf set-env $1 JAVA_OPTS -XX:ReservedCodeCacheSize=140M\ -Xss256k
cf restage $1
