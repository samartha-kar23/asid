# Scripts

# General
Many of the scripts need to have some environment settings set up. Setting up those vaiables can be done by edding them to the echo section of the setup script.
To than be having the values the setupscript setup.sh has to be executed on any new terminal session. To make that happen:
* be sure to check out the project into ~/workspace
(so that the link to the scripts will always be ~/workspace/asid/scripts)
* be sure to have a READABLE newest copy of the credentials.yml where it belongs (~/workspace/asid/asid_backend)
* (if not done already): add the magic lines to your ~/.bash_profile:
```
~/workspace/asid/scripts/setup.sh
source ~/asidsettings.tmp
rm ~/asidsettings.tmp
```
After that, any new terminal can
* run the new scripts from any folder
* access environment settings you defined in the setup script
* read settings from out of the credentials


# Database related stuff
## MySQL setup
To enable local development on mac machines we introduce a mock database. So a running MySQL instance is required (to avoid all the hassle with not working named queries on an H2 database).

To setup mysql:

- if already installed and you do not know the passwd:
  -stop the mysqld deamon:
  ```sudo /usr/local/mysql/support-files/mysql.server stop```
  - restart it again with no security:
  ```sudo /usr/local/mysql/support-files/mysql.server start --skip-grant-tables```
  - Add the required asiduser to the users table:
  ```GRANT ALL PRIVILEGES ON *.* TO 'asiduser'@'localhost' IDENTIFIED BY 'addtheprojecthere,cause it's mostly known!';```
  - now you can log in mysql -u asiduser -p
  - if you happen do get the "command not found" response: add mysql to the path-variable by (for example):
      sudo vi /etc/paths
      add: /usr/local/mysql/bin
- if not installed: do a fresh install and add the user.

## ASID MockDatabase initialization
This script will create all tables needed for the image upload
and fill them with data:
- run initializeMySQL.sh

## ASID MockDatabase teardown
This script will drop the asidmock database:
- run recreatedb.sh

## ASID MockDatabase access
This script will log you into the mysql console of the asidmock database:
- run dbconsole.sh
