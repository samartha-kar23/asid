create database if not exists asidmock character set = utf8;
use asidmock;

CREATE TABLE IF NOT EXISTS slp_dokument
  (
     dokument_id INT,
     marke CHAR(1),
     xml VARCHAR(6000),
     lastmodified TIMESTAMP,
     size INT,
     name VARCHAR(255),
     dokument_type VARCHAR(255),
     isdeleted TINYINT,
     import_id INT,
     druck_num VARCHAR(255),
     dok_id VARCHAR(255),
     spk TINYTEXT,
     nr INT,
     slp_typ CHAR(1)
  );

CREATE TABLE IF NOT EXISTS file_content
(
   file_id VARCHAR(255),
   file_data LONGBLOB,
   file_type VARCHAR(255),
   info_media_type VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS slp_dokument_seite_image
(
   dokument_id INT,
   seite INT,
   image_id VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS slp_image_binary
(
   lastmodified TIMESTAMP,
   size INT,
   import_id INT,
   isdeleted TINYINT,
   modified TINYINT,
   firstimporttime DATETIME,
   image_id VARCHAR(255),
   image BLOB,
   document_type VARCHAR(255),
   marke CHAR(1),
   spk TINYTEXT
);

CREATE TABLE IF NOT EXISTS wi_dokument
(
   dokument_id INT,
   redsysmarke CHAR(1),
   xml VARCHAR(255),
   lastmodified TIMESTAMP,
   size INT,
   l3_dok_id TINYTEXT,
   l3_id TINYTEXT,
   name VARCHAR(255),
   dokument_type TINYTEXT,
   isdeleted TINYINT,
   org_import_id INT,
   redsystyp INT,
   import_id INT,
   druck_num TINYTEXT,
   wrkshopm_id TINYTEXT,
   baugruppen_id TINYTEXT,
   spk TINYTEXT,
   ext_id VARCHAR(200)
);
CREATE TABLE IF NOT EXISTS wi_dokument_image
(
   dokument_id INT,
   image_id VARCHAR(255),
   document_type VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS wi_image_binary
(
   lastmodified TIMESTAMP,
   size INT,
   import_id INT,
   isdeleted TINYINT,
   modified TINYINT,
   firstimporttime DATETIME,
   image_id TINYTEXT,
   image BLOB,
   document_type TINYTEXT
);
