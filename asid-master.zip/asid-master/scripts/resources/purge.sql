drop database asidmock;
