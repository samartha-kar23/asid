require 'yaml'

class ExportCredentials
  thing = YAML.load_file('../asid_backend/ci/credentials.yml')
  # puts thing.inspect
  thing.each do |k,v| key = k,value = v

    File.open(ENV['HOME']+"/asidsettings.tmp", 'a') { |file| file.write("export " + k.gsub("-","_") + "="+ v + "\n") }
  end
  puts "Export Ruby done"
end