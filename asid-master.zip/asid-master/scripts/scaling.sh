#!/bin/sh
yes | cf scale $1 -k $2 -m $3
