#!/bin/sh
mysql -u asiduser -p$PROJECT_PASSWD asidmock
