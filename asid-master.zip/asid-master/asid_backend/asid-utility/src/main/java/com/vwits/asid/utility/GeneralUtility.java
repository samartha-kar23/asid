package com.vwits.asid.utility;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;

import java.util.Base64;
import java.util.List;

public class GeneralUtility {
    public static final String INVALID_SALES_TYPE = "000";
    private GeneralUtility() {
    }

    public static String modifyLanguageToISO(String language, String country) {
        if (StringUtils.isEmpty(language)) {
            if (StringUtils.isEmpty(country))
                return "";
            return country;
        }
        if (!StringUtils.isEmpty(country) && !language.contains("-") && language.length() == 2) {
            return language + "-" + country;
        }
        return language;
    }

    public static String trimStringTo3Chars(String stringToBeTrimmed) {
        if (stringToBeTrimmed.length() > 3) {
            stringToBeTrimmed = stringToBeTrimmed.substring(0, 3);
        }
        return stringToBeTrimmed;
    }

    public static String computeTypeFolder(String fileType) {
        String other = "other";
        String png = "png";
        String svg = "svg";

        if (fileType == null) return other;
        fileType = fileType.toLowerCase();

        if (fileType.contains(png)) {
            return png;
        }
        if (fileType.contains(svg)) {
            return svg;
        }
        return other;

    }

    public static boolean isEmpty(List anyList) {
        return null == anyList || anyList.isEmpty();
    }

    public static boolean isEmpty(Object[] anyArray) {
        return null == anyArray || anyArray.length == 0;
    }

    public static HttpEntity<String> getHttpEntityWithHeaderToken(String authToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "bearer " + authToken);
        return new HttpEntity<>(headers);
    }

    public static String convertStringToBase64(final String content) {
        return Base64.getEncoder().encodeToString(content.getBytes());
    }

    public static String decodeBase64ToString(final String encodedString) {
        if (encodedString == null || encodedString.isEmpty()) {
            throw new IllegalArgumentException("Empty base64 string");
        }
        return new String(Base64.getDecoder().decode(encodedString));
    }

    public static String extractSalesTypeFromVIN(final String vin) {
        final int beginIndex = 6;
        final int endIndex = 9;
        if (vin.length() < endIndex) {
            return INVALID_SALES_TYPE;
        }
        return vin.substring(beginIndex, endIndex);
    }
}
