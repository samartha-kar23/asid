package com.vwits.idkit.asid.utility.config.proxy;

import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.protocol.HttpContext;
import org.springframework.context.annotation.Configuration;

import javax.validation.constraints.NotNull;
import java.net.URI;
import java.util.Arrays;
import java.util.List;

@Configuration
public class ProxyConfiguration {


    public static CredentialsProvider proxyCredentialsProvider(URI proxyUri) {

        CredentialsProvider proxyCredentials = new BasicCredentialsProvider();
        String[] userInfo = proxyUri.getUserInfo().split(":");
        proxyCredentials.setCredentials(
                proxyAuthScope(proxyUri), new UsernamePasswordCredentials(userInfo[0], userInfo[1]));
        return proxyCredentials;
    }

    @NotNull
    private static AuthScope proxyAuthScope(URI proxyUri) {
        return new AuthScope(proxyUri.getHost(), proxyUri.getPort());
    }

    public static class VWSProxyRoutePlanner extends DefaultProxyRoutePlanner {

        private List<String> noProxyUrls;

        public VWSProxyRoutePlanner(HttpHost proxy, String noProxyUrls) {
            super(proxy);
            this.noProxyUrls = Arrays.asList(noProxyUrls.split(","));
        }

        @Override
        protected HttpHost determineProxy(HttpHost target, HttpRequest request, HttpContext context)
                throws HttpException {
            String hostname = target.getHostName();
            if (noProxyUrls.stream().anyMatch(hostname::endsWith)) {
                return null;
            }
            return super.determineProxy(target, request, context);
        }
    }

}