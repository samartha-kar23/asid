package com.vwits.asid.utility.constants;

import java.util.Arrays;
import java.util.List;

public final class ASIDAppConstants {

    private ASIDAppConstants() {

    }

    public static final String APOS_API_PATH = "/aposinfo";

    public static final String REPAIR_INFO_PATH = "/rlinfo";


    public static final String REVERSE_MAPPING_APOS_ID_PATH = "/aposid";

    public static final String TOOLTIP = "Links in ETKA are currently not supported";

    public static final String DEALER_ID_PARAMETER_NAME = "dealerid";

    public static final String RL_INFO = "rlinfo";

    public static final String LT_INFO = "aposinfo";

    public static final String REVERSE_MAPPING_SERVICE_EBOID_PATH = "/eboid";
    public static final String REVERSE_MAPPING_SERVICE_RLID_PATH = "/rlid";
    public static final String REVERSE_MAPPING_SERVICE_SLPID_PATH = "/slpid";
    public static final String REVERSE_MAPPING_SERVICE_APOSID_PATH = "/aposid";

    public static final String MAPPING_SERVICE_URL = "mapping-service-url";

    public static final int REPAIR_MANUAL_TIMEOUT = 8;

    // Default fallback languages should be kept at the beginning.
    public static final List<String> ALL_SUPPORTED_LANGUAGES_BY_E2GO = Arrays.asList("de-DE", "en-GB", "cs-CZ", "da-DK", "el-GR", "en-US", "es-ES", "fi-FI", "fr-CA",
            "fr-FR", "hi-IN", "hr-HR", "hu-HU", "it-IT", "ja-JP", "ko-KR", "nl-NL", "pl-PL", "pt-BR", "pt-PT", "ro-RO", "ru-RU", "sk-SK", "sl-SI", "sv-SE", "th-TH", "tr-TR", "zh-CN", "zh-TW");

}

