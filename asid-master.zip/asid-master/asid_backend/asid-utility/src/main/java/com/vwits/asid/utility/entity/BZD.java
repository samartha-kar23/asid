package com.vwits.asid.utility.entity;

import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Wither;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Wither
public class BZD {

    @ApiParam(value = "Language, e.g. de", example = "de")
    @NotNull @NotBlank
    String lang;

    @ApiParam(value = "Country, e.g. DE", example = "DE")
    @NotNull @NotBlank
    String country;

    @ApiParam(value = "MKB, e.g. CZPB", example = "CZPB")
    @NotNull @NotBlank
    String mkb;

    @ApiParam(value = "GKB, e.g. SBK", example = "SBK")
    @NotNull @NotBlank
    String gkb;

    @ApiParam(value = "Model Year, e.g. 2018", example = "2018")
    @NotNull
    int modelyear;

    @ApiParam(value = "PR Number, e.g. 0B5,0FA", example = " ")
    @NotNull
    List<String> prnumber;

    @ApiParam(value = "Brand, e.g. V", example = "V")
    @NotNull @NotBlank
    String brand;

    @ApiParam(value = "VT, e.g. 3H73HZ", example = "3H73HZ")
    @NotNull @NotBlank
    String vt;

}
