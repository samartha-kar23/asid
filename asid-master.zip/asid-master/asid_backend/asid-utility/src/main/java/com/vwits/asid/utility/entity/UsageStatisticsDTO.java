package com.vwits.asid.utility.entity;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
@EqualsAndHashCode
public class UsageStatisticsDTO {


    @JsonSerialize(using = CustomLocalDateTimeSerializer.class)
    private LocalDateTime timeStamp;

    private String endPoint;

    private String asid;

    private String dealerId;

    private String brand;

    private String language;

    private String appName;

    private Integer responseCode;

    private long responseTime;
}
