package com.vwits.asid.utility.entity;

import java.util.HashMap;
import java.util.Map;

public enum Scope {

    DIRECT(1), INDIRECT(2), ALL(0);

    private int scopeValue;

    private static Map<Integer, Scope> scopesMap;

    Scope(int scope) {
        this.scopeValue = scope;
    }

    static {
        scopesMap = new HashMap<>(Scope.values().length);
        for (Scope scope : Scope.values()) {
            scopesMap.put(scope.getValue(), scope);
        }
    }

    public int getValue() {
        return scopeValue;
    }

    public static Scope getByValue(int value) {
        return scopesMap.get(value);
    }

    @Override
    public String toString() {
        return String.valueOf(this.getValue());
    }
}
