package com.vwits.asid.utility.environment;

public interface EnvironmentProvider {

    String getStageName();

    String getApplicationURI();
}
