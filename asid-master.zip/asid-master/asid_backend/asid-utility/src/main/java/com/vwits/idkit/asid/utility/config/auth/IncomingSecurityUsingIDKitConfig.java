package com.vwits.idkit.asid.utility.config.auth;

import com.vwits.idkit.asid.utility.config.newrelic.NewRelicBypassAdapter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import vwg.digitallab.identitykit.clients.oauth2incoming.config.PlatformSecurityConfig;
import vwg.digitallab.identitykit.clients.oauth2incoming.config.PlatformSecurityConfigurer;

/**
 *To use this configuration simply annotate your SpringBootApplication's main class with
 *
 * @Import(IncomingSecurityUsingIDKitConfig.class)
 * Make sure you have whitelist clients in your environment
 */

@Configuration
@Import(NewRelicBypassAdapter.class)
public class IncomingSecurityUsingIDKitConfig {
    @Value("${identitykit.whitelisted-client:none}")
    private String[] whitelistedClient;

    @Bean
    @Primary
    public PlatformSecurityConfig platformSecurityConfig() {
        PlatformSecurityConfigurer platformSecurityConfigurer = PlatformSecurityConfigurer
                .newBuilder()
                .enableOAuth2()
                .enableCsrf()
                .disableExternalAuthorization();
        for (String client : whitelistedClient) {
            platformSecurityConfigurer.addWhitelistedClient(client);
        }
        return platformSecurityConfigurer.build();
    }
}
