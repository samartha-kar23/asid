package com.vwits.asid.utility.environment;

import net.minidev.json.parser.JSONParser;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("cloud")
@Component
public class CloudEnvironmentProvider implements EnvironmentProvider {

    private String stageName;

    private String appUri;

    public CloudEnvironmentProvider() {
        JSONObject vcap = this.parseVcap();
        if (vcap != null) {
            final JSONArray applicationUris = (JSONArray) vcap.get("application_uris");
            this.appUri = (String) applicationUris.get(0);
            this.stageName = (String) vcap.get("space_name");
        }
    }

    @Override
    public String getStageName() {
        return stageName;
    }

    @Override
    public String getApplicationURI() {
        return appUri;
    }

    private JSONObject parseVcap() {
        String vcap = System.getenv("VCAP_APPLICATION");
        if (vcap == null) {
            return null;
        }
        JSONParser parser = new JSONParser(JSONParser.MODE_JSON_SIMPLE);
        JSONObject jsonObject;
        try {
            Object obj = parser.parse(vcap);
            jsonObject = (JSONObject) obj;
        } catch (Exception e) {
            return null;
        }
        return jsonObject;
    }
}
