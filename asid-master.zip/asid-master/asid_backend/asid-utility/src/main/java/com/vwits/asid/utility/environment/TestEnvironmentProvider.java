package com.vwits.asid.utility.environment;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile({"test","local"})
public class TestEnvironmentProvider implements EnvironmentProvider {

    public static final String NON_PRODUCTION_STAGE = "development";

    private String environment=NON_PRODUCTION_STAGE;

    private static final String APP_URI = "my-uri-space.apps.emea.vwapps.io";

    @Override
    public String getStageName() {
        return environment;
    }

    @Override
    public String getApplicationURI() {
        return APP_URI;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }
}
