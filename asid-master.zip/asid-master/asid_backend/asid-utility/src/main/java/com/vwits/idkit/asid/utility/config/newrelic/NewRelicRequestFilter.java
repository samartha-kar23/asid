package com.vwits.idkit.asid.utility.config.newrelic;

import org.springframework.http.HttpHeaders;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


public class NewRelicRequestFilter extends OncePerRequestFilter {

    public static final String NEW_RELIC_AGENT_FILTER= "com.newrelic.agent.IGNORE";

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        String appName = httpServletRequest.getParameter("appname");
        String agent = httpServletRequest.getHeader(HttpHeaders.USER_AGENT);
        if ((agent != null && agent.contains("PostmanRuntime")) || appName == null ||
                appName.equalsIgnoreCase("") ||
                appName.equalsIgnoreCase("ASIDTESTS") ||
                appName.equalsIgnoreCase("devs") ||
                appName.equalsIgnoreCase("dev") ||
                appName.equalsIgnoreCase("devtest") ||
                appName.equalsIgnoreCase("e2e")) {
            httpServletRequest.setAttribute(NEW_RELIC_AGENT_FILTER, true);
        }
        filterChain.doFilter(httpServletRequest, httpServletResponse);
    }

}
