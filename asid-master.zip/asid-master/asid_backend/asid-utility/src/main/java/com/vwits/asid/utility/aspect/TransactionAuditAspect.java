package com.vwits.asid.utility.aspect;

import com.vwits.asid.utility.entity.BZD;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import com.vwits.asid.utility.environment.EnvironmentProvider;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.CodeSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@Profile("cloud")
@Aspect
@Configuration
@Slf4j
public class TransactionAuditAspect {

    private static int numberOfThreads = 3;
    private String serviceEndPoint;
    private RestTemplate restTemplate;
    private Executor executor = Executors.newFixedThreadPool(numberOfThreads);

    private Environment environment;

    @Autowired
    public TransactionAuditAspect(final EnvironmentProvider environmentProvider, final RestTemplate restTemplate, final Environment environment) {
        this.serviceEndPoint = environmentProvider.getApplicationURI();
        final String[] hostSplits = this.serviceEndPoint.split("\\.");
        if (hostSplits.length > 1) {
            this.serviceEndPoint = hostSplits[0];
        }
        this.restTemplate = restTemplate;
        this.environment = environment;
    }

    @Around("execution(public org.springframework.http.ResponseEntity com.vwits.asid.*.*Repair*Controller.*(..)) || execution(public org.springframework.http.ResponseEntity com.vwits.asid.*.*Labor*Controller.*(..)) " +
            "|| execution(public org.springframework.http.ResponseEntity com.vwits.asid.*.*Part*Controller.*(..))")
    public ResponseEntity around(ProceedingJoinPoint joinPoint) throws Throwable {
        final long startTime = System.currentTimeMillis();
        final ResponseEntity result = (ResponseEntity) joinPoint.proceed();
        final long responseTime = System.currentTimeMillis() - startTime;
        // asynchronously processed the request
        executor.execute(() -> {
            final UsageStatisticsDTO usageStatisticsDTO = buildUsageStatisticsDTO(joinPoint, result.getStatusCode(), responseTime);
            sendAuditData(usageStatisticsDTO);
        });
        return result;
    }

    private UsageStatisticsDTO buildUsageStatisticsDTO(final JoinPoint joinPoint, final HttpStatus httpStatus, final long responseTime) {
        final String[] parameterNames = ((CodeSignature) joinPoint.getSignature()).getParameterNames();

        final Object[] args = joinPoint.getArgs();

        final UsageStatisticsDTO.UsageStatisticsDTOBuilder auditDTOBuilder = UsageStatisticsDTO.builder();

        for (int index = 0; index < parameterNames.length; index++) {
            Object parameterValue = args[index];
            String parameterName = parameterNames[index];
            switch (parameterName) {
                case "asid":
                    auditDTOBuilder.asid((String) parameterValue);
                    break;
                case "dealerId":
                    auditDTOBuilder.dealerId((String) parameterValue);
                    break;
                case "brand":
                    auditDTOBuilder.brand((String) parameterValue);
                    break;
                case "language":
                    auditDTOBuilder.language((String) parameterValue);
                    break;
                case "bzd":
                    final BZD bzd = (BZD) parameterValue;
                    auditDTOBuilder.language(bzd.getLang());
                    auditDTOBuilder.brand(bzd.getBrand());
                    break;
                case "appName":
                    auditDTOBuilder.appName((String) parameterValue);
                    break;
                default:
                    break;
            }
        }

        auditDTOBuilder.endPoint(this.serviceEndPoint);
        auditDTOBuilder.responseCode(httpStatus.value());

        auditDTOBuilder.timeStamp(LocalDateTime.now());
        auditDTOBuilder.responseTime(responseTime);

        return auditDTOBuilder.build();
    }

    private void sendAuditData(final UsageStatisticsDTO usageStatisticsDTO) {
        final String monitoringServiceBaseUrl = environment.getProperty("monitoring.service.url");

        final String monitoringServiceUrl = monitoringServiceBaseUrl.concat("/api/statistics");
        try {
            restTemplate.postForEntity(monitoringServiceUrl, buildMonitoringServiceRequest(usageStatisticsDTO), Boolean.class);
        } catch (Exception e) {
            log.error("Error occurred while calling monitoring service:", e);
        }
    }

    private HttpEntity<UsageStatisticsDTO> buildMonitoringServiceRequest(final UsageStatisticsDTO auditDTO) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_JSON);
        return new HttpEntity<>(auditDTO, headers);
    }
}
