package com.vwits.idkit.asid.utility.config.auth;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@Slf4j
public class DealerBlacklistService {

    private final RestTemplate restTemplate;

    private String dealerIdBlacklistServiceURL;

    public DealerBlacklistService(String dealerIdBlacklistServiceURL, RestTemplate restTemplate) {
        this.dealerIdBlacklistServiceURL = dealerIdBlacklistServiceURL;
        this.restTemplate = restTemplate;
    }

    public boolean isDealerBlacklisted(String dealerId, String infoMediaType) {
        final String authUrl = dealerIdBlacklistServiceURL + "/validatedealer?dealerid=" + dealerId + "&infomediatype=" + infoMediaType;
        final HttpHeaders headers = new HttpHeaders();
        final HttpEntity<Object> requestEntity = new HttpEntity<>(headers);
        final ResponseEntity<Boolean> exchange;
        try {
            exchange = restTemplate.exchange(authUrl, HttpMethod.GET, requestEntity, Boolean.class);
        } catch (Exception e) {
            log.error("Error while calling auth service url:{} ", authUrl, e);
            return true;
        }
        return exchange.getBody();
    }
}
