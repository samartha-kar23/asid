package com.vwits.asid.utility.mapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.utility.entity.Scope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static com.vwits.asid.utility.constants.ASIDAppConstants.*;

@Service
public class ReverseMappingServiceProvider {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private Environment env;

    public List<String> getLaborTimeIds(String asid) throws IOException {
        return getReverseMapping(asid, REVERSE_MAPPING_SERVICE_APOSID_PATH);
    }

    public List<String> getEboIds(String asid) throws IOException {
        return getReverseMapping(asid, REVERSE_MAPPING_SERVICE_EBOID_PATH);
    }

    public List<String> getRlIds(final String asid, final Scope scope) throws IOException {
        return getReverseMappingForRLs(asid, scope);
    }

    public List<String> getSlpIds(String asid) throws IOException {
        return getReverseMapping(asid, REVERSE_MAPPING_SERVICE_SLPID_PATH);
    }

    private List<String> getReverseMapping(String asid, String reverseMappingURL) throws IOException {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(env.getProperty(MAPPING_SERVICE_URL) + reverseMappingURL)
                .queryParam("asid", asid);

        return callReverseMapping(builder.build().toUri());
    }

    private List<String> getReverseMappingForRLs(final String asid, final Scope scope) throws IOException {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(env.getProperty(MAPPING_SERVICE_URL) + REVERSE_MAPPING_SERVICE_RLID_PATH)
                .queryParam("asid", asid)
                .queryParam("scope", scope.getValue());

        return callReverseMapping(builder.build().toUri());
    }

    private List<String> callReverseMapping(final URI uri) throws IOException {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<String> forEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
        if (forEntity.getStatusCode() == HttpStatus.NO_CONTENT)
            return new ArrayList<>();
        return new ObjectMapper().readValue(forEntity.getBody(), List.class);
    }
}
