package com.vwits.idkit.asid.utility.config.proxy;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.net.Authenticator;
import java.net.URI;

@Profile({"cloud & !NoAuth"})
@Configuration
public class ProxyRestTemplate {


    @Bean
    public RestTemplate restTemplate(@Value("${vcap.services.asid_proxy.credentials.uri}") String proxyUrl, @Value("${vcap.services.asid_proxy.credentials.user}") String proxyUser,
                                     @Value("${vcap.services.asid_proxy.credentials.password}") String proxyPassword, @Value("${vcap.services.asid_proxy.credentials.no_proxy}") String noProxyUrls) {

        Authenticator.setDefault(new ProxyAuthenticator(proxyUser, proxyPassword));
        URI proxyUri = URI.create(proxyUrl);

        HttpHost proxy = new HttpHost(proxyUri.getHost(), proxyUri.getPort());
        HttpClient httpClient =
                HttpClientBuilder.create()
                        .setProxy(proxy)
                        .setRoutePlanner(new ProxyConfiguration.VWSProxyRoutePlanner(proxy, noProxyUrls))
                        .setDefaultCredentialsProvider(ProxyConfiguration.proxyCredentialsProvider(proxyUri))
                        .build();

        RestTemplate template = new RestTemplate();
        template.setRequestFactory(new HttpComponentsClientHttpRequestFactory(httpClient));
        return template;

    }

}


