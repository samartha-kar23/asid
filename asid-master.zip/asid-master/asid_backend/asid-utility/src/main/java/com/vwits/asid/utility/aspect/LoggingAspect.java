package com.vwits.asid.utility.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.CodeSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

@Aspect
@Configuration
public class LoggingAspect {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Before("within((com.vwits.asid.*.*) && !(com.vwits.asid.*.*Test)) && args(yourString,..)")
    public void before(JoinPoint joinPoint, String yourString) {
        logger.info("INSIDE >> {}", joinPoint.getSignature());

    }

    @Before("within((com.vwits.asid.*.*) && !(com.vwits.asid.*.*Test))")
    public void debugBeforeAllMethods(JoinPoint joinPoint) {

        String[] parameterNames = ((CodeSignature) joinPoint.getSignature()).getParameterNames();
        int vinIndex = getVinIndex(parameterNames);
        int tokenIndex = getTokenIndex(parameterNames);
        List<Object> argumentValues = Arrays.asList(joinPoint.getArgs());
        IntStream.range(0, argumentValues.size())
                .forEach(idx -> {
                    Object argument = argumentValues.get(idx);
                    if (vinIndex == idx) {
                        String vinNoToLog = argument.toString();
                        if (vinNoToLog.length() > 6)
                            vinNoToLog = vinNoToLog.substring(0, vinNoToLog.length() - 6).concat("XXXXXX");
                        logger.info("INSIDE >> {} >> {} = {}", joinPoint.getSignature(), parameterNames[idx], vinNoToLog);
                    } else if (tokenIndex != idx)
                        logger.info("INSIDE >> {} >> {} = {}", joinPoint.getSignature(), parameterNames[idx], argument);
                });
    }

    private int getVinIndex(String[] parameterNames) {
        return Arrays.asList(parameterNames).indexOf("vin");

    }

    private int getTokenIndex(String[] parameterNames) {
        return Arrays.asList(parameterNames).indexOf("token");

    }

    @AfterThrowing(value = "within(com.vwits.asid.*.*)", throwing = "error")
    public void afterError(JoinPoint joinPoint, Exception error) {
        logger.error(" Throws error >> {} >> {}", joinPoint, error);
    }

    @AfterReturning(value = "within(com.vwits.asid.*.*)",
            returning = "result")
    public void afterReturning(JoinPoint joinPoint, Object result) {
        if (result instanceof ResponseEntity) {
            ResponseEntity<String> newResult = (ResponseEntity<String>) result;
            logger.info("After returning >> {} >> {} ", joinPoint.getSignature(), newResult.getStatusCode());
        } else {
            logger.info("After returning >> {}", joinPoint.getSignature());
        }
    }
}
