package com.vwits.asid.utility.i18n;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Component
public class LocalizationHelper {

    private ResourceBundleMessageSource messageSource;

    private static final List<Locale> SUPPORTED_LOCALES = Arrays.asList(new Locale("en","GB"), new Locale("en","US"),new Locale("de"), new Locale("fr"),
            new Locale("cs"),new Locale("es"),new Locale("fa"),new Locale("hu"),
            new Locale("it"), new Locale("nl"), new Locale("pl"),
            new Locale("pt","BR"), new Locale("pt","PT"),new Locale("ru"), new Locale("zh"));

    @Autowired
    public LocalizationHelper(final ResourceBundleMessageSource messageSource) {
        this.messageSource = messageSource;
    }

    public String getMessage(final String messageKey, final String language) {
        final Locale locale = this.toLocale(language);
        return messageSource.getMessage(messageKey, null, locale);
    }

    public String getMessage(final String messageKey, final Object[] placeHolders, final String language) {
        final Locale locale = this.toLocale(language);
        return messageSource.getMessage(messageKey, placeHolders, locale);
    }

    private Locale toLocale(final String language) {
        return language == null || language.isEmpty()
                ? Locale.getDefault()
                : Locale.lookup(Locale.LanguageRange.parse(language), SUPPORTED_LOCALES);
    }
}


