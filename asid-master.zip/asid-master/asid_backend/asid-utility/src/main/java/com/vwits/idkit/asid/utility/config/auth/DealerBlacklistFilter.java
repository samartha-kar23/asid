package com.vwits.idkit.asid.utility.config.auth;

import com.vwits.asid.utility.i18n.LocalizationHelper;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.vwits.asid.utility.constants.ASIDAppConstants.DEALER_ID_PARAMETER_NAME;


public class DealerBlacklistFilter extends OncePerRequestFilter {

    private final DealerBlacklistService dealerBlacklistService;

    public DealerBlacklistFilter(DealerBlacklistService dealerBlacklistService) {
        this.dealerBlacklistService = dealerBlacklistService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        String dealerId = httpServletRequest.getParameter(DEALER_ID_PARAMETER_NAME);
        String infoMediaType = httpServletRequest.getRequestURI().length() > 1 ? httpServletRequest.getRequestURI().substring(1) : "";
        if (dealerId == null || dealerId.isEmpty() || (dealerBlacklistService.isDealerBlacklisted(dealerId, infoMediaType))) {
            httpServletResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied");
        } else {
            filterChain.doFilter(httpServletRequest, httpServletResponse);
        }
    }
}
