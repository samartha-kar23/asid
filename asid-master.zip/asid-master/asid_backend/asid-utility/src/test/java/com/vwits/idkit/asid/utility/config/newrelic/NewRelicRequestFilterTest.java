package com.vwits.idkit.asid.utility.config.newrelic;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.ServletException;
import java.io.IOException;

import static com.vwits.idkit.asid.utility.config.newrelic.NewRelicRequestFilter.NEW_RELIC_AGENT_FILTER;
import static org.junit.Assert.assertTrue;

public class NewRelicRequestFilterTest {

    private NewRelicRequestFilter newRelicRequestFilter;
    private MockFilterChain mockChain;
    private MockHttpServletRequest httpServletRequest;
    private MockHttpServletResponse httpServletResponse;

    @Before
    public void setUp() throws Exception {

        newRelicRequestFilter = new NewRelicRequestFilter();
        mockChain = new MockFilterChain();
        httpServletRequest = new MockHttpServletRequest();
        httpServletResponse = new MockHttpServletResponse();
    }

    @Test
    public void testIfNewRelicFilterIsAdded_whenAgentIsPostman() throws ServletException, IOException {
        httpServletRequest.addHeader(HttpHeaders.USER_AGENT, "PostmanRuntime");
        newRelicRequestFilter.doFilter(httpServletRequest, httpServletResponse, mockChain);
        assertTrue((Boolean) httpServletRequest.getAttribute(NEW_RELIC_AGENT_FILTER));
    }

    @Test
    public void testIfNewRelicFilterIsAdded_whenAppnameIsBlank() throws ServletException, IOException {
        httpServletRequest.addParameter("appname", "");
        newRelicRequestFilter.doFilter(httpServletRequest, httpServletResponse, mockChain);
        assertTrue((Boolean) httpServletRequest.getAttribute(NEW_RELIC_AGENT_FILTER));
    }

    @Test
    public void testIfNewRelicFilterIsAdded_whenAppnameIsAsidtests() throws ServletException, IOException {
        httpServletRequest.addParameter("appname", "ASIDTESTS");
        newRelicRequestFilter.doFilter(httpServletRequest, httpServletResponse, mockChain);
        assertTrue((Boolean) httpServletRequest.getAttribute(NEW_RELIC_AGENT_FILTER));
    }

    @Test
    public void testIfNewRelicFilterIsAdded_whenAppnameIsDevs() throws ServletException, IOException {
        httpServletRequest.addParameter("appname", "devs");
        newRelicRequestFilter.doFilter(httpServletRequest, httpServletResponse, mockChain);
        assertTrue((Boolean) httpServletRequest.getAttribute(NEW_RELIC_AGENT_FILTER));
    }

    @Test
    public void testIfNewRelicFilterIsAdded_whenAppnameIsDev() throws ServletException, IOException {
        httpServletRequest.addParameter("appname", "dev");
        newRelicRequestFilter.doFilter(httpServletRequest, httpServletResponse, mockChain);
        assertTrue((Boolean) httpServletRequest.getAttribute(NEW_RELIC_AGENT_FILTER));
    }

    @Test
    public void testIfNewRelicFilterIsAdded_whenAppnameIsDevtest() throws ServletException, IOException {
        httpServletRequest.addParameter("appname", "devtest");
        newRelicRequestFilter.doFilter(httpServletRequest, httpServletResponse, mockChain);
        assertTrue((Boolean) httpServletRequest.getAttribute(NEW_RELIC_AGENT_FILTER));
    }

    @Test
    public void testIfNewRelicFilterIsAdded_whenAppnameIsE2E() throws ServletException, IOException {
        httpServletRequest.addParameter("appname", "e2e");
        newRelicRequestFilter.doFilter(httpServletRequest, httpServletResponse, mockChain);
        assertTrue((Boolean) httpServletRequest.getAttribute(NEW_RELIC_AGENT_FILTER));
    }
}