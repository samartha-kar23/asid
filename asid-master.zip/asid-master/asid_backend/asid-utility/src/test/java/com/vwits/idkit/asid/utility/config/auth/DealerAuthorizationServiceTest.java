package com.vwits.idkit.asid.utility.config.auth;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DealerAuthorizationServiceTest {

    private String authorizedDealer = "authorized_Dealer";
    private String infoMediaType;

    @InjectMocks
    DealerBlacklistService dealerAuthorizationService ;

    @Mock
    private RestTemplate restTemplate;

    UriComponentsBuilder builder;

    @Before
    public void setUp() throws Exception {
        infoMediaType = "rlinfo";
        builder= UriComponentsBuilder.fromHttpUrl("http://dummy_url/validatedealer")
                .queryParam("dealerid",authorizedDealer)
                .queryParam("infomediatype", infoMediaType);
        dealerAuthorizationService = new DealerBlacklistService("http://dummy_url",restTemplate);
    }

    @Test
    public void shouldReturnTrue_whenValidDealerIdIsProvided() {

        when(restTemplate.exchange(eq(builder.build().toUriString()), eq(HttpMethod.GET), any(HttpEntity.class), eq(Boolean.class))).thenReturn(ResponseEntity.ok(true));

        boolean isDealerValid = dealerAuthorizationService.isDealerBlacklisted(authorizedDealer, infoMediaType);

        assertTrue(isDealerValid);

    }

    @Test
    public void shouldReturnFalse_whenInvalidDealerIdIsProvided() {
        infoMediaType = "rlinfo";
        when(restTemplate.exchange(eq(builder.build().toUriString()), eq(HttpMethod.GET), any(HttpEntity.class), eq(Boolean.class))).thenReturn(ResponseEntity.ok(false));

        boolean isDealerValid = dealerAuthorizationService.isDealerBlacklisted(authorizedDealer, infoMediaType);
        assertFalse(isDealerValid);

    }
}
