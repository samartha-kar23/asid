package com.vwits.asid.utility.mapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.utility.entity.Scope;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static com.vwits.asid.utility.constants.ASIDAppConstants.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ReverseMappingServiceProviderTest {

    @Mock
    private RestTemplate restTemplate;
    @InjectMocks
    private ReverseMappingServiceProvider mappingServiceProvider;
    private String base;
    @Mock
    private Environment env;

    @Before
    public void setUp() {
        base = "https://dummy.com";
        when(env.getProperty("mapping-service-url")).thenReturn(base);
    }

    @Test
    public void getLaborTimeIds_shouldReturnListOfLaborTimeIds() throws IOException {
        String[] expectedLaborIds = {"9898", "234"};

        String expectedBody = new ObjectMapper().writeValueAsString(expectedLaborIds);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + "/aposid")
                .queryParam("asid", "1234");

        ResponseEntity responseEntity = ResponseEntity.ok(expectedBody);
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> laborTimeIds = mappingServiceProvider.getLaborTimeIds("1234");

        assertNotNull(laborTimeIds);
        assertEquals(Arrays.asList(expectedLaborIds), laborTimeIds);
    }


    @Test
    public void getLaborTimeIds_shouldNotReturnListOfLaborTimeIds_IfNoContent() throws IOException {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + "/aposid")
                .queryParam("asid", "1234");

        ResponseEntity responseEntity = ResponseEntity.noContent().build();
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> laborTimeIds = mappingServiceProvider.getLaborTimeIds("1234");

        assertTrue(laborTimeIds.isEmpty());
    }

    @Test
    public void getInstallationLocationIds_shouldReturnListOfInstallationLocationIds() throws IOException {
        String[] expectedLaborIds = {"9898", "234"};

        String expectedBody = new ObjectMapper().writeValueAsString(expectedLaborIds);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + REVERSE_MAPPING_SERVICE_EBOID_PATH)
                .queryParam("asid", "1234");

        ResponseEntity responseEntity = ResponseEntity.ok(expectedBody);
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> eboIds = mappingServiceProvider.getEboIds("1234");

        assertNotNull(eboIds);
        assertEquals(Arrays.asList(expectedLaborIds), eboIds);
    }


    @Test
    public void getInstallationLocationIds_shouldNotReturnListOfInstallationLocationIds_IfNoContent() throws IOException {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + REVERSE_MAPPING_SERVICE_EBOID_PATH)
                .queryParam("asid", "1234");

        ResponseEntity responseEntity = ResponseEntity.noContent().build();
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> eboIds = mappingServiceProvider.getEboIds("1234");

        assertTrue(eboIds.isEmpty());
    }

    @Test
    public void getRLIds_shouldNotReturnListOfRLIds_IfNoContent() throws IOException {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + REVERSE_MAPPING_SERVICE_RLID_PATH)
                .queryParam("asid", "1234")
                .queryParam("scope", 1);

        ResponseEntity responseEntity = ResponseEntity.noContent().build();
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> repairManualIds = mappingServiceProvider.getRlIds("1234", Scope.DIRECT);

        assertTrue(repairManualIds.isEmpty());
    }

    @Test
    public void getRLIds_shouldReturnListOfRLIds() throws IOException {
        String[] expectedRLIds = {"9898", "234"};

        String expectedBody = new ObjectMapper().writeValueAsString(expectedRLIds);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + REVERSE_MAPPING_SERVICE_RLID_PATH)
                .queryParam("asid", "1234")
                .queryParam("scope", 2);

        ResponseEntity responseEntity = ResponseEntity.ok(expectedBody);
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> repairManualIds = mappingServiceProvider.getRlIds("1234", Scope.INDIRECT);

        assertNotNull(repairManualIds);
        assertEquals(Arrays.asList(expectedRLIds), repairManualIds);
    }


    @Test
    public void getWireDiagramIds_shouldReturnListOfWireDiagramIds() throws IOException {
        String[] expectedWireDiagramIds = {"9898", "234"};

        String expectedBody = new ObjectMapper().writeValueAsString(expectedWireDiagramIds);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + REVERSE_MAPPING_SERVICE_SLPID_PATH)
                .queryParam("asid", "1234");

        ResponseEntity responseEntity = ResponseEntity.ok(expectedBody);

        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> wireDiagramIds = mappingServiceProvider.getSlpIds("1234");

        assertNotNull(wireDiagramIds);
        assertEquals(Arrays.asList(expectedWireDiagramIds), wireDiagramIds);
    }


    @Test
    public void getWireDiagramIds_shouldNotReturnListOfWireDiagramIds_IfNoContent() throws IOException {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(base + REVERSE_MAPPING_SERVICE_SLPID_PATH)
                .queryParam("asid", "1234");

        ResponseEntity responseEntity = ResponseEntity.noContent().build();

        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(responseEntity);

        List<String> wireDiagramIds = mappingServiceProvider.getSlpIds("1234");

        assertTrue(wireDiagramIds.isEmpty());
    }

}
