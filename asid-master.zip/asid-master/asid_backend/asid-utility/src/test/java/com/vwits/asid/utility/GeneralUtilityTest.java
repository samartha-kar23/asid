package com.vwits.asid.utility;

import com.vwits.asid.utility.testutils.entity.IdKitClientCredential;
import com.vwits.asid.utility.testutils.entity.Token;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static com.vwits.asid.utility.testutils.TokenUtil.getToken;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;

@RunWith(MockitoJUnitRunner.class)
public class GeneralUtilityTest {

    final RestTemplate mockedRestTemplate = mock(RestTemplate.class);

    @Test
    public void modifyLanguageToISO_itShouldBeAbleToModifyLanguageToISOType_whenLanguageProvidedIsNotISOType() {
        String languageISO = GeneralUtility.modifyLanguageToISO("en", "de");
        assertEquals("en-de", languageISO);
    }

    @Test
    public void shouldReturnOnlyCountryWhenNoLanguageProvided() {
        String languageISO = GeneralUtility.modifyLanguageToISO(null, "de");
        assertEquals("de", languageISO);
        languageISO = GeneralUtility.modifyLanguageToISO("", "de");
        assertEquals("de", languageISO);
    }

    @Test
    public void shouldReturnOnlyLanguageWhenNoCountryProvided() {
        String languageISO = GeneralUtility.modifyLanguageToISO("de", null);
        assertEquals("de", languageISO);
        languageISO = GeneralUtility.modifyLanguageToISO("de", "");
        assertEquals("de", languageISO);
    }

    @Test
    public void shouldReturnEmptyStringWhenBothLanguageAndCountryIsEmpty() {
        String languageISO = GeneralUtility.modifyLanguageToISO(null, null);
        assertEquals("", languageISO);
        languageISO = GeneralUtility.modifyLanguageToISO("", "");
        assertEquals("", languageISO);
        languageISO = GeneralUtility.modifyLanguageToISO("", null);
        assertEquals("", languageISO);
        languageISO = GeneralUtility.modifyLanguageToISO(null, "");
        assertEquals("", languageISO);
    }

    @Test
    public void shouldReturnTrueIfListIsNullOrEmpty() {
        boolean result = GeneralUtility.isEmpty(new ArrayList());
        assertTrue(result);
        final List o = null;
        result = GeneralUtility.isEmpty(o);
        assertTrue(result);
    }

    @Test
    public void shouldReturnTrueIfArrayIsNullOrEmpty() {
        boolean result = GeneralUtility.isEmpty(new Object[0]);
        assertTrue(result);
        final Object[] o = null;
        result = GeneralUtility.isEmpty(o);
        assertTrue(result);
    }

    @Test
    public void shouldReturnFalseIfListIsNotEmpty() {
        final ArrayList<Integer> anyList = new ArrayList<>();
        anyList.add(1);
        boolean result = GeneralUtility.isEmpty(anyList);
        assertFalse(result);
    }

    @Test
    public void shouldReturnFalseIfArrayIsNotEmpty() {
        final Integer[] anyArray = new Integer[1];
        anyArray[0] = 1;
        boolean result = GeneralUtility.isEmpty(anyArray);
        assertFalse(result);
    }

    @Test
    public void modifyLanguageToISO_itShouldBeNotModifyLanguage_whenLanguageProvidedIsISOType() {
        String languageISO = GeneralUtility.modifyLanguageToISO("en-DE", "IN");
        assertEquals("en-DE", languageISO);
    }

    @Test
    public void modifyLanguageToISO_itShouldBeNotModifyLanguage_whenLanguageProvidedIsMoreThan2CharactersLong() {
        String languageISO = GeneralUtility.modifyLanguageToISO("eng", "IN");
        assertEquals("eng", languageISO);
    }

    @Test
    public void trimStringTo3Chars_itShouldTrimAString_whenTheStringIsMoreThan3CharLength() {
        String trimmedString = GeneralUtility.trimStringTo3Chars("abcd");
        assertEquals("abc", trimmedString);
    }

    @Test
    public void trimStringTo3Chars_itShouldNotTrimAString_whenTheStringIsLessThanOrEquals3CharLength() {
        String trimmedString = GeneralUtility.trimStringTo3Chars("abc");
        assertEquals("abc", trimmedString);

        trimmedString = GeneralUtility.trimStringTo3Chars("ab");
        assertEquals("ab", trimmedString);
    }

    @Test
    public void computeTypeFolder_itShouldProvideFolderName_whenFileTypeIsofPngOrSVG() {
        String typeFolderName = GeneralUtility.computeTypeFolder("png");
        assertEquals("png", typeFolderName);

        typeFolderName = GeneralUtility.computeTypeFolder("pngx");
        assertEquals("png", typeFolderName);

        typeFolderName = GeneralUtility.computeTypeFolder("svg");
        assertEquals("svg", typeFolderName);

        typeFolderName = GeneralUtility.computeTypeFolder("svgz");
        assertEquals("svg", typeFolderName);
    }

    @Test
    public void computeTypeFolder_itShouldProvideFolderNameAsOther_whenFileTypeIsNotOfTypePngOrSVG() {
        String typeFolderName = GeneralUtility.computeTypeFolder(null);
        assertEquals("other", typeFolderName);

        typeFolderName = GeneralUtility.computeTypeFolder("dfhjks");
        assertEquals("other", typeFolderName);
    }

    @Test
    public void shouldMakeAValidRequestUsingIdKitCredentialClass() {
        final String clientId = "clientId";
        final String secret = "secret";
        final String tokenUrl = "tokenUrl";
        final String grantType = "grant-type";
        final IdKitClientCredential mockIdKitCred = new IdKitClientCredential(tokenUrl, clientId, secret, grantType);
        when(mockedRestTemplate.postForEntity(anyString(), any(), eq(Token.class)))
                .thenReturn(new ResponseEntity<>(new Token().withAccessToken("something"), HttpStatus.OK));

        getToken(mockedRestTemplate, mockIdKitCred);

        ArgumentCaptor<HttpEntity> entityCaptor = ArgumentCaptor.forClass(HttpEntity.class);
        verify(mockedRestTemplate).postForEntity(eq(mockIdKitCred.getTokenURL()), entityCaptor.capture(), eq(Token.class));
        assertEquals(APPLICATION_FORM_URLENCODED.toString(), entityCaptor.getValue().getHeaders().getFirst(HttpHeaders.CONTENT_TYPE));
        assertEquals(secret, ((MultiValueMap<String, String>) entityCaptor.getValue().getBody()).getFirst("client_secret"));
        assertEquals(clientId, ((MultiValueMap<String, String>) entityCaptor.getValue().getBody()).getFirst("client_id"));
        assertEquals(grantType, ((MultiValueMap<String, String>) entityCaptor.getValue().getBody()).getFirst("grant_type"));
    }

    @Test
    public void shouldReturnValidAccessTokenWhenValidCredentialsProvided() {
        String expectedAccessToken = "valid-token";
        final IdKitClientCredential mockIdKitCred = new IdKitClientCredential("tokenUrl", "clientId", "secret", "grant-type");
        when(mockedRestTemplate.postForEntity(eq(mockIdKitCred.getTokenURL()), any(HttpEntity.class), eq(Token.class)))
                .thenReturn(new ResponseEntity<>(new Token().withAccessToken(expectedAccessToken), HttpStatus.OK));

        final String token = getToken(mockedRestTemplate, mockIdKitCred);

        assertEquals(expectedAccessToken, token);
    }

    @Test
    public void shouldThrowHttpServletExceptionWhenInValidCredentialsProvided() {
        final IdKitClientCredential mockIdKitCred = new IdKitClientCredential("tokenUrl", "invalid-clientId", "invalid-secret", "grant-type");
        final String errorMessage = "UNAUTHORIZED";
        when(mockedRestTemplate.postForEntity(eq(mockIdKitCred.getTokenURL()), any(HttpEntity.class), eq(Token.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.UNAUTHORIZED, errorMessage));
        try {
            getToken(mockedRestTemplate, mockIdKitCred);
        } catch (HttpClientErrorException e) {
            assertEquals(HttpStatus.UNAUTHORIZED, e.getStatusCode());
            assertEquals(errorMessage, e.getStatusText());
        }

    }

    @Test
    public void shouldReturnBase64String() {
        assertEquals("YWJj", GeneralUtility.convertStringToBase64("abc"));
    }

    @Test
    public void shouldExtractSalesTypeFromVIN() {
        String vin = "ABCDEFGHIJKLMN";
        String salesType = "GHI";

        assertEquals(salesType, GeneralUtility.extractSalesTypeFromVIN(vin));
    }

    @Test
    public void shouldNotExtractSalesTypeWhenProvidedVINIsInvalid() {
        String vin = "ABCDEF";
        assertEquals(GeneralUtility.INVALID_SALES_TYPE, GeneralUtility.extractSalesTypeFromVIN(vin));
    }
}