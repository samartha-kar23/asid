package com.vwits.asid.utility.environment;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({System.class, CloudEnvironmentProvider.class})
public class CloudEnvironmentProviderTest {

    private static final String VCAP_APPLICATION = "{\n" +
            "  \"application_id\": \"1234\",\n" +
            "  \"application_name\": \"repair-manual-service\",\n" +
            "  \"application_uris\": [\n" +
            "   \"repair-manual-service-url-space.apps.emea.vwapps.io\"\n" +
            "  ],\n" +
            "  \"application_version\": \"abcd\",\n" +
            "  \"cf_api\": \"https://api.com\",\n" +
            "  \"limits\": {\n" +
            "   \"disk\": 256,\n" +
            "   \"fds\": 16384,\n" +
            "   \"mem\": 400\n" +
            "  },\n" +
            "  \"name\": \"repair-manual-service\",\n" +
            "  \"space_id\": \"1234\",\n" +
            "  \"space_name\": \"development\",\n" +
            "  \"uris\": [\n" +
            "   \"repair-manual-service-uri\"\n" +
            "  ],\n" +
            "  \"users\": null,\n" +
            "  \"version\": \"1234\"\n" +
            " }\n" +
            "}";

    private CloudEnvironmentProvider rlEnvProvider;

    @Before
    public void setUp() {
        PowerMockito.mockStatic(System.class);
        when(System.getenv("VCAP_APPLICATION")).thenReturn(VCAP_APPLICATION);
        rlEnvProvider = new CloudEnvironmentProvider();
    }

    @Test
    public void shouldProvideSpaceName_FromVCAP_Application_Properties() {
        final String expectedStageName = "development";
        String stageName = rlEnvProvider.getStageName();

        assertEquals(expectedStageName, stageName);
    }

    @Test
    public void shouldProvideAppURI_FromVCAP_Application_Properties() {
        final String expectedAppURI = "repair-manual-service-url-space.apps.emea.vwapps.io";
        String actualAppURI = rlEnvProvider.getApplicationURI();

        assertEquals(expectedAppURI, actualAppURI);
    }
}

