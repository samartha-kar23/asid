package com.vwits.idkit.asid.utility.config.auth;

import com.vwits.asid.utility.i18n.LocalizationHelper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.ServletException;
import java.io.IOException;

import static com.vwits.asid.utility.constants.ASIDAppConstants.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.FORBIDDEN;

@RunWith(MockitoJUnitRunner.class)
public class DealerBlacklistFilterTest {
    @InjectMocks
    private DealerBlacklistFilter dealerAuthorizationFilter;

    @Mock
    private DealerBlacklistService dealerAuthorizationService;

    private MockHttpServletRequest mockHttpServletRequest;

    private MockHttpServletResponse mockHttpServletResponse;
    private String infoMediaType = "rlinfo";

    @Before
    public void setUp() {
        mockHttpServletRequest = new MockHttpServletRequest();
        mockHttpServletResponse = new MockHttpServletResponse();
        dealerAuthorizationFilter = new DealerBlacklistFilter(dealerAuthorizationService);
    }

    @Test
    public void shouldReturnForbidden_whenBlacklistedDealerIdProvided() throws ServletException, IOException {
        String invalidDealerId = "InvalidDealerId";

        String requestURI = APOS_API_PATH;
        mockHttpServletRequest.setRequestURI(requestURI);

        mockHttpServletRequest.setParameter(DEALER_ID_PARAMETER_NAME, invalidDealerId);
        when(dealerAuthorizationService.isDealerBlacklisted(invalidDealerId, LT_INFO)).thenReturn(true);

        dealerAuthorizationFilter.doFilterInternal(mockHttpServletRequest, mockHttpServletResponse, new MockFilterChain());
        verify(dealerAuthorizationService).isDealerBlacklisted(anyString(), anyString());
        assertEquals(FORBIDDEN.value(), mockHttpServletResponse.getStatus());
    }

    @Test
    public void shouldNotBeForbidden_whenValidDealerIdProvided() throws ServletException, IOException {
        String validDealerId = "ValidDealerId";

        mockHttpServletRequest.setParameter(DEALER_ID_PARAMETER_NAME, validDealerId);
        String requestURI = "/rlinfo";
        mockHttpServletRequest.setRequestURI(requestURI);

        when(dealerAuthorizationService.isDealerBlacklisted(validDealerId, requestURI.substring(1))).thenReturn(false);

        dealerAuthorizationFilter.doFilterInternal(mockHttpServletRequest, mockHttpServletResponse, new MockFilterChain());
        verify(dealerAuthorizationService).isDealerBlacklisted(anyString(), anyString());
        Assert.assertNotEquals(FORBIDDEN.value(), mockHttpServletResponse.getStatus());
    }


    @Test
    public void shouldReturnForbidden_whenURIIsNotProvided() throws ServletException, IOException {
        String validDealerId = "ValidDealerId";

        mockHttpServletRequest.setParameter(DEALER_ID_PARAMETER_NAME, validDealerId);
        String requestURI = "";
        mockHttpServletRequest.setRequestURI(requestURI);

        when(dealerAuthorizationService.isDealerBlacklisted(validDealerId, requestURI)).thenReturn(true);

        dealerAuthorizationFilter.doFilterInternal(mockHttpServletRequest, mockHttpServletResponse, new MockFilterChain());

        verify(dealerAuthorizationService).isDealerBlacklisted(anyString(), anyString());
        assertEquals(FORBIDDEN.value(), mockHttpServletResponse.getStatus());
    }

    @Test
    public void shouldReturnForbidden_whenDealerIdIsNotPresentInRequest() throws ServletException, IOException {

        dealerAuthorizationFilter.doFilterInternal(mockHttpServletRequest, mockHttpServletResponse, new MockFilterChain());
        verifyZeroInteractions(dealerAuthorizationService);

        assertEquals(FORBIDDEN.value(), mockHttpServletResponse.getStatus());
    }

}
