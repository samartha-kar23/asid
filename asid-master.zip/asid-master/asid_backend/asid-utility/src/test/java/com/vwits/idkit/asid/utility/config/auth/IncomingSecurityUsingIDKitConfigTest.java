package com.vwits.idkit.asid.utility.config.auth;


import com.vwits.asid.utility.testutils.reflectionutil.ReflectionUtilsForTesting;
import org.junit.Test;
import vwg.digitallab.identitykit.clients.oauth2incoming.config.PlatformSecurityConfig;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class IncomingSecurityUsingIDKitConfigTest {

    @Test
    public void platformSecurityConfig_shouldConfigureWhitelistedClient_whenProvidedwithClientkey() {

        String[] whitelistedClient = new String[]{"FirstWhiteListedClient", "SecondWhiteListedClient"};

        IncomingSecurityUsingIDKitConfig subject = new IncomingSecurityUsingIDKitConfig();

        ReflectionUtilsForTesting.injectAnyField(subject,"whitelistedClient",String[].class,whitelistedClient);
        PlatformSecurityConfig platformSecurityConfig = subject.platformSecurityConfig();

        assertTrue(platformSecurityConfig.isCsrfEnabled());
        assertTrue(platformSecurityConfig.isOAuth2Enabled());
        assertFalse(platformSecurityConfig.isExternalAuthorizationEnabled());

        assertTrue(platformSecurityConfig.isClientWhitelisted(whitelistedClient[0]));
        assertTrue(platformSecurityConfig.isClientWhitelisted(whitelistedClient[1]));

    }
}