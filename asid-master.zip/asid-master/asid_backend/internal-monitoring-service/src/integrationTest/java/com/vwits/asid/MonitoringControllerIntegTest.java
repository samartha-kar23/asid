package com.vwits.asid;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class MonitoringControllerIntegTest {

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private MockMvc mvc;

    @Test
    public void getASIDFromRLID_shouldReturnASID_withStatusOk_whenCorrectRLIDisProvided() throws Exception {

        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

        UsageStatisticsDTO templatePostData = UsageStatisticsDTO.builder().appName("dummy").asid("dummy").brand("A")
               .timeStamp(LocalDateTime.now())
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                        language("english").responseCode(200).responseTime(200L).build();


        mvc.perform(post("/api/statistics")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(templatePostData)))
                .andExpect(status().isOk())
                .andExpect(content().string(Boolean.TRUE.toString()));
    }



}
