package com.vwits.asid;

import com.vwits.asid.entity.UsageStatisticsEntity;
import com.vwits.asid.repository.UsageStatisticsRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.util.Optional;

import static junit.framework.TestCase.assertTrue;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase
public class UsageStatisticsRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private UsageStatisticsRepository usageStatisticsRepository;


    @Test
    public void shouldStoreRecordsInUsageStatisticsTable() {

        UsageStatisticsEntity transactionStatisticsDAOForLT = UsageStatisticsEntity.builder()
                .appName("LT").asid("dummy").brand("A")
                .timeStamp(LocalDateTime.now())
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                        language("english").responseCode(200).responseTime(200L).build();

        UsageStatisticsEntity transactionStatisticsDAOForRL = UsageStatisticsEntity.builder()
                .appName("RL").asid("dummy").brand("A")
                .timeStamp(LocalDateTime.now())
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                        language("english").responseCode(200).responseTime(200L).build();
        entityManager.persist(transactionStatisticsDAOForLT);
        entityManager.persist(transactionStatisticsDAOForRL);
        entityManager.flush();

        // when
        final Optional<UsageStatisticsEntity> actualUsageStatistics = usageStatisticsRepository.findById(transactionStatisticsDAOForLT.getId());

        // then
        assertTrue(actualUsageStatistics.isPresent());
        assertTrue(usageStatisticsRepository.findAll().size() > 1);

    }
}
