package com.vwits.asid.service;

import com.vwits.asid.entity.UsageStatisticsEntity;
import com.vwits.asid.repository.UsageStatisticsRepository;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class InternalMonitoringService {

    private UsageStatisticsRepository usageStatisticsRepository;

    public InternalMonitoringService(UsageStatisticsRepository usageStatisticsRepository) {
        this.usageStatisticsRepository = usageStatisticsRepository;
    }

    public boolean storeUsageData(UsageStatisticsDTO auditDTO) {
        boolean isDataStored;
        UsageStatisticsEntity usageStatisticsDAO = toUserStatisticsDAO(auditDTO);
        try {
            isDataStored = usageStatisticsRepository.save(usageStatisticsDAO)!=null;
        }
        catch (Exception e){
            log.error("Error occurred while saving audit data ", e);
            isDataStored = false;
        }
        return isDataStored;
    }

    private UsageStatisticsEntity toUserStatisticsDAO(UsageStatisticsDTO auditDTO) {
        return UsageStatisticsEntity.builder()
                .appName(auditDTO.getAppName())
                .asid(auditDTO.getAsid())
                .brand(auditDTO.getBrand())
                .timeStamp(auditDTO.getTimeStamp())
                .dealerId(auditDTO.getDealerId())
                .endPoint(auditDTO.getEndPoint())
                .language(auditDTO.getLanguage())
                .responseCode(auditDTO.getResponseCode())
                .responseTime(auditDTO.getResponseTime())
                .build();
    }
}
