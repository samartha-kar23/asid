package com.vwits.asid.controller;

import com.vwits.asid.service.InternalMonitoringService;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api")
public class InternalMonitoringController {

    @Autowired
    private InternalMonitoringService internalMonitoringService;


    @PostMapping(path = "/statistics")
    public ResponseEntity storeUsageData(@RequestBody final UsageStatisticsDTO auditDTO) {
        boolean responseStatus = internalMonitoringService.storeUsageData(auditDTO);
        return ResponseEntity.ok().body(responseStatus);
    }
}
