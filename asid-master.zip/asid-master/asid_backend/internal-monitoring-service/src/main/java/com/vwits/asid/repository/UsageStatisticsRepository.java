package com.vwits.asid.repository;


import com.vwits.asid.entity.UsageStatisticsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsageStatisticsRepository extends JpaRepository<UsageStatisticsEntity, Long> {
}
