package com.vwits.asid.controller;

import com.vwits.asid.service.InternalMonitoringService;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class InternalMonitoringControllerTest {

    @Mock
    private InternalMonitoringService internalMonitoringService;

    @InjectMocks
    private InternalMonitoringController monitoringDataController;
    private UsageStatisticsDTO transactionAuditDTO;

    @Before
    public void setUp() {
        transactionAuditDTO = UsageStatisticsDTO.builder().appName("dummy").asid("dummy").brand("A")
                .timeStamp(LocalDateTime.now())
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                language("english").responseCode(200).responseTime(200L).build();

    }

    @Test
    public void shouldStoreDataAndReturnTrue_whenRequiredParamsArePassed() {

        when(internalMonitoringService.storeUsageData(any())).thenReturn(true);
        ResponseEntity responseEntity=monitoringDataController.storeUsageData(transactionAuditDTO);
        assertTrue((Boolean) responseEntity.getBody());
    }


    @Test
    public void shouldReturnFalse_whenUnableToStoreRecordsInDatabase() {
        when(internalMonitoringService.storeUsageData(any())).thenReturn(false);
        ResponseEntity responseEntity=monitoringDataController.storeUsageData(transactionAuditDTO);
        assertFalse((Boolean) responseEntity.getBody());
    }
}
