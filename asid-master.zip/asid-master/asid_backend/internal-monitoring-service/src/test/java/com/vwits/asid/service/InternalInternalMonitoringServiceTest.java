package com.vwits.asid.service;

import com.vwits.asid.entity.UsageStatisticsEntity;
import com.vwits.asid.repository.UsageStatisticsRepository;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.LocalDateTime;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class InternalInternalMonitoringServiceTest {

    private InternalMonitoringService internalMonitoringService;

    @Mock
    private UsageStatisticsRepository usageStatisticsRepository;
    private UsageStatisticsDTO transactionAuditDTO;

    @Before
    public void setUp() {

        internalMonitoringService = new InternalMonitoringService(usageStatisticsRepository);

        transactionAuditDTO = UsageStatisticsDTO.builder().appName("dummy").asid("dummy").brand("A")
                .timeStamp(LocalDateTime.now())
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                        language("english").responseCode(200).responseTime(200L).build();

    }

    @Test
    public void shouldReturnTrue_whenDataIsStoredInDatabase() {
        when(usageStatisticsRepository.save(any())).thenReturn(new UsageStatisticsEntity());
        assertTrue(internalMonitoringService.storeUsageData(transactionAuditDTO));
    }

    @Test
    public void shouldReturnFalse_whenDataIsUnableToStoreInDatabase() {
        when(usageStatisticsRepository.save(any())).thenReturn(null);
        assertFalse(internalMonitoringService.storeUsageData(transactionAuditDTO));
    }

    @Test
    public void shouldReturnFalse_whenExceptionThrownByRepository() {
        when(usageStatisticsRepository.save(any())).thenThrow(new RuntimeException());
        assertFalse(internalMonitoringService.storeUsageData(transactionAuditDTO));
    }
}
