package com.vwits.asid.controller;

import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.entity.RepairManualMappingDTO;
import com.vwits.asid.exception.DuplicateRecordException;
import com.vwits.asid.exception.InvalidLengthException;
import com.vwits.asid.service.AuthorizationService;
import com.vwits.asid.service.IDTokenHelper;
import com.vwits.asid.service.MappingService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import javax.servlet.http.Cookie;
import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MappingDataControllerTest {

    private final String validEmailId = "valid-email";
    @Mock
    AuthorizationService authorizationService;
    @Mock
    private MappingService mappingService;
    @InjectMocks
    private MappingDataController mappingDataController;
    private Cookie cookie;
    private MockHttpServletRequest request;
    @Mock
    private IDTokenHelper idTokenHelper;

    @Before
    public void setUp() throws Exception {
        request = new MockHttpServletRequest();
        cookie = new Cookie("id-token", "valid-token");
        request.setCookies(cookie);
        when(idTokenHelper.getEmail(request)).thenReturn(validEmailId);
        when(authorizationService.isUserAuthorized(validEmailId)).thenReturn(true);
    }

    @Test
    public void getMappingDataForRepairManual_itShouldReturnAllMappingDataInCSVFormat_withStatus200() {

        ArrayList<RepairManualMapping> dummyRepairManualMappingList = new ArrayList<>();
        RepairManualMapping repairManualMapping = new RepairManualMapping(1l, "asid-1", "rlid-1");
        dummyRepairManualMappingList.add(repairManualMapping);

        when(mappingService.getAllRepairManualMapping()).thenReturn(dummyRepairManualMappingList);
        ResponseEntity actualMappingDataResponse = mappingDataController.getRepairManualMappingData(request);

        assertNotNull(actualMappingDataResponse);
        assertEquals(HttpStatus.OK.value(), actualMappingDataResponse.getStatusCodeValue());
        assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, actualMappingDataResponse.getHeaders().getContentType().toString());
        assertTrue(actualMappingDataResponse.getHeaders().get("Content-Disposition").contains("attachment; filename=rlmappingdata.csv"));

        String actualCSVData = actualMappingDataResponse.getBody().toString();
        assertTrue(actualCSVData.contains(dummyRepairManualMappingList.get(0).getAsid()));
        assertTrue(actualCSVData.contains(dummyRepairManualMappingList.get(0).getRepairManualId()));

    }

    @Test
    public void getMappingDataForRepairManual_itShouldReturnNoContent_whenMappingDataDoesNotExist() {
        when(mappingService.getAllRepairManualMapping()).thenReturn(new ArrayList<>());
        ResponseEntity actualMappingDataResponse = mappingDataController.getRepairManualMappingData(request);

        assertEquals(HttpStatus.NO_CONTENT.value(), actualMappingDataResponse.getStatusCodeValue());
    }

    @Test
    public void deleteMappingRowForRepairManual_itShouldDeleteARow_whenProvidedWithOneCombinationOfASIDandRLId() {
        String asid = "dummy";
        String rlid = "dummy";
        ResponseEntity responseEntity = mappingDataController.deleteMappingRowForRepairManual(request, asid, rlid);

        assertEquals(HttpStatus.NO_CONTENT, responseEntity.getStatusCode());
        verify(mappingService).deleteRepairManualMapping(anyString(), anyString());
    }

    @Test
    public void addRlMapping_itShouldAddNewEntryToRLMapping_whenASIDAndRLIDIsProvided() {

        RepairManualMapping dummyRepairManualMapping = new RepairManualMapping().withAsid("ASID").withRepairManualId("RLID");
        RepairManualMappingDTO dummyRepairManualMappingDTO = new RepairManualMappingDTO().withAsid("ASID").withRepairManualId("RLID");

        when(mappingService.addRlMapping(dummyRepairManualMappingDTO)).thenReturn(dummyRepairManualMapping);

        ResponseEntity response = mappingDataController.addRlMapping(request, dummyRepairManualMappingDTO);

        assertNotNull(response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void addRlMapping_itShouldReturnUnsupportedEntity_whenIllegalCharsPresentInAsidOrRlid() {

        RepairManualMappingDTO dummyRepairManualMappingDTO = new RepairManualMappingDTO().withAsid("ASID*").withRepairManualId("RLID*");

        when(mappingService.addRlMapping(dummyRepairManualMappingDTO)).thenThrow(new IllegalArgumentException("error message"));

        ResponseEntity responseEntity = mappingDataController.addRlMapping(request, dummyRepairManualMappingDTO);

        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY.value(), responseEntity.getStatusCode().value());
    }

    @Test
    public void addRlMapping_itShouldReturnUnsupportedEntity_whenTooManyCharsInASIDOrRLid() {

        RepairManualMappingDTO dummyRepairManualMappingDTO = new RepairManualMappingDTO().withAsid("ASID*").withRepairManualId("RLID*");

        when(mappingService.addRlMapping(dummyRepairManualMappingDTO)).thenThrow(new InvalidLengthException("error message"));

        ResponseEntity responseEntity = mappingDataController.addRlMapping(request, dummyRepairManualMappingDTO);

        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY.value(), responseEntity.getStatusCode().value());
    }

    @Test
    public void addRlMapping_itShouldReturnUnsupportedEntity_whenAsidOrRLidIsNull() {

        RepairManualMappingDTO dummyRepairManualMappingDTO = new RepairManualMappingDTO().withAsid("ASID*").withRepairManualId("RLID*");

        when(mappingService.addRlMapping(dummyRepairManualMappingDTO)).thenThrow(new InvalidLengthException("error message"));

        ResponseEntity responseEntity = mappingDataController.addRlMapping(request, dummyRepairManualMappingDTO);

        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY.value(), responseEntity.getStatusCode().value());
    }

    @Test
    public void addRlMapping_itShouldReturnUnsupportedEntity_whenAsidOrRlidLengthIsZero() {
        RepairManualMappingDTO dummyRepairManualMappingDTO = new RepairManualMappingDTO().withAsid("ASID*").withRepairManualId("RLID*");

        when(mappingService.addRlMapping(dummyRepairManualMappingDTO)).thenThrow(new InvalidLengthException("error message"));

        ResponseEntity responseEntity = mappingDataController.addRlMapping(request, dummyRepairManualMappingDTO);

        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY.value(), responseEntity.getStatusCode().value());
    }

    @Test
    public void addRlMapping_itShouldReturnUnsupportedEntity_whenASIDAndRlidAlreadyExistInDatabase() {
        RepairManualMappingDTO dummyRepairManualMappingDTO = new RepairManualMappingDTO().withAsid("ASID*").withRepairManualId("RLID*");

        when(mappingService.addRlMapping(dummyRepairManualMappingDTO)).thenThrow(new DuplicateRecordException("duplicate entry error"));

        ResponseEntity responseEntity = mappingDataController.addRlMapping(request, dummyRepairManualMappingDTO);

        assertEquals(HttpStatus.CONFLICT.value(), responseEntity.getStatusCode().value());
    }
}
