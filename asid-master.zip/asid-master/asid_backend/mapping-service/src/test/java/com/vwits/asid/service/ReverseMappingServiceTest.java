package com.vwits.asid.service;

import com.vwits.asid.entity.LaborTimeMapping;
import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.entity.SlpEboMapping;
import com.vwits.asid.repository.LaborTimeMappingRepository;
import com.vwits.asid.repository.RepairManualDirectMappingRepository;
import com.vwits.asid.repository.RepairManualMappingIndirectLinkRepository;
import com.vwits.asid.repository.SlpEboMappingRepository;
import com.vwits.asid.utility.entity.Scope;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ReverseMappingServiceTest {
    @Mock
    private LaborTimeMappingRepository laborTimeMappingRepository;

    @Mock
    private RepairManualDirectMappingRepository repairManualDirectMappingRepository;

    @Mock
    SlpEboMappingRepository slpEboMappingRepository;

    @Mock
    private RepairManualMappingIndirectLinkRepository indirectRepairManualMappingRepository;

    @InjectMocks
    private ReverseMappingService reverseMappingService;

    @Test
    public void getLaborTimeIdForAsid_Positive_shouldReturnMultipleLaborTimeIds() {
        final String asid = "1234";

        final List<String> laborTimeId = new ArrayList<>();
        laborTimeId.add("4321-000");
        laborTimeId.add("1234-000");
        final List<LaborTimeMapping> laborTimeMappings = getLaborTimeMappingsFromLaborTimeId(laborTimeId);
        when(laborTimeMappingRepository.findAllByAsid(asid)).thenReturn(laborTimeMappings);

        List<String> responseLaborTimeIdList = reverseMappingService.getLaborTimeIdForAsid(asid);

        Assert.assertEquals(laborTimeId.size(), responseLaborTimeIdList.size());
        Assert.assertTrue(laborTimeId.contains(responseLaborTimeIdList.get(0)));
        Assert.assertTrue(laborTimeId.contains(responseLaborTimeIdList.get(1)));
    }

    @Test
    public void getLaborTimeIdForASID_Negative_ShouldReturnEmptyAsidList_IfLaborTimeIdIsInvalid() throws Exception {

        final String invalidAsid = "abcd-sdf";
        final List<String> emptyLaborTimeIdList = new ArrayList<>();
        final List<LaborTimeMapping> laborTimeMappings = getLaborTimeMappingsFromLaborTimeId(emptyLaborTimeIdList);

        when(laborTimeMappingRepository.findAllByAsid(invalidAsid)).thenReturn(laborTimeMappings);

        List<String> responseAsidList = reverseMappingService.getLaborTimeIdForAsid(invalidAsid);

        Assert.assertEquals(emptyLaborTimeIdList.size(), responseAsidList.size());
    }

    private List<LaborTimeMapping> getLaborTimeMappingsFromLaborTimeId(List<String> laborTimeId) {
        final List<LaborTimeMapping> laborTimeMappings = new ArrayList<>();
        for (String id : laborTimeId) {
            laborTimeMappings.add(new LaborTimeMapping().withLaborTimeId(id));
        }
        return laborTimeMappings;
    }


    @Test
    public void getRepairManualIdForAsid_Positive_shouldReturnMultipleDirectMappingRepairManualIds() {
        final String asid = "1234,3214";

        final List<String> rlIds = new ArrayList<>();
        rlIds.add("4321-000");
        rlIds.add("1234-000");
        when(repairManualDirectMappingRepository.findRepairManualDirectIdByAsid(Arrays.asList(asid.split(",")))).thenReturn(rlIds);

        List<String> responseRepairManualIdList = reverseMappingService.getRepairManualIdsForAsid(asid, Scope.DIRECT);

        Assert.assertEquals(rlIds.size(), responseRepairManualIdList.size());
        Assert.assertTrue(rlIds.contains(responseRepairManualIdList.get(0)));
        Assert.assertTrue(rlIds.contains(responseRepairManualIdList.get(1)));
    }

    @Test
    public void getRepairManualIdForASID_itShouldReturnEmptyList_whenInvalidASIDProvidedForDirectMapping() throws Exception {

        final String invalidAsid = "abcd-sdf";
        final List<String> emptyRepairManualIdList = new ArrayList<>();
        final List<RepairManualMapping> repairManualMappings = getRepairManualMappingsFromRepairManualId(emptyRepairManualIdList);

        when(repairManualDirectMappingRepository.findAllByAsid(invalidAsid)).thenReturn(repairManualMappings);

        List<String> responseAsidList = reverseMappingService.getRepairManualIdsForAsid(invalidAsid, Scope.DIRECT);

        Assert.assertEquals(emptyRepairManualIdList.size(), responseAsidList.size());
    }

    @Test
    public void shouldReturnListOfInDirectMappingRepairManualIds_whenValidASIDProvidedWithScopeIndirect() {
        String validAsid = "valid_asid,qwerty_asdfg";
        final List<String> indirectRlIds = new ArrayList<>();
        indirectRlIds.add("4321-000");
        indirectRlIds.add("1234-000");

        when(indirectRepairManualMappingRepository.findRepairManualIndirectIdByAsid(Arrays.asList(validAsid.split(",")))).thenReturn(indirectRlIds);
        List<String> actualIndirectRepairManualIdsForAsid = reverseMappingService.getRepairManualIdsForAsid(validAsid, Scope.INDIRECT);

        verify(indirectRepairManualMappingRepository).findRepairManualIndirectIdByAsid(Arrays.asList(validAsid.split(",")));
        Assert.assertNotNull(actualIndirectRepairManualIdsForAsid);
        Assert.assertEquals(indirectRlIds.size(), actualIndirectRepairManualIdsForAsid.size());
        Assert.assertTrue(indirectRlIds.contains(actualIndirectRepairManualIdsForAsid.get(0)));
        Assert.assertTrue(indirectRlIds.contains(actualIndirectRepairManualIdsForAsid.get(1)));
    }

    @Test
    public void shouldReturnEmptyListOfInDirectMappingRepairManualIds_whenInValidASIDProvidedWithScopeIndirect() {
        String invalidAsid = "invalid_asid,zxcvb_qwert";

        when(indirectRepairManualMappingRepository.findRepairManualIndirectIdByAsid(Arrays.asList(invalidAsid.split(",")))).thenReturn(new ArrayList<>());
        List<String> actualIndirectRepairManualIdsForAsid = reverseMappingService.getRepairManualIdsForAsid(invalidAsid, Scope.INDIRECT);

        verify(indirectRepairManualMappingRepository).findRepairManualIndirectIdByAsid(Arrays.asList(invalidAsid.split(",")));
        Assert.assertNotNull(actualIndirectRepairManualIdsForAsid);
        Assert.assertEquals(0, actualIndirectRepairManualIdsForAsid.size());
    }


    @Test
    public void shouldReturnListOfInDirectAndDirectMappingRepairManualIds_whenValidASIDProvidedWithScopeAll() {
        String validAsid = "valid_asid,newValid_asid";
        final List<String> indirectRlIds = new ArrayList<>();
        indirectRlIds.add("4321-indirect");
        indirectRlIds.add("1234-indirect");

        final List<String> directRlIds = new ArrayList<>();
        directRlIds.add("4321-direct");
        directRlIds.add("1234-direct");

        List<String> rlids = new ArrayList<>();
        rlids.addAll(indirectRlIds);
        rlids.addAll(directRlIds);

        when(indirectRepairManualMappingRepository.findRepairManualIndirectIdByAsid(Arrays.asList(validAsid.split(",")))).thenReturn(indirectRlIds);
        when(repairManualDirectMappingRepository.findRepairManualDirectIdByAsid(Arrays.asList(validAsid.split(",")))).thenReturn(directRlIds);
        List<String> repairManualIdsForAsid = reverseMappingService.getRepairManualIdsForAsid(validAsid, Scope.ALL);

        verify(indirectRepairManualMappingRepository).findRepairManualIndirectIdByAsid(Arrays.asList(validAsid.split(",")));
        verify(repairManualDirectMappingRepository).findRepairManualDirectIdByAsid(Arrays.asList(validAsid.split(",")));
        Assert.assertNotNull(repairManualIdsForAsid);
        Assert.assertEquals(indirectRlIds.size() + directRlIds.size(), repairManualIdsForAsid.size());
        Assert.assertTrue(repairManualIdsForAsid.containsAll(indirectRlIds));
        Assert.assertTrue(repairManualIdsForAsid.containsAll(directRlIds));
    }

    @Test
    public void shouldReturnEmptyList_whenInValidASIDProvidedWithScopeAll() {
        String invalidAsid = "invalid_asid,nmkl_oplk";

        when(indirectRepairManualMappingRepository.findRepairManualIndirectIdByAsid(Arrays.asList(invalidAsid.split(",")))).thenReturn(new ArrayList<>());
        List<String> actualIndirectRepairManualIdsForAsid = reverseMappingService.getRepairManualIdsForAsid(invalidAsid, Scope.ALL);

        verify(indirectRepairManualMappingRepository).findRepairManualIndirectIdByAsid(Arrays.asList(invalidAsid.split(",")));
        Assert.assertNotNull(actualIndirectRepairManualIdsForAsid);
        Assert.assertEquals(0, actualIndirectRepairManualIdsForAsid.size());
    }


    private List<RepairManualMapping> getRepairManualMappingsFromRepairManualId(List<String> rlId) {
        final List<RepairManualMapping> repairManualMappings = new ArrayList<>();
        for (String id : rlId) {
            repairManualMappings.add(new RepairManualMapping().withRepairManualId(id));
        }
        return repairManualMappings;
    }


    @Test
    public void getWireDiagramIdForAsid_Positive_shouldReturnMultipleWireDiagramIds() {
        final String asid = "1234,1235";
        final List<String> slpIds = new ArrayList<>();
        slpIds.add("4321-000");
        slpIds.add("1234-000");
        final List<SlpEboMapping> SLPEBOMappings = getWireDiagramMappingsFromWireDiagramId(slpIds);
        Mockito.when(slpEboMappingRepository.findAllByAsidIn(Arrays.asList(asid.split(",")))).thenReturn(SLPEBOMappings);

        List<String> responseWireDiagramIdList = reverseMappingService.getMlCodeForAsid(asid);

        Assert.assertEquals(slpIds.size(), responseWireDiagramIdList.size());
        Assert.assertTrue(slpIds.contains(responseWireDiagramIdList.get(0)));
        Assert.assertTrue(slpIds.contains(responseWireDiagramIdList.get(1)));
    }

    @Test
    public void getWireDiagramIdForASID_Negative_ShouldReturnEmptyAsidList_IfWireDiagramIdIsInvalid() throws Exception {

        final String invalidAsid = "abcd-sdf,poiu-qwer";
        final List<String> emptyWireDiagramIdList = new ArrayList<>();
        final List<SlpEboMapping> SLPEBOMappings = getWireDiagramMappingsFromWireDiagramId(emptyWireDiagramIdList);

        Mockito.when(slpEboMappingRepository.findAllByAsidIn(Arrays.asList(invalidAsid.split(",")))).thenReturn(SLPEBOMappings);

        List<String> responseAsidList = reverseMappingService.getMlCodeForAsid(invalidAsid);

        Assert.assertEquals(emptyWireDiagramIdList.size(), responseAsidList.size());
    }

    private List<SlpEboMapping> getWireDiagramMappingsFromWireDiagramId(List<String> slpId) {
        final List<SlpEboMapping> slpEboMappings = new ArrayList<>();
        for (String id : slpId) {
            slpEboMappings.add(SlpEboMapping.builder().mlCode(id).build());
        }
        return slpEboMappings;
    }
}
