package com.vwits.asid.controller;

import com.vwits.asid.service.ReverseMappingService;
import com.vwits.asid.utility.entity.Scope;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

@RunWith(MockitoJUnitRunner.class)
public class ReverseMappingControllerTest {

    @InjectMocks
    ReverseMappingController reverseMappingController;

    @Mock
    ReverseMappingService reverseMappingService;

    @Test
    public void getLaborTimeIdForAsid_itShouldReturnAtLeastOneLaborTimeId_withStatus200_whenAsidIDisValid()  {
        final ArrayList<String> laborTimeId = new ArrayList<>();
        laborTimeId.add("4321-000");
        laborTimeId.add("1234-000");
        final String asid = "1234";

        Mockito.when(reverseMappingService.getLaborTimeIdForAsid(asid)).thenReturn(laborTimeId);

        final ResponseEntity<Object> laborTimeIds = reverseMappingController.getLaborTimeIdFromAsid(asid);

        Assert.assertEquals(laborTimeId, laborTimeIds.getBody());
        Assert.assertEquals(HttpStatus.OK, laborTimeIds.getStatusCode());
    }

    @Test
    public void getAsidFromLaborTimeId_itShouldReturnStatus204_whenLaborTimeIDisInvalid(){
        final String asidId_whichHasNoLaborTimeId = "1234";
        final ArrayList<String> emptyAsidList = new ArrayList<>();
        Mockito.when(reverseMappingService.getLaborTimeIdForAsid(asidId_whichHasNoLaborTimeId)).thenReturn(emptyAsidList);

        ResponseEntity<Object> emptyAsid = reverseMappingController.getLaborTimeIdFromAsid(asidId_whichHasNoLaborTimeId);

        Assert.assertEquals(HttpStatus.NO_CONTENT, emptyAsid.getStatusCode());
    }

    @Test
    public void getRepairManualIdForAsid_itShouldReturnAtLeastOneRepairManualId_withStatus200_whenASIDisValid()  {
        final ArrayList<String> repairManualIdList = new ArrayList<>();
        repairManualIdList.add("4321-000");
        repairManualIdList.add("1234-000");
        final String asid = "1234";

        Mockito.when(reverseMappingService.getRepairManualIdsForAsid(asid, Scope.DIRECT)).thenReturn(repairManualIdList);

        final ResponseEntity<Object> repairManualIds = reverseMappingController.getRepairManualIdFromAsid(asid, Scope.DIRECT.getValue());

        Assert.assertEquals(repairManualIdList, repairManualIds.getBody());
        Assert.assertEquals(HttpStatus.OK, repairManualIds.getStatusCode());
    }

    @Test
    public void getAsidFromRepairManualId_itShouldReturnStatus204_whenRepairManualIDisInvalid() {
        final String asidId_whichHasNoRepairManualId = "1234";
        final ArrayList<String> emptyAsidList = new ArrayList<>();
        Mockito.when(reverseMappingService.getRepairManualIdsForAsid(asidId_whichHasNoRepairManualId, Scope.DIRECT)).thenReturn(emptyAsidList);

        ResponseEntity<Object> emptyAsid = reverseMappingController.getRepairManualIdFromAsid(asidId_whichHasNoRepairManualId, Scope.DIRECT.getValue());

        Assert.assertEquals(HttpStatus.NO_CONTENT, emptyAsid.getStatusCode());
    }

    @Test
    public void getMlCodeForAsid_itShouldReturnAtLeastOneMlCode_withStatus200_whenASIDisValid()  {
        final ArrayList<String> mlCodeList = new ArrayList<>();
        mlCodeList.add("4321-000");
        mlCodeList.add("1234-000");
        final String asid = "1234";

        Mockito.when(reverseMappingService.getMlCodeForAsid(asid)).thenReturn(mlCodeList);

        final ResponseEntity<Object> actualResponse = reverseMappingController.getMlCodeFromAsid(asid);

        Assert.assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
        Assert.assertEquals(mlCodeList, actualResponse.getBody());
    }

    @Test
    public void getAsidFromMlCode_itShouldReturnStatus204_whenMlCodeIsInvalid() {
        final String asid_whichHasNoMlCode = "1234";
        final ArrayList<String> emptyAsidList = new ArrayList<>();
        Mockito.when(reverseMappingService.getMlCodeForAsid(asid_whichHasNoMlCode)).thenReturn(emptyAsidList);

        ResponseEntity<Object> emptyAsid = reverseMappingController.getMlCodeFromAsid(asid_whichHasNoMlCode);

        Assert.assertEquals(HttpStatus.NO_CONTENT, emptyAsid.getStatusCode());
    }
}
