package com.vwits.asid.controller;

import com.vwits.asid.service.MappingService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MappingControllerTest {

    @Mock
    MappingService mappingService;

    @InjectMocks
    MappingController mappingController;

    @Test
    public void getAsidForRepairManualId_itShouldReturnAtLeastOneASID_withStatus200_whenRLIDisValid() throws Exception {
        final ArrayList<String> asidList = new ArrayList<>();
        asidList.add("4321-000");
        asidList.add("1234-000");
        final String repairManualId = "1234";

        when(mappingService.getASIDForRepairManualID(repairManualId)).thenReturn(asidList);

        final ResponseEntity<Object> asid = mappingController.getASID(repairManualId, "", "");

        assertEquals(asidList, asid.getBody());
        assertEquals(HttpStatus.OK, asid.getStatusCode());
    }

    @Test
    public void getAsidFromRepairManualId_itShouldReturnStatus204_whenRLIDisInvalid() throws Exception {
        final String rlId_whichHasNoAsid = "1234";
        final ArrayList<String> emptyAsidList = new ArrayList<>();
        when(mappingService.getASIDForRepairManualID(rlId_whichHasNoAsid)).thenReturn(emptyAsidList);

        ResponseEntity<Object> emptyAsid = mappingController.getASID(rlId_whichHasNoAsid, "", "");

        assertEquals(HttpStatus.NO_CONTENT, emptyAsid.getStatusCode());
    }

    @Test
    public void getAsidForLaborTimeId_itShouldReturnAtLeastOneASID_withStatus200_whenLTIDisValid() throws Exception {
        final ArrayList<String> asidList = new ArrayList<>();
        asidList.add("4321-000");
        asidList.add("1234-000");
        final String laborTimeId = "1234";

        when(mappingService.getASIDForLaborTimeID(laborTimeId)).thenReturn(asidList);

        final ResponseEntity<Object> asid = mappingController.getASID("", laborTimeId, "");

        assertEquals(asidList, asid.getBody());
        assertEquals(HttpStatus.OK, asid.getStatusCode());
    }

    @Test
    public void getAsidFromLaborTimeId_itShouldReturnStatus204_whenLTIDisInvalid() throws Exception {
        final String ltIdWithoutAsid = "1234";
        final ArrayList<String> emptyAsidList = new ArrayList<>();
        when(mappingService.getASIDForLaborTimeID(ltIdWithoutAsid)).thenReturn(emptyAsidList);

        ResponseEntity<Object> emptyAsid = mappingController.getASID("", ltIdWithoutAsid, "");

        assertEquals(HttpStatus.NO_CONTENT, emptyAsid.getStatusCode());
    }

    @Test
    public void getAsidFromLaborTimeId_itShouldReturnStatus400_whenNoIdIsProvided() throws Exception {

        ResponseEntity<Object> emptyAsid = mappingController.getASID("", "", "");

        assertEquals(HttpStatus.BAD_REQUEST, emptyAsid.getStatusCode());
        assertEquals("atleast one id is required.", emptyAsid.getBody());
    }

    @Test
    public void getAsid_itShouldPreferLaborId_whenBothRepairManualIDAndLaborTimeIdAreGiven() {

        final String ltId = "lt1234";
        final String rlid = "rl1234";
        final ArrayList<String> asidList = new ArrayList<>();
        asidList.add("123-456");

        ResponseEntity<Object> emptyAsid = mappingController.getASID(rlid, ltId, "");

        Mockito.verify(mappingService, Mockito.times(1)).getASIDForLaborTimeID(ltId);

    }

    @Test
    public void getAsidFromMlCode_itShouldReturnAsid_whenValidMlCodeIsPassed() {

        String mlCode = "1234";
        List<String> expectedAsid = new ArrayList<>();
        expectedAsid.add("valid-asid");

        when(mappingService.getASIDForMlCode(mlCode)).thenReturn(expectedAsid);

        ResponseEntity actualResponse = mappingController.getASID("", "", mlCode);

        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
        assertEquals(expectedAsid, actualResponse.getBody());

    }

    @Test
    public void getAsidFromMlCode_itShouldReturnEmptyList_whenInvalidMlCodeIsPassed() {

        String mlCode = "invalidMlCode";
        List<String> expectedAsid = new ArrayList<>();

        when(mappingService.getASIDForMlCode(mlCode)).thenReturn(expectedAsid);

        ResponseEntity actualResponse = mappingController.getASID("", "", mlCode);
        assertEquals(HttpStatus.NO_CONTENT, actualResponse.getStatusCode());

    }
}