package com.vwits.asid.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static com.vwits.asid.controller.CustomErrorController.CUSTOM_ERROR_MESSAGE;
import static com.vwits.asid.utility.constants.MappingServiceConstants.ERROR_PATH;
import static org.junit.Assert.*;


@RunWith(MockitoJUnitRunner.class)
public class CustomErrorControllerTest {

    @InjectMocks
    private CustomErrorController customErrorController;

    @Test
    public void shouldReturnErrorText_whenErrorHandled() {
        assertEquals(CUSTOM_ERROR_MESSAGE, customErrorController.handleError());
    }

    @Test
    public void shouldReturnErrorPathUrl_whenErrorOccurred() {
        assertEquals(ERROR_PATH, customErrorController.getErrorPath());
    }
}