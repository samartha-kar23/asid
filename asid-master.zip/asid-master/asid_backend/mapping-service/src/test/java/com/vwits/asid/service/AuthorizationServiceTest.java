package com.vwits.asid.service;

import com.vwits.asid.utility.testutils.reflectionutil.ReflectionUtilsForTesting;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AuthorizationServiceTest {

    @InjectMocks
    private AuthorizationService authorizationService;

    @Mock
    private RestTemplate restTemplate;

    private UriComponentsBuilder builder;

    @Before
    public void setUp() {
        String authServiceUrl = "http://dummy_url";
        ReflectionUtilsForTesting.injectAnyField(authorizationService, "authServiceUrl", String.class, authServiceUrl);
        builder = UriComponentsBuilder.fromHttpUrl(authServiceUrl);
    }

    @Test
    public void isUserAuthorized_shouldReturnTrue_whenEmailIdHasAdminRole() {
        String authorizedEmailId = "authorized@email.id";
        builder.queryParam("emailId", authorizedEmailId);
        when(restTemplate.exchange(eq(builder.build().toUriString()), eq(HttpMethod.GET), any(HttpEntity.class), eq(Boolean.class))).thenReturn(ResponseEntity.ok(true));

        assertTrue(authorizationService.isUserAuthorized(authorizedEmailId));
    }

    @Test
    public void isUserAuthorized_shouldReturnFalse_whenEmailIdHasNoRole() {
        String normalEmailId = "NormalEmailId";
        builder.queryParam("emailId", normalEmailId);
        when(restTemplate.exchange(eq(builder.build().toUriString()), eq(HttpMethod.GET), any(HttpEntity.class), eq(Boolean.class))).thenReturn(ResponseEntity.ok(false));

        assertFalse(authorizationService.isUserAuthorized(normalEmailId));
    }

    @Test
    public void isUserAuthorized_shouldReturnFalse_whenAuthServiceIsNotAccessible() {
        String normalEmailId = "NormalEmailId";
        builder.queryParam("emailId", normalEmailId);
        when(restTemplate.exchange(eq(builder.build().toUriString()), eq(HttpMethod.GET), any(HttpEntity.class), eq(Boolean.class))).thenThrow(new RuntimeException("URL is not accessible"));

        assertFalse(authorizationService.isUserAuthorized(normalEmailId));
    }
}