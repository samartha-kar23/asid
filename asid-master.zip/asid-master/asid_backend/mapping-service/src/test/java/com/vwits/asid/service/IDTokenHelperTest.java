package com.vwits.asid.service;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import javax.servlet.http.Cookie;

import static org.junit.Assert.assertEquals;


public class IDTokenHelperTest {

    private IDTokenHelper idTokenHelper;

    private MockHttpServletRequest mockHttpServletRequest;

    private static final String TEST_EMAIL = "sagar@vw-dilab.com";

    private static final String EXPIRED_JWT_TOKEN_OF_EMAIL = "eyJraWQiOiI0MjU3YzI3MjJlODE3NDZjIiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiMTNPSUNOendZRjFHeUs0cnVBTXRrZyIsInN1YiI6IjZlMWM5ZjI2LTdhMDgtNDg2MC04NDgyLWUyN2JhOTE0MDJkYSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJodHRwczpcL1wvaWRlbnRpdHktc2FuZGJveC52d2dyb3VwLmlvIiwianR0IjoiaWRfdG9rZW4iLCJsZWUiOlsiVk9MS1NXQUdFTiJdLCJhdWQiOiJkNDkxMWMwNi1jZmUxLTRkYjItOTIzZC0xODkwNjU5ODBiZWRAYXBwc192dy1kaWxhYl9jb20iLCJhY3IiOiJodHRwczpcL1wvaWRlbnRpdHktc2FuZGJveC52d2dyb3VwLmlvXC9hc3N1cmFuY2VcL2xvYS0yIiwidXBkYXRlZF9hdCI6MTQ5MjA3MDcxNDEzNywiYWF0IjoiaWRlbnRpdHlraXQiLCJleHAiOjE1NDgyNDA0NzUsImlhdCI6MTU0ODIzNjg3NSwianRpIjoiZDQwNmYxNjQtMTdjOS00ZTlmLWE1NDUtNzNhMDU5MmEzYjNlIiwiZW1haWwiOiJzYWdhckB2dy1kaWxhYi5jb20ifQ.VbVtUFbTb0A6zYMbIJRzGhl_az4NoKBWvPWK6Uf9ctff4ItnSOswH50BrRz6o9QeXK1c0PCJFrrl9IOAN7o8SI4XZiwx4ZUHS6DJCU-HTwo-1JrCVmCq1t8Vo3ZAXOXN-yHmMw_eGT5uQWkWEXwHTeZqAlyoQ0WO83IsG7ir2RywXZe4_0DVNuTwYuBsqp4OcEThKENvaR49TQnGJ2Qb_pEMS3xzGy0fLy-vNvGn9ZI_oQXfkdaiHT1dKyMCFPOJ7b8cyD9aoC4I80qW6hLZ-OMsVwBZGlSTufpaa6bvs-s7z99j88iYiL4LMpIoeb1xo1q-HvsJe91yoOFn0UMi4D6MITLqzY7jI3rAnX2fEM6wBGxqFUlCO8HDppo11LMsm01IrHXUq2yET-2g2TmZXO6lcoeSqZKybTO5Gmr05qeU-S5DYUBPf0TlQrU2pJSUOOCm2mYJqKK2vzOR1Tu-bWxun5RF2qKErCWsyekRIDahV87icxB8-cGkHNAKfF3Q92pknm7ZyxRol2K6SYq6uv5Di_Vd220Gs0SUREvhGLuizwK0qs4ZIiMSjgPQSYsZG5EZHZvaPIq6U7dSSyar3vH8MSViW3Tovp5UoDg2oW-nild_svRDUztxUkYo0rBUtgLtAaX1qFsD47UGJHPbkYQzcbR1X9Ylr0l8bXUqsl4";

    @Before
    public void setUp() {
        idTokenHelper = new IDTokenHelper();
        mockHttpServletRequest = new MockHttpServletRequest();
    }

    @Test
    public void getValidEmailId_FromRequestCookie() {
        // given:
        final Cookie cookie = new Cookie("id-token", EXPIRED_JWT_TOKEN_OF_EMAIL);
        mockHttpServletRequest.setCookies(cookie);

        // when:
        String result = idTokenHelper.getEmail(mockHttpServletRequest);

        // then:
        assertEquals(TEST_EMAIL, result);
    }

    @Test
    public void getEmptyEmailId_FromCookie_whenEmailIsNotExtractedFromCookie() {
        // given:
        final Cookie cookie1 = new Cookie("id-token", "InvalidToken");
        mockHttpServletRequest.setCookies(cookie1);

        // when:
        final String actualEmail = idTokenHelper.getEmail(mockHttpServletRequest);

        // then:
        assertEquals("", actualEmail);
    }

    @Test
    public void getEmptyEmailId_whenCookiesAreNotPresentInRequest() {
        final String actualEmail = idTokenHelper.getEmail(mockHttpServletRequest);
        assertEquals("", actualEmail);
    }
}