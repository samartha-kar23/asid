package com.vwits.asid.service;

import com.vwits.asid.entity.LaborTimeMapping;
import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.entity.RepairManualMappingDTO;
import com.vwits.asid.exception.DuplicateRecordException;
import com.vwits.asid.exception.InvalidLengthException;
import com.vwits.asid.repository.LaborTimeMappingRepository;
import com.vwits.asid.repository.RepairManualDirectMappingRepository;
import com.vwits.asid.repository.SlpEboMappingRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MappingServiceTest {

    @Mock
    RepairManualDirectMappingRepository repairManualDirectMappingRepository;

    @Mock
    LaborTimeMappingRepository laborTimeMappingRepository;

    @Mock
    SlpEboMappingRepository slpEboMappingRepository;

    @InjectMocks
    MappingService mappingService;


    @Test
    public void getASID_Positive_shouldReturnMultipleASIDs() {
        final String repairManualId = "1234";


        final List<String> asidList = new ArrayList<>();
        asidList.add("4321-000");
        asidList.add("1234-000");

        Mockito.when(repairManualDirectMappingRepository.findDistinctAsidByRepairManualIdIn(Arrays.asList(repairManualId))).thenReturn(asidList);

        List<String> responseAsidList = mappingService.getASIDForRepairManualID(repairManualId);

        Assert.assertEquals(asidList.size(), responseAsidList.size());
        assertTrue(asidList.contains(responseAsidList.get(0)));
        assertTrue(asidList.contains(responseAsidList.get(1)));
    }

    @Test
    public void getASID_whenMultipleRLIdProvided_shouldReturnMultipleASIDs() {
        final String repairManualId = "1234,9876";

        ArrayList repairManualIds = new ArrayList();
        repairManualIds.add("1234");
        repairManualIds.add("9876");


        final List<String> asidList = new ArrayList<>();
        asidList.add("4321-000");
        asidList.add("1234-000");

        asidList.add("9876-000");
        asidList.add("6789-000");

        Mockito.when(repairManualDirectMappingRepository.findDistinctAsidByRepairManualIdIn(repairManualIds)).thenReturn(asidList);

        List<String> responseAsidList = mappingService.getASIDForRepairManualID(repairManualId);

        Assert.assertEquals(asidList.size(), responseAsidList.size());
        assertTrue(asidList.contains(responseAsidList.get(0)));
        assertTrue(asidList.contains(responseAsidList.get(1)));
    }

//    private List<String> getRlMappingsFromAsid(List<String> asid) {
//        final List<RepairManualMapping> rlMapping = new ArrayList<>();
//        for (String id : asid) {
//            rlMapping.add(new RepairManualMapping().withAsid(id));
//        }
//        return rlMapping;
//    }

    @Test
    public void getASID_Positive_ShouldReturnEmptyASIDList_IfNotFound() throws Exception {

        final String validRepairManualId = "abcd";
        final List<String> emptyAsidList = new ArrayList<>();

        Mockito.when(repairManualDirectMappingRepository.findDistinctAsidByRepairManualIdIn(Arrays.asList(validRepairManualId))).thenReturn(emptyAsidList);

        List<String> responseAsidList = mappingService.getASIDForRepairManualID(validRepairManualId);

        Assert.assertEquals(emptyAsidList.size(), responseAsidList.size());
    }

    @Test
    public void getASID_Negative_ShouldReturnEmptyAsidList_IfRepairManualIdIsInvalid() throws Exception {

        final String invalidRepairManualId = "abcd-sdf";
        final List<String> emptyAsidList = new ArrayList<>();


        Mockito.when(repairManualDirectMappingRepository.findDistinctAsidByRepairManualIdIn(Arrays.asList(invalidRepairManualId))).thenReturn(emptyAsidList);

        List<String> responseAsidList = mappingService.getASIDForRepairManualID(invalidRepairManualId);

        Assert.assertEquals(emptyAsidList.size(), responseAsidList.size());
    }

    @Test
    public void getASIDForLaborTimeID_shouldReturnAtLeastOneASIDs_WhenValidLaborID() {
        final String laborTimeID = "123456";

        final List<String> asidList = new ArrayList<>();
        asidList.add("4321-000");
        asidList.add("1234-000");

        final List<LaborTimeMapping> laborTimeMapping = getLTMappingsFromAsid(asidList);
        Mockito.when(laborTimeMappingRepository.findAllByLaborTimeId(laborTimeID)).thenReturn(laborTimeMapping);

        List<String> responseAsidList = mappingService.getASIDForLaborTimeID(laborTimeID);

        assertEquals(asidList.size(), responseAsidList.size());
        assertTrue(asidList.contains(responseAsidList.get(0)));
        assertTrue(asidList.contains(responseAsidList.get(1)));
    }

    @Test
    public void getASIDsForMultipleLTIDs_shouldReturnAtLeastOneASIDs_WhenValidLaborIDsProvided() {
        final String laborTimeID = "123456,789101";
        List<String> lTIDs = new ArrayList<>();
        lTIDs.add("123456");
        lTIDs.add("789101");

        final List<String> asidList1 = new ArrayList<>();
        asidList1.add("4321-000");
        asidList1.add("1234-000");

        final List<String> asidList2 = new ArrayList<>();
        asidList2.add("43215-000");
        asidList2.add("12345-000");

        final List<LaborTimeMapping> laborTimeMappings1 = new ArrayList<>();
        final List<LaborTimeMapping> laborTimeMappings2 = new ArrayList<>();
        laborTimeMappings1.addAll(getLTMappingsFromAsid(asidList1));
        laborTimeMappings2.addAll(getLTMappingsFromAsid(asidList2));

        Mockito.when(laborTimeMappingRepository.findAllByLaborTimeId(lTIDs.get(0))).thenReturn(laborTimeMappings1);
        Mockito.when(laborTimeMappingRepository.findAllByLaborTimeId(lTIDs.get(1))).thenReturn(laborTimeMappings2);

        List<String> responseAsidList = mappingService.getASIDForLaborTimeID(laborTimeID);

        assertEquals(asidList2.size() + asidList1.size(), responseAsidList.size());
        assertTrue(asidList1.contains(responseAsidList.get(0)));
        assertTrue(asidList1.contains(responseAsidList.get(1)));
        assertTrue(asidList2.contains(responseAsidList.get(2)));
        assertTrue(asidList2.contains(responseAsidList.get(3)));
    }

    @Test
    public void getASIDForLTID_shouldSearchWith6DigitsTrimmedLTID_WhenLTIDLengthIsGreaterThan6Digits() {

        final String laborTimeID = "12345678";
        final String trimmedLTID = "123456";
        final String asid = "4321-000";


        final List<String> asidList = new ArrayList<>();
        asidList.add(asid);

        final List<LaborTimeMapping> laborTimeMapping = getLTMappingsFromAsid(asidList);

        when(laborTimeMappingRepository.findAllByLaborTimeId(trimmedLTID)).thenReturn(laborTimeMapping);
        List<String> responseAsidList = mappingService.getASIDForLaborTimeID(laborTimeID);

        verify(laborTimeMappingRepository).findAllByLaborTimeId(trimmedLTID);
        assertEquals(asid, responseAsidList.get(0));

    }

    @Test
    public void getASIDForLTID_shouldSearchWith4DigitsTrimmedLTID_WhenLTIDLengthIsGreaterThan6DigitsAndNoASIDFor6DigitsFound() {

        final String laborTimeID = "12345678";
        final String trimmed6DigitLTID = "123456";
        final String trimmed4DigitLTID = "1234";
        final String asid = "4321-000";


        final List<String> asidList = new ArrayList<>();
        asidList.add(asid);

        final List<LaborTimeMapping> laborTimeMapping = getLTMappingsFromAsid(asidList);

        when(laborTimeMappingRepository.findAllByLaborTimeId(trimmed6DigitLTID)).thenReturn(new ArrayList<>());
        when(laborTimeMappingRepository.findAllByLaborTimeId(trimmed4DigitLTID)).thenReturn(laborTimeMapping);
        List<String> responseAsidList = mappingService.getASIDForLaborTimeID(laborTimeID);

        verify(laborTimeMappingRepository).findAllByLaborTimeId(trimmed6DigitLTID);
        verify(laborTimeMappingRepository).findAllByLaborTimeId(trimmed4DigitLTID);
        assertEquals(asid, responseAsidList.get(0));

    }

    @Test
    public void getASIDForLTID_shouldSearchWith4DigitsTrimmedLTID_WhenLTIDLengthIsGreaterThan3DigitsAndLessThan6Digits() {

        final String laborTimeID = "12345";
        final String trimmed4DigitLTID = "1234";
        final String asid = "4321-000";

        final List<String> asidList = new ArrayList<>();
        asidList.add(asid);

        final List<LaborTimeMapping> laborTimeMapping = getLTMappingsFromAsid(asidList);

        when(laborTimeMappingRepository.findAllByLaborTimeId(trimmed4DigitLTID)).thenReturn(laborTimeMapping);
        List<String> responseAsidList = mappingService.getASIDForLaborTimeID(laborTimeID);

        verify(laborTimeMappingRepository).findAllByLaborTimeId(trimmed4DigitLTID);
        assertEquals(asid, responseAsidList.get(0));

    }

    private List<LaborTimeMapping> getLTMappingsFromAsid(List<String> asid) {
        final List<LaborTimeMapping> laborTimeMappings = new ArrayList<>();
        for (String id : asid) {
            laborTimeMappings.add(new LaborTimeMapping().withAsid(id));
        }
        return laborTimeMappings;
    }

    @Test
    public void getASIDForLaborTimeID_Positive_ShouldReturnEmptyASIDList_IfNotFound() throws Exception {

        final String validLaborTimeId = "abcdef";
        final List<String> emptyAsidList = new ArrayList<>();
        final List<LaborTimeMapping> laborTimeMappings = getLTMappingsFromAsid(emptyAsidList);
        Mockito.when(laborTimeMappingRepository.findAllByLaborTimeId(validLaborTimeId)).thenReturn(laborTimeMappings);

        List<String> responseAsidList = mappingService.getASIDForLaborTimeID(validLaborTimeId);

        verify(laborTimeMappingRepository).findAllByLaborTimeId(validLaborTimeId);
        Assert.assertEquals(emptyAsidList.size(), responseAsidList.size());
    }

    @Test
    public void getASIDForLaborTimeID_Negative_ShouldReturnEmptyAsidList_IfRepairManualIdIsInvalid() throws Exception {

        final String invalidLaborTimeId = "abcd-sdf";
        final List<String> emptyAsidList = new ArrayList<>();
        final List<LaborTimeMapping> laborTimeMapping = getLTMappingsFromAsid(emptyAsidList);

        Mockito.when(laborTimeMappingRepository.findAllByLaborTimeId(invalidLaborTimeId)).thenReturn(laborTimeMapping);

        List<String> responseAsidList = mappingService.getASIDForLaborTimeID(invalidLaborTimeId);

        Assert.assertEquals(emptyAsidList.size(), responseAsidList.size());
    }

    @Test
    public void getAllRepairManualMapping_itShouldReturnListOfRepairManualMapping() {

        ArrayList<RepairManualMapping> dummyRepairManualMappingList = new ArrayList<>();
        dummyRepairManualMappingList.add(new RepairManualMapping(1l, "asid-1", "rlid-1"));

        when(repairManualDirectMappingRepository.findAll()).thenReturn(dummyRepairManualMappingList);

        List<RepairManualMapping> actualAllRepairManualMapping = mappingService.getAllRepairManualMapping();

        assertEquals(dummyRepairManualMappingList.size(), actualAllRepairManualMapping.size());
        assertEquals(dummyRepairManualMappingList.get(0).getAsid(), actualAllRepairManualMapping.get(0).getAsid());
        assertEquals(dummyRepairManualMappingList.get(0).getRepairManualId(), actualAllRepairManualMapping.get(0).getRepairManualId());
    }

    @Test
    public void addRlMapping_itShouldAddNewRLMappingData_whenASIDAndRLIDProvided() {
        String newAsid = "ASID-1";
        String newRlId = "RLID-1";

        RepairManualMapping dummyRepairManualMapping = new RepairManualMapping().withAsid(newAsid).withRepairManualId(newRlId);
        RepairManualMappingDTO dummyRepairManualMappingDTO = new RepairManualMappingDTO().withAsid(newAsid).withRepairManualId(newRlId);

        when(repairManualDirectMappingRepository.save(dummyRepairManualMapping)).thenReturn(dummyRepairManualMapping);

        RepairManualMapping repairManualMapping = mappingService.addRlMapping(dummyRepairManualMappingDTO);

        Assert.assertEquals(dummyRepairManualMapping.getAsid(), repairManualMapping.getAsid());
        Assert.assertEquals(dummyRepairManualMapping.getRepairManualId(), repairManualMapping.getRepairManualId());

    }

    @Test
    public void deleteRlMapping_itShouldMakeACallToRepositoryToDelete_whenAsidAndRIdIsProvided() {
        String existingAsid = "ASID";
        String existingRlId = "RLID";

        mappingService.deleteRepairManualMapping(existingAsid, existingRlId);

        verify(repairManualDirectMappingRepository, times(1)).deleteByAsidAndRepairManualId(anyString(), anyString());
    }

    @Test
    public void itShouldNotAllowAddingIllegalCharactersInASIDAndRlidAndReturnErrorMessage() {
        String newAsid = "ASID-1";
        String newRlId = "RLID-1";
        RepairManualMappingDTO repairManualMapping = new RepairManualMappingDTO().withAsid(newAsid).withRepairManualId(newRlId);

        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withAsid("asid*"));
        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withAsid("asid%"));
        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withAsid("asid'"));
        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withAsid("asid "));
        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withRepairManualId("rlid*"));
        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withRepairManualId("rlid%"));
        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withRepairManualId("rlid'"));
        expectIllegalArgumentExceptionWhileAdding(repairManualMapping.withRepairManualId("rlid "));

    }

    @Test
    public void addRLMapping_itShouldThrowTooManyCharactersException_whenLengthOfRLIdOrAsidExceeds15Chars() {
        String newAsid = "ASID";
        String newRlId = "RLID";
        RepairManualMappingDTO repairManualMapping = new RepairManualMappingDTO().withAsid(newAsid).withRepairManualId(newRlId);

        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withAsid("dummy-asid-0123456789"));
        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withRepairManualId("dummy-rlid-0123456789"));
        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withAsid("0123456789abcde"));
        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withRepairManualId("0123456789abcde"));
    }

    @Test
    public void addRLMapping_itShouldThrowTooManyCharactersException_whenLengthOfRLIdOrAsidIsZero() {
        String newAsid = "ASID";
        String newRlId = "RLID";
        RepairManualMappingDTO repairManualMapping = new RepairManualMappingDTO().withAsid(newAsid).withRepairManualId(newRlId);

        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withAsid(""));
        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withRepairManualId(""));
        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withAsid("").withRepairManualId(""));
    }

    @Test
    public void addRLMapping_itShouldThrowTooManyCharactersException_whenLengthOfRLIdOrAsidIsNull() {
        RepairManualMappingDTO repairManualMapping = new RepairManualMappingDTO();

        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withAsid("asid"));
        expectInvalidLengthExceptionWhileAdding(repairManualMapping.withRepairManualId("rlid"));
        expectInvalidLengthExceptionWhileAdding(repairManualMapping);
    }

    @Test
    public void addRlMapping_itShouldReturnDuplicateDataMessage_whenExistingASIDAndRLIDProvided() {
        String existingAsid = "ASID";
        String existingRlId = "RLID";

        RepairManualMapping dummyMappingData = new RepairManualMapping().withAsid(existingAsid).withRepairManualId(existingRlId);
        RepairManualMappingDTO repairManualMappingDTO = new RepairManualMappingDTO().withAsid(existingAsid).withRepairManualId(existingRlId);

        when(repairManualDirectMappingRepository.findByAsidAndRepairManualId(existingAsid, existingRlId)).
                thenReturn(dummyMappingData);

        try {
            mappingService.addRlMapping(repairManualMappingDTO);
            fail();
        } catch (DuplicateRecordException e) {
            assertEquals(MappingService.MESSAGE_WHEN_ADDING_DUPLICATE_RECORDS, e.getMessage());
        }

    }

    @Test
    public void getASIDList_itShouldReturnAsid_whenValidMLCodeProvided() {
        String existingMlCode = "1234";
        String asid1 = "1234-abcd";
        String asid2 = "1234-efgh";
        List<String> expectedAsidList = Arrays.asList(asid1,asid2);
        when(slpEboMappingRepository.findDistinctAsidByMlCodeIn(Arrays.asList(existingMlCode))).thenReturn(expectedAsidList);

        List<String> actualAsidList = mappingService.getASIDForMlCode(existingMlCode);

        assertEquals(Arrays.asList(asid1,asid2), actualAsidList);
        assertEquals(2, actualAsidList.size());
    }

    @Test
    public void getASIDList_itShouldReturnAsid_whenValidMLCodesProvided() {
        String existingMlCode = "1234,4321";
        List<String> existingMlCodeList = new ArrayList<>();
        existingMlCodeList.add("1234");
        existingMlCodeList.add("4321");
        String asid1 = "1234-abcd";
        String asid2 = "1234-efgh";
        String asid3 = "1234-abcd";
        String asid4 = "4321-efgh";
        /*List<String> expectedAsidList = new ArrayList<>();
        expectedAsidList.add(asid1);
        expectedAsidList.add(asid2);
        expectedAsidList.add(asid3);
        expectedAsidList.add(asid4);*/

        List<String> expectedSlpMappingList = Arrays.asList(asid1,asid2,asid4);
        when(slpEboMappingRepository.findDistinctAsidByMlCodeIn(existingMlCodeList)).thenReturn(expectedSlpMappingList);

        List<String> actualAsidList = mappingService.getASIDForMlCode(existingMlCode);

//        assertEquals(3, actualAsidList.size());
//        assertEquals(expectedAsidList, actualAsidList);
    }
    private void expectInvalidLengthExceptionWhileAdding(RepairManualMappingDTO repairManualMappingDTO) {
        try {
            mappingService.addRlMapping(repairManualMappingDTO);
            fail();
        } catch (InvalidLengthException e) {
            assertEquals(MappingService.MESSAGE_WHEN_ID_LENGTH_INVALID, e.getMessage());
        }
    }

    private void expectIllegalArgumentExceptionWhileAdding(RepairManualMappingDTO repairManualMapping) {
        try {
            mappingService.addRlMapping(repairManualMapping);
            fail();
        } catch (IllegalArgumentException e) {
            assertEquals(MappingService.MESSAGE_WHILE_ADDING_ILLEGAL_CHARS, e.getMessage());
        }
    }
}