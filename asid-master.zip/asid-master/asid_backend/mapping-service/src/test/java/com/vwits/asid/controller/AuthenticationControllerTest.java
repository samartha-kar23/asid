package com.vwits.asid.controller;

import com.vwits.asid.service.IDTokenHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AuthenticationControllerTest {

    @InjectMocks
    private AuthenticationController authenticationController;

    @Mock
    private IDTokenHelper idTokenHelper;

    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private MockHttpSession httpSession;
    private Cookie cookie;

    @Before
    public void setUp() {
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        httpSession = new MockHttpSession();
        request.setSession(httpSession);
    }

    @Test
    public void authCallBack_ShouldReturn_ModelAndView() {
        assertTrue(authenticationController.authCallBack() instanceof ModelAndView);
    }

    @Test
    public void authCallBack() {
        assertTrue(authenticationController.authCallBackError(response) instanceof ResponseEntity);
    }

    @Test
    public void getLoggedInUserDetails_shouldReturnOk_whenValidTokenPassed() {
        cookie = new Cookie("id-token", "valid-token");
        request.setCookies(cookie);
        when(idTokenHelper.getEmail(request)).thenReturn("valid-email");
        final ResponseEntity responseEntity = authenticationController.getLoggedInUserDetails(request);
        assertEquals("valid-email", responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    public void getLoggedInUserDetails_shouldReturnOk_whenInValidTokenPassed() {
        cookie = new Cookie("id-token", "invalid-token");
        request.setCookies(cookie);
        final String invalidEmailId = "";
        when(idTokenHelper.getEmail(request)).thenReturn(invalidEmailId);
        final ResponseEntity responseEntity = authenticationController.getLoggedInUserDetails(request);
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
    }

    @Test
    public void logout_shouldLogout() throws Exception {
        String idToken = "idToken";
        cookie = new Cookie("id-token", idToken);
        request.setCookies(cookie);
        authenticationController.setLogoutSuccessRedirect("");
        authenticationController.setIssuer("https://identity-dummy-sandbox.vwgroup.io");
        when(idTokenHelper.readToken(request)).thenReturn(idToken);
        authenticationController.logout(request, response);
        assertTrue(httpSession.isInvalid());
        assertTrue(response.getRedirectedUrl().contains("https://identity-dummy-sandbox.vwgroup.io"));
    }

    @Test
    public void logoutSuccessFullAuthCallBack_shouldReturnTrue() {
        assertTrue(authenticationController.logoutSuccessFull());
    }
}
