package com.vwits.asid;

import com.vwits.asid.utility.testutils.IntegTestHelper;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import javax.servlet.http.Cookie;

import static com.vwits.asid.utility.constants.MappingServiceConstants.LOGGEDIN_USER_DETAILS_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.LOGOUT_USER;
import static com.vwits.asid.utility.constants.MappingServiceConstants.SUCCESSFUL_LOGOUT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
@ActiveProfiles(profiles = {"adminIntegTest"})
public class AuthenticationControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Value("${admin.pageUrl}")
    private String uiHome;

    @Value("${logoutsuccess.redirectUrl}")
    private String logoutSuccessRedirect;

    private static final String TEST_EMAIL = "sagar@vw-dilab.com";

    private static final String EXPIRED_JWT_TOKEN_OF_EMAIL = "eyJraWQiOiI0MjU3YzI3MjJlODE3NDZjIiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiMTNPSUNOendZRjFHeUs0cnVBTXRrZyIsInN1YiI6IjZlMWM5ZjI2LTdhMDgtNDg2MC04NDgyLWUyN2JhOTE0MDJkYSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJodHRwczpcL1wvaWRlbnRpdHktc2FuZGJveC52d2dyb3VwLmlvIiwianR0IjoiaWRfdG9rZW4iLCJsZWUiOlsiVk9MS1NXQUdFTiJdLCJhdWQiOiJkNDkxMWMwNi1jZmUxLTRkYjItOTIzZC0xODkwNjU5ODBiZWRAYXBwc192dy1kaWxhYl9jb20iLCJhY3IiOiJodHRwczpcL1wvaWRlbnRpdHktc2FuZGJveC52d2dyb3VwLmlvXC9hc3N1cmFuY2VcL2xvYS0yIiwidXBkYXRlZF9hdCI6MTQ5MjA3MDcxNDEzNywiYWF0IjoiaWRlbnRpdHlraXQiLCJleHAiOjE1NDgyNDA0NzUsImlhdCI6MTU0ODIzNjg3NSwianRpIjoiZDQwNmYxNjQtMTdjOS00ZTlmLWE1NDUtNzNhMDU5MmEzYjNlIiwiZW1haWwiOiJzYWdhckB2dy1kaWxhYi5jb20ifQ.VbVtUFbTb0A6zYMbIJRzGhl_az4NoKBWvPWK6Uf9ctff4ItnSOswH50BrRz6o9QeXK1c0PCJFrrl9IOAN7o8SI4XZiwx4ZUHS6DJCU-HTwo-1JrCVmCq1t8Vo3ZAXOXN-yHmMw_eGT5uQWkWEXwHTeZqAlyoQ0WO83IsG7ir2RywXZe4_0DVNuTwYuBsqp4OcEThKENvaR49TQnGJ2Qb_pEMS3xzGy0fLy-vNvGn9ZI_oQXfkdaiHT1dKyMCFPOJ7b8cyD9aoC4I80qW6hLZ-OMsVwBZGlSTufpaa6bvs-s7z99j88iYiL4LMpIoeb1xo1q-HvsJe91yoOFn0UMi4D6MITLqzY7jI3rAnX2fEM6wBGxqFUlCO8HDppo11LMsm01IrHXUq2yET-2g2TmZXO6lcoeSqZKybTO5Gmr05qeU-S5DYUBPf0TlQrU2pJSUOOCm2mYJqKK2vzOR1Tu-bWxun5RF2qKErCWsyekRIDahV87icxB8-cGkHNAKfF3Q92pknm7ZyxRol2K6SYq6uv5Di_Vd220Gs0SUREvhGLuizwK0qs4ZIiMSjgPQSYsZG5EZHZvaPIq6U7dSSyar3vH8MSViW3Tovp5UoDg2oW-nild_svRDUztxUkYo0rBUtgLtAaX1qFsD47UGJHPbkYQzcbR1X9Ylr0l8bXUqsl4";

    @Test
    public void shouldRedirectToLogoutEndpoint() throws Exception {
        MvcResult mvcResult = mockMvc.perform(get(LOGOUT_USER).cookie(new Cookie[]{new Cookie("id-token", IntegTestHelper.getMockTokenForIdKit())})).andReturn();

        assertNotNull(mvcResult.getResponse().getRedirectedUrl());
        assertTrue(mvcResult.getResponse().getRedirectedUrl().contains(SUCCESSFUL_LOGOUT));
    }

    @Test
    public void logoutSuccessFull_shouldReturnTrue() throws Exception {
        MvcResult result = mockMvc.perform(get(SUCCESSFUL_LOGOUT))
                .andReturn();

        assertEquals("true", result.getResponse().getContentAsString());
    }

    @Test
    public void getLoggedInUserDetails_shouldReturnResponseEntityWithEmailId_whenValidTokenPassed() throws Exception {
        mockMvc.perform(get(LOGGEDIN_USER_DETAILS_PATH)
                .cookie(new Cookie("id-token", EXPIRED_JWT_TOKEN_OF_EMAIL)))
                .andExpect(status().isOk())
                .andExpect(content().string(Matchers.containsString(TEST_EMAIL)));
    }

    @Test
    public void getLoggedInUserDetails_shouldReturnUnAuthorized_whenIdTokenCookieIsNotPresent() throws Exception {
        mockMvc.perform(get(LOGGEDIN_USER_DETAILS_PATH)
                .cookie(new Cookie("dummy-id", EXPIRED_JWT_TOKEN_OF_EMAIL)))
                .andExpect(status().isUnauthorized());
    }
}
