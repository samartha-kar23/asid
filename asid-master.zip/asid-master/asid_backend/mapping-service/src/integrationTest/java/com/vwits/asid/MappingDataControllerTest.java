package com.vwits.asid;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.utility.constants.MappingServiceConstants;
import com.vwits.asid.repository.RepairManualDirectMappingRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static com.vwits.asid.service.MappingService.*;
import static com.vwits.asid.utility.constants.MappingServiceConstants.ADMIN_GET_RL_MAPPING_DATA_CSV_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.ADMIN_RL_MAPPING_ADD_PATH;
import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("adminIntegTest")
@AutoConfigureMockMvc
public class MappingDataControllerTest {

    final String[] asidForRepairManual = {"4321-000"};
    final String repairManualId = "1234";
    @Autowired
    MockMvc mvc;
    @Autowired
    private RepairManualDirectMappingRepository repairManualDirectMappingRepository;

    private ObjectMapper mapper = new ObjectMapper();

    @Test
    public void getMappingDataForRepairManual_itShouldReturnMappingDataInCSVFormat_withStatus200() throws Exception {
        repairManualDirectMappingRepository.save(new RepairManualMapping(1L, asidForRepairManual[0], repairManualId));
        MvcResult mvcResult = mvc.perform(get(ADMIN_GET_RL_MAPPING_DATA_CSV_PATH)
                .contentType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
                .andExpect(status().isOk())
                .andReturn();

        assertTrue(mvcResult.getResponse().getContentAsString().contains(asidForRepairManual[0]));
    }

    @Test
    public void getMappingDataForRepairManual_itShouldReturnNoContent_whenMappingDataDoesNotExist() throws Exception {
        repairManualDirectMappingRepository.deleteAll();
        mvc.perform(get(ADMIN_GET_RL_MAPPING_DATA_CSV_PATH)
                .contentType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
                .andExpect(status().isNoContent());
    }

    @Test
    public void deleteMappingRowForRepairManual_itShouldDeleteARow_whenProvidedWithOneCombinationOfASIDandRLId() throws Exception {
        repairManualDirectMappingRepository.save(new RepairManualMapping(1L, asidForRepairManual[0], repairManualId));

        mvc.perform(delete(MappingServiceConstants.ADMIN_RL_DELETE_PATH + "?asid=" + asidForRepairManual[0] + "&rlid=" + repairManualId))
                .andExpect(status().isNoContent());
    }

    @Test
    public void deleteMappingRowForRepairManual_itShouldNotDeleteARowButStillReturnNoContent_whenProvidedCombinationDoesNotExistInDb() throws Exception {

        mvc.perform(delete(MappingServiceConstants.ADMIN_RL_DELETE_PATH + "?asid=" + asidForRepairManual[0] + "&rlid=" + repairManualId))
                .andExpect(status().isNoContent());
    }


    @Test
    public void deleteMappingRowForRepairManual_itShouldNotProcessRequest_whenMandatoryParamsAreMissing() throws Exception {
        repairManualDirectMappingRepository.save(new RepairManualMapping(1L, asidForRepairManual[0], repairManualId));

        mvc.perform(delete(MappingServiceConstants.ADMIN_RL_DELETE_PATH))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void addRlMapping_itShouldAddNewEntryToRLMapping_whenASIDAndRLIDIsProvided() throws Exception {
        String newAsid = "ASID-1234";
        String newRlId = "RLID-1234";

        String inputMappingData = "{\n" +
                "  \"asid\": \"ASID-1234\",\n" +
                "  \"repairManualId\": \"RLID-1234\"\n" +
                "}";

        MvcResult mvcResult = mvc.perform(post(ADMIN_RL_MAPPING_ADD_PATH).contentType(MediaType.APPLICATION_JSON_VALUE).
                content(inputMappingData)).andReturn();

        RepairManualMapping repairManualMapping = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualMapping.class);

        assertEquals(newAsid, repairManualMapping.getAsid());
        assertEquals(newRlId, repairManualMapping.getRepairManualId());
    }

    @Test
    public void addRlMapping_itShouldGiveErrorMessage_whenASIDOrRlidContainsInvalidChars() throws Exception {

        String inputMappingData = "{\n" +
                "  \"asid\": \"ASID-1234*\",\n" +
                "  \"repairManualId\": \"RLID-1234'\"\n" +
                "}";

        MvcResult mvcResult = mvc.perform(post(ADMIN_RL_MAPPING_ADD_PATH).contentType(MediaType.APPLICATION_JSON_VALUE).
                content(inputMappingData)).andReturn();

        String errorMessage = mvcResult.getResponse().getContentAsString();

        assertEquals(MESSAGE_WHILE_ADDING_ILLEGAL_CHARS, errorMessage);


    }

    @Test
    public void addRlMapping_itShouldGiveErrorMessage_whenTooManyCharsInASIDOrRlid() throws Exception {

        String inputMappingData = "{\n" +
                "  \"asid\": \"dummy-asid-0123456789\",\n" +
                "  \"repairManualId\": \"dummy-rlid-0123456789\"\n" +
                "}";

        MvcResult mvcResult = mvc.perform(post(ADMIN_RL_MAPPING_ADD_PATH).contentType(MediaType.APPLICATION_JSON_VALUE).
                content(inputMappingData)).andReturn();

        String errorMessage = mvcResult.getResponse().getContentAsString();

        assertEquals(MESSAGE_WHEN_ID_LENGTH_INVALID, errorMessage);


    }

    @Test
    public void addRlMapping_itShouldGiveErrorMessage_whenASIDOrRlidCharLengthIsZero() throws Exception {

        String inputMappingData = "{\n" +
                "  \"asid\": \"\",\n" +
                "  \"repairManualId\": \"\"\n" +
                "}";

        MvcResult mvcResult = mvc.perform(post(ADMIN_RL_MAPPING_ADD_PATH).contentType(MediaType.APPLICATION_JSON_VALUE).
                content(inputMappingData)).andReturn();
        String errorMessage = mvcResult.getResponse().getContentAsString();
        assertEquals(MESSAGE_WHEN_ID_LENGTH_INVALID, errorMessage);

    }

    @Test

    public void addRlMapping_itShouldGiveErrorMessage_whenASIDOrRlidCharLengthIsNull() throws Exception {

        String inputMappingData = "{}";

        MvcResult mvcResult = mvc.perform(post(ADMIN_RL_MAPPING_ADD_PATH).contentType(MediaType.APPLICATION_JSON_VALUE).
                content(inputMappingData)).andReturn();

        String errorMessage = mvcResult.getResponse().getContentAsString();
        assertEquals(MESSAGE_WHEN_ID_LENGTH_INVALID, errorMessage);

    }

    @Test
    public void addRlMapping_itShouldGiveErrorMessage_whenASIDAndRlidAlreadyExistInDatabase() throws Exception {
        repairManualDirectMappingRepository.save(new RepairManualMapping(1L, "ASID-1234", "RLID-1234"));

        String inputMappingData = "{\n" +
                "  \"asid\": \"ASID-1234\",\n" +
                "  \"repairManualId\": \"RLID-1234\"\n" +
                "}";

        MvcResult mvcResult = mvc.perform(post(ADMIN_RL_MAPPING_ADD_PATH).contentType(MediaType.APPLICATION_JSON_VALUE).
                content(inputMappingData)).andReturn();

        String errorMessage = mvcResult.getResponse().getContentAsString();
        assertEquals(MESSAGE_WHEN_ADDING_DUPLICATE_RECORDS, errorMessage);

    }
}
