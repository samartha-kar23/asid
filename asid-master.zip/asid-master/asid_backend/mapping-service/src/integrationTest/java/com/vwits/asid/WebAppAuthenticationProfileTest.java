package com.vwits.asid;

import com.vwits.asid.utility.constants.MappingServiceConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static junit.framework.TestCase.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("Auth")
@AutoConfigureMockMvc
public class WebAppAuthenticationProfileTest {
    @Autowired
    MockMvc mockMvc;

    @Test
    public void shouldUseWebAppAuthenticationFilter() throws Exception {
        ResultActions result = mockMvc.perform(get(MappingServiceConstants.ADMIN_GET_ASID_PATH +"?rlid=" + "1234")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is3xxRedirection());
        assertTrue(result.andReturn().getResponse().getRedirectedUrl().contains("https://identity-sandbox.vwgroup.io/oidc/v1/authorize"));

    }
}
