package com.vwits.asid;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.entity.LaborTimeMapping;
import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.entity.SlpEboMapping;
import com.vwits.asid.repository.LaborTimeMappingRepository;
import com.vwits.asid.repository.RepairManualDirectMappingRepository;
import com.vwits.asid.repository.SlpEboMappingRepository;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("NoAuth")
@AutoConfigureMockMvc
public class MappingControllerTest {

    final String[] returnedAsidForRepairManual = {"4321-000"};
    final String[] returnedAsidForLaborTime = {"4321-001"};
    final String[] returnedAsidForMlCode = {"4321-002"};

    final String repairManualId = "1234";
    final String laborTimeId = "123456";
    String mlCode = "valid-mlcode";

    ObjectMapper mapper = new ObjectMapper();

    @Autowired
    MockMvc mvc;
    @Autowired
    private RepairManualDirectMappingRepository mappingRepository;
    @Autowired
    private LaborTimeMappingRepository laborTimeMappingRepository;
    @Autowired
    private SlpEboMappingRepository slpEboMappingRepository;


    @Before
    public void initRepo() {
        mappingRepository.save(new RepairManualMapping(1L, returnedAsidForRepairManual[0], repairManualId));
        laborTimeMappingRepository.save(new LaborTimeMapping(1L, returnedAsidForLaborTime[0], laborTimeId));
        slpEboMappingRepository.save(new SlpEboMapping(1L, returnedAsidForMlCode[0], mlCode));

    }


    @After
    public void tearDown() {
        mappingRepository.deleteAll();
        laborTimeMappingRepository.deleteAll();
        slpEboMappingRepository.deleteAll();
    }

    @Test
    public void getASIDFromRLID_shouldReturnASID_withStatusOk_whenCorrectRLIDisProvided() throws Exception {
        mvc.perform(get("/getasid?rlid=" + repairManualId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(mapper.writeValueAsString(returnedAsidForRepairManual)));

    }

    @Test
    public void getASIDFromRLID_shouldReturnNoASID_withStatusNoContent_whenInCorrectRLIDisProvided() throws Exception {
        mvc.perform(get("/getasid?rlid=dummy")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    public void getASIDFromRLID_shouldReturnStatusBadRequest_whenNoRLIDisProvided() throws Exception {
        MvcResult mvcResult = mvc.perform(get("/getasid")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals("atleast one id is required.", mvcResult.getResponse().getContentAsString());
    }

    @Test
    public void getASIDFromLTID_shouldReturnASID_withStatusOk_whenCorrectLTIDisProvided() throws Exception {
        mvc.perform(get("/getasid?ltid=" + laborTimeId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(mapper.writeValueAsString(returnedAsidForLaborTime)));
    }

    @Test
    public void getASIDFromLTID_shouldReturnNoASID_withStatusNoContent_whenInCorrectLTIDisProvided() throws Exception {
        mvc.perform(get("/getasid?ltid=dummy")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    public void getASIDFromLTID_shouldReturnStatusBadRequest_whenNoLTIDisProvided() throws Exception {
        MvcResult mvcResult = mvc.perform(get("/getasid?ltid=" + laborTimeId + "&rlid=" + repairManualId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(mapper.writeValueAsString(returnedAsidForLaborTime)))
                .andReturn();

        final String contentAsString = mvcResult.getResponse().getContentAsString();
        assertFalse(contentAsString.contains(mapper.writeValueAsString(returnedAsidForRepairManual)));
    }

    @Test
    public void getASIDFromMlCode_shouldReturnASID__withStatusOk_whenCorrectMlCodeIsProvided() throws Exception {
        mvc.perform(get("/getasid?mlcode=" + mlCode)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
//                .andExpect(content().string(mapper.writeValueAsString(returnedAsidForMlCode)));
    }

    @Test
    public void getASIDFromMlCode_shouldNotReturnAsid_withStatusNoContent_whenInCorrectMlCodeIsProvided() throws Exception {
        mvc.perform(get("/getasid?mlcode=dummy")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }
}
