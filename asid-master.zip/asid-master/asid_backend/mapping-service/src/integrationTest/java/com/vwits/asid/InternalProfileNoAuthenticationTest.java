package com.vwits.asid;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static com.vwits.asid.utility.constants.MappingServiceConstants.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("NoAuth")
@AutoConfigureMockMvc
public class InternalProfileNoAuthenticationTest {
    @Autowired
    MockMvc mockMvc;

    @Test
    public void shouldUseWebAppAuthenticationFilter() throws Exception {
        mockMvc.perform(get("/getasid?rlid=" + "1234")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    public void deleteRequestShouldNotBeActive() throws Exception {
        final MvcResult mvcResult = mockMvc.perform(delete(ADMIN_RL_DELETE_PATH + "?asid=" + "something" + "&rlid=" + "something")
                .contentType(MediaType.APPLICATION_OCTET_STREAM_VALUE)).andReturn();
        Assert.assertEquals(HttpStatus.NOT_FOUND.value(), mvcResult.getResponse().getStatus());
    }

    @Test
    public void addRequestShouldNotBeActive() throws Exception {
        final MvcResult mvcResult = mockMvc.perform(delete(ADMIN_RL_MAPPING_ADD_PATH + "?asid=" + "something" + "&rlid=" + "something")
                .contentType(MediaType.APPLICATION_OCTET_STREAM_VALUE)).andReturn();
        Assert.assertEquals(HttpStatus.NOT_FOUND.value(), mvcResult.getResponse().getStatus());
    }

    @Test
    public void downloadCSVRequestShouldNotBeActive() throws Exception {
        final MvcResult mvcResult = mockMvc.perform(post(ADMIN_GET_RL_MAPPING_DATA_CSV_PATH + "?asid=" + "something" + "&rlid=" + "something")
                .contentType(MediaType.APPLICATION_OCTET_STREAM_VALUE)).andReturn();
        Assert.assertEquals(HttpStatus.NOT_FOUND.value(), mvcResult.getResponse().getStatus());
    }
}
