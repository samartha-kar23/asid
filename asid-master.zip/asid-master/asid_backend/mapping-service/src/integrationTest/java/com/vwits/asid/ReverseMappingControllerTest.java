package com.vwits.asid;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.entity.LaborTimeMapping;
import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.entity.RepairManualMappingIndirectLink;
import com.vwits.asid.entity.SlpEboMapping;
import com.vwits.asid.repository.LaborTimeMappingRepository;
import com.vwits.asid.repository.RepairManualDirectMappingRepository;
import com.vwits.asid.repository.RepairManualMappingIndirectLinkRepository;
import com.vwits.asid.repository.SlpEboMappingRepository;
import com.vwits.asid.utility.entity.Scope;
import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static com.vwits.asid.utility.constants.ASIDAppConstants.REVERSE_MAPPING_APOS_ID_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.REVERSE_MAPPING_ML_CODE_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.REVERSE_MAPPING_RL_ID_PATH;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("NoAuth")
@AutoConfigureMockMvc
public class ReverseMappingControllerTest {

    final String[] mlCode = {"1234w"};
    private final String asid = "4321-001";
    private final String invalidAsid = "dummy";
    private final String[] laborTimeId = {"1234l"};
    private final String[] repairManualDirectId = {"direct_rl_1234"};
    private final String[] repairManualIndirectId = {"indirect_rl_1234"};

    ObjectMapper mapper = new ObjectMapper();
    @Autowired
    MockMvc mvc;
    @Autowired
    private LaborTimeMappingRepository laborTimeMappingRepository;
    @Autowired
    private RepairManualDirectMappingRepository repairManualDirectMappingRepository;
    @Autowired
    private RepairManualMappingIndirectLinkRepository repairManualMappingIndirectLinkRepository;

    @Autowired
    private SlpEboMappingRepository slpEboMappingRepository;


    @Before
    public void initRepo() {
        laborTimeMappingRepository.save(new LaborTimeMapping(1L, asid, laborTimeId[0]));
        slpEboMappingRepository.save(new SlpEboMapping(1L, asid, mlCode[0]));
        repairManualDirectMappingRepository.save(new RepairManualMapping(1L, asid, repairManualDirectId[0]));
        repairManualMappingIndirectLinkRepository.save(new RepairManualMappingIndirectLink(1L, asid, repairManualIndirectId[0]));
    }

    @After
    public void tearDown() {
        laborTimeMappingRepository.deleteAll();
        slpEboMappingRepository.deleteAll();
        repairManualDirectMappingRepository.deleteAll();
        repairManualMappingIndirectLinkRepository.deleteAll();
    }

    @Test
    public void getLaborTimeIdFromASID_shouldReturnLaborTimeId_withStatusOk_whenCorrectASIDisProvided() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_APOS_ID_PATH + "?asid=" + asid)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(mapper.writeValueAsString(laborTimeId)))
                .andExpect(status().isOk());

    }

    @Test
    public void getLaborTimeIdFromASID_shouldNotReturnLaborTimeId_withStatusNoContent_whenInCorrectASIDisProvided() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_APOS_ID_PATH + "?asid=" + invalidAsid)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

    }

    @Test
    public void shouldReturnRepairManualIds_withStatusOk_whenCorrectASIDisProvidedWithScope0() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + asid + "&scope=" + Scope.ALL)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(Matchers.containsString(mapper.writeValueAsString(repairManualDirectId[0]))))
                .andExpect(content().string(Matchers.containsString(mapper.writeValueAsString(repairManualIndirectId[0]))))
                .andExpect(status().isOk());

    }

    @Test
    public void shouldReturnRepairManualDirectId_withStatusOk_whenCorrectASIDisProvidedWithScope1() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + asid + "&scope=" + Scope.DIRECT)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(mapper.writeValueAsString(repairManualDirectId)))
                .andExpect(status().isOk());

    }


    @Test
    public void shouldReturnRepairManualIndirectId_withStatusOk_whenCorrectASIDisProvidedWithScope2() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + asid + "&scope=" + Scope.INDIRECT)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(mapper.writeValueAsString(repairManualIndirectId)))
                .andExpect(status().isOk());

    }

    @Test
    public void shouldReturnRepairManualDirectId_withStatusOk_whenCorrectASIDisProvidedWithoutScope() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + asid)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(mapper.writeValueAsString(repairManualDirectId)))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldReturnRepairManuals_withStatusNoContent_whenInvalidASIDisProvidedWithScope0() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + invalidAsid + "&scope=" + Scope.ALL)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

    }

    @Test
    public void shouldReturnRepairManualDirectId_withStatusNoContent_whenInvalidASIDisProvidedWithScope1() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + invalidAsid + "&scope=" + Scope.DIRECT)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

    }

    @Test
    public void shouldReturnRepairManualIndirectId_withStatusNoContent_whenInvalidASIDisProvidedWithScope2() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + invalidAsid + "&scope=" + Scope.INDIRECT)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

    }

    @Test
    public void shouldReturnRepairManualDirectId_withStatusNoContent_whenInvalidASIDisProvidedWithoutScope() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + invalidAsid)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }


    @Test
    public void shouldReturnRepairManualDirectId_withStatusOk_whenCorrectASIDisProvided() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + asid)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(mapper.writeValueAsString(repairManualDirectId)))
                .andExpect(status().isOk());

    }

    @Test
    public void getRepairManualIdFromASID_shouldNotReturnRepairManualId_withStatusNoContent_whenInCorrectASIDisProvided() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_RL_ID_PATH + "?asid=" + "dummy")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

    }

    @Test
    public void getMlCodeFromAsid_shouldReturnWireDiagramId_withStatusOk_whenCorrectASIDisProvided() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_ML_CODE_PATH + "?asid=" + asid)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(mapper.writeValueAsString(mlCode)))
                .andExpect(status().isOk());

    }

    @Test
    public void getMlCodeFromAsid_shouldNotReturnWireDiagramId_withStatusNoContent_whenInCorrectASIDisProvided() throws Exception {
        mvc.perform(get(REVERSE_MAPPING_ML_CODE_PATH + "?asid=" + "dummy")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

    }

}
