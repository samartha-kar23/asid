package com.vwits.asid.external;

import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import com.vwits.asid.utility.testutils.TokenUtil;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static com.vwits.asid.utility.constants.MappingServiceConstants.REVERSE_MAPPING_APOS_ID_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.REVERSE_MAPPING_ML_CODE_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.REVERSE_MAPPING_RL_ID_PATH;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_ASID;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_ASID_FOR_SLP_EBO;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.http.HttpMethod.GET;

public class ReverseMappingServiceSystemTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("mapping-service", false);
    private TestRestTemplate template;
    private HttpEntity<Object> requestEntity;


    @Before
    public void setUp() {
        template = new TestRestTemplate();
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + TokenUtil.getToken());
        requestEntity = new HttpEntity<>(headers);
    }

    @Test
    public void shouldReturn401WhenNoTokenPassedToGetMlCode() {
        String parameters = "?asid=" + VALID_ASID_FOR_SLP_EBO;
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL + REVERSE_MAPPING_ML_CODE_PATH + parameters, String.class);
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToGetMlCode() {
        String parameters = "?asid=" + VALID_ASID_FOR_SLP_EBO;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + REVERSE_MAPPING_ML_CODE_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void shouldReturn401WhenNoTokenPassedToGetRlId() {
        String parameters = "?asid=" + VALID_ASID;
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL + REVERSE_MAPPING_RL_ID_PATH + parameters, String.class);
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToGetRlIdWithoutScope() {
        String parameters = "?asid=" + VALID_ASID;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + REVERSE_MAPPING_RL_ID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToGetRlIdWithScope0() {
        String parameters = "?asid=" + VALID_ASID + "&scope=" + 0;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + REVERSE_MAPPING_RL_ID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToGetRlIdWithScope1() {
        String parameters = "?asid=" + VALID_ASID + "&scope=" + 1;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + REVERSE_MAPPING_RL_ID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToGetRlIdWithScope2() {
        String parameters = "?asid=" + VALID_ASID + "&scope=" + 2;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + REVERSE_MAPPING_RL_ID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void shouldReturn401WhenNoTokenPassedToGetLtId() {
        String parameters = "?asid=" + VALID_ASID;
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL + REVERSE_MAPPING_APOS_ID_PATH + parameters, String.class);
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToGetLtId() {
        String parameters = "?asid=" + VALID_ASID;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + REVERSE_MAPPING_APOS_ID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
    }
}
