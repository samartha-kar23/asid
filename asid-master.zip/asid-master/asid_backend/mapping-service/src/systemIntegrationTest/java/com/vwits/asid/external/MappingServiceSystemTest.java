package com.vwits.asid.external;

import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import com.vwits.asid.utility.testutils.TokenUtil;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static com.vwits.asid.utility.constants.MappingServiceConstants.ADMIN_GET_RL_MAPPING_DATA_CSV_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.ADMIN_RL_DELETE_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.ADMIN_RL_MAPPING_ADD_PATH;
import static com.vwits.asid.utility.constants.MappingServiceConstants.GET_ASID_PATH;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_LT_ID;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_ML_CODE;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_RL_ID;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;

public class MappingServiceSystemTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("mapping-service", false);

    private TestRestTemplate template;
    private HttpEntity<Object> requestEntity;

    private String idKitAuthorizationEndpoint = "/oidc/v1/authorize";

    @Before
    public void setUp() {
        template = new TestRestTemplate();
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + TokenUtil.getToken());
        requestEntity = new HttpEntity<>(headers);
    }

    @Test
    public void shouldReturn401WhenNoTokenPassedToGetAsid() {
        String parameters = "?rlid=" + VALID_RL_ID;
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL + GET_ASID_PATH + parameters, String.class);
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToGetAsid() {
        String parameters = "?rlid=" + VALID_RL_ID;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + GET_ASID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void shouldRedirect302WhenNoTokenPassedToAdminRLMappingGetCSV() {
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL + ADMIN_GET_RL_MAPPING_DATA_CSV_PATH, String.class);
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertTrue(getRedirectionUrl(responseEntity).contains(idKitAuthorizationEndpoint));
    }

    @Test
    public void shouldRedirect302WhenBackendTokenPassedToAdminRLMappingGetCSV() {
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + ADMIN_GET_RL_MAPPING_DATA_CSV_PATH, GET, requestEntity, String.class);
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertTrue(getRedirectionUrl(responseEntity).contains(idKitAuthorizationEndpoint));
    }

    @Test
    public void shouldRedirect302WhenBackendTokenPassedToAddRLMapping() {
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + ADMIN_RL_MAPPING_ADD_PATH, POST, requestEntity, String.class);
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertTrue(getRedirectionUrl(responseEntity).contains(idKitAuthorizationEndpoint));
    }

    @Test
    public void shouldRedirect302WhenBackendTokenPassedToDeleteRLMapping() {
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + ADMIN_RL_DELETE_PATH, DELETE, requestEntity, String.class);
        assertEquals(HttpStatus.FOUND, responseEntity.getStatusCode());
        assertTrue(getRedirectionUrl(responseEntity).contains(idKitAuthorizationEndpoint));
    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToFetchAsid_WhenMlCodeIsGiven() {
        String parameters = "?mlcode=" + VALID_ML_CODE;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + GET_ASID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
        assertNotNull(responseEntity.getBody());
    }

    @Test
    public void shouldReturn401WhenNoTokenIsPassedToFetchAsid_WhenMlCodeIsGiven() {
        String parameters = "?mlcode=" + VALID_ML_CODE;
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL + GET_ASID_PATH + parameters, String.class);
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());

    }

    @Test
    public void shouldReturn2XXWhenValidTokenIsPassedToFetchAsid_WhenLtIdIsGiven() {
        String parameters = "?ltid=" + VALID_LT_ID;
        final ResponseEntity<String> responseEntity = template.exchange(serviceURL + GET_ASID_PATH + parameters, GET, requestEntity, String.class);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());
        assertNotNull(responseEntity.getBody());
    }

    @Test
    public void shouldReturn401WhenNoTokenIsPassedToFetchAsid_WhenLtIdIsGiven() {
        String parameters = "?ltid=" + VALID_LT_ID;
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL + GET_ASID_PATH + parameters, String.class);
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());

    }

    @Test
    public void testSwaggerUrl() {
        if (serviceURL.contains("acceptance")) {
            String url = serviceURL + "/v2/api-docs?group=Swagger Specification";
            ResponseEntity<String> forEntity = template.getForEntity(url, String.class);
            assertEquals(HttpStatus.OK.value(), forEntity.getStatusCode().value());
        } else {
            assertTrue("Test case is not applicable for this environment, hence skipping it", true);
        }
    }

    private String getRedirectionUrl(ResponseEntity<String> responseEntity) {
        return responseEntity.getHeaders().get("Location").get(0);
    }
}
