package com.vwits.asid.external;

import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static com.vwits.asid.controller.CustomErrorController.CUSTOM_ERROR_MESSAGE;

public class CustomErrorControllerTest {

    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("mapping-service", false);
    private TestRestTemplate template;

    @Before
    public void setUp() {
        template = new TestRestTemplate();
    }

    @Test
    public void shouldReturnCustomErrorResponse_WhenMappingServiceHasBeenRequestedWithoutPath() {
        final ResponseEntity<String> responseEntity = template.getForEntity(serviceURL, String.class);
        Assert.assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        Assert.assertEquals(CUSTOM_ERROR_MESSAGE, responseEntity.getBody());

    }

}
