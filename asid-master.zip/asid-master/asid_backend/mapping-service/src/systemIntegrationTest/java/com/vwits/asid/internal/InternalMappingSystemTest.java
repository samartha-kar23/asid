package com.vwits.asid.internal;

import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_RL_ID;
import static org.hamcrest.Matchers.containsString;

public class InternalMappingSystemTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("internal-mapping-service", true);

    private RestTemplate template;

    @Before
    public void setUp() {
        template = new RestTemplate();
    }

    @Test
    public void shouldNotBeReachablePublicy() {
        thrown.expect(ResourceAccessException.class);
        thrown.expectMessage(containsString("apps.internal"));
        String parameters = "?rlid=" + VALID_RL_ID;
        template.getForEntity(serviceURL + "/getasid" + parameters, String.class);
    }

}
