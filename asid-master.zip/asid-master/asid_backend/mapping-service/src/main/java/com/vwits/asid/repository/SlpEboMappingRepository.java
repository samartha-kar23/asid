package com.vwits.asid.repository;

import com.vwits.asid.entity.SlpEboMapping;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SlpEboMappingRepository extends CrudRepository<SlpEboMapping, Long> {

    List<SlpEboMapping> findAllByAsidIn(List<String> asid);

    List<String> findDistinctAsidByMlCodeIn(List<String> mlCode);
}
