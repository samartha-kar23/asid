package com.vwits.asid.config;

import com.vwits.asid.service.AuthorizationService;
import com.vwits.asid.service.IDTokenHelper;
import com.vwits.asid.utility.constants.MappingServiceConstants;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AuthorizationFilter extends OncePerRequestFilter {

    private IDTokenHelper idTokenHelper;

    private AuthorizationService authorizationService;

    public AuthorizationFilter(IDTokenHelper idTokenHelper, AuthorizationService authorizationService) {
        this.idTokenHelper = idTokenHelper;
        this.authorizationService = authorizationService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        if (!httpServletRequest.getRequestURI().equals(MappingServiceConstants.AUTH_CALLBACK_PATH) && !httpServletRequest.getRequestURI().equals(MappingServiceConstants.LOGOUT_USER) && !httpServletRequest.getRequestURI().equals(MappingServiceConstants.SUCCESSFUL_LOGOUT) &&
                httpServletRequest.getCookies() != null) {
            final String emailId = idTokenHelper.getEmail(httpServletRequest);
            if (!(authorizationService.isUserAuthorized(emailId))) {
                httpServletResponse.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied");
            }
        }
        filterChain.doFilter(httpServletRequest, httpServletResponse);
    }
}
