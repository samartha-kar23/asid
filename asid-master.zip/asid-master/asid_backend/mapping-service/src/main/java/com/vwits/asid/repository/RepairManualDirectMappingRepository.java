package com.vwits.asid.repository;

import com.vwits.asid.entity.RepairManualMapping;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface RepairManualDirectMappingRepository extends CrudRepository<RepairManualMapping, Long> {

    @Query("select distinct rlMapping.asid from RepairManualMapping rlMapping where rlMapping.repairManualId in :repairManualIds ")
    List<String> findDistinctAsidByRepairManualIdIn(@Param("repairManualIds") List<String> repairManualIds);

    List<RepairManualMapping> findAllByAsid(String asid);

    RepairManualMapping findByAsidAndRepairManualId(String asid, String repairManualId);

    @Transactional
    void deleteByAsidAndRepairManualId(String asid, String repairManualId);

    @Query("select RLDirectLink.repairManualId from RepairManualMapping RLDirectLink where RLDirectLink.asid in :asid")
    List<String> findRepairManualDirectIdByAsid(@Param("asid") List<String> asid);
}
