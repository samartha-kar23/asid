package com.vwits.asid.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.vwits.asid.utility.constants.MappingServiceConstants.ERROR_PATH;

@Profile("Auth")
@RestController
public class CustomErrorController implements ErrorController {

    public static final String CUSTOM_ERROR_MESSAGE = "ERROR";

    @GetMapping(path = ERROR_PATH)
    public String handleError() {
        return CUSTOM_ERROR_MESSAGE;
    }

    @Override
    public String getErrorPath() {
        return ERROR_PATH;
    }
}
