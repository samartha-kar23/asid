package com.vwits.asid.utility;

import java.util.Arrays;
import java.util.List;

public class Utils {
    public static List<String> splitStringByComma(final String StringToSplit) {
        return Arrays.asList(StringToSplit.split("\\s*,\\s*"));
    }
}
