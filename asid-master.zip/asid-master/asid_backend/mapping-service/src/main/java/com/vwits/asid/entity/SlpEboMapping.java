package com.vwits.asid.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

import static com.vwits.asid.utility.constants.MappingServiceConstants.SLP_EBO_MAPPING;

@Entity(name = SLP_EBO_MAPPING)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SlpEboMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String asid;

    @Column(name = "ml_code")
    String mlCode;
}
