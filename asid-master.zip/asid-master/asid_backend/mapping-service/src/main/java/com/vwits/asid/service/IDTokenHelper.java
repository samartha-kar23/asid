package com.vwits.asid.service;

import com.nimbusds.jose.JWSObject;
import org.springframework.stereotype.Service;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Optional;

@Service
public class IDTokenHelper {

    public String getEmail(final HttpServletRequest request) {
        final String idToken = readToken(request);
        final Optional<String> email = getClaimFromJWSToken(idToken, "email");
        return email.orElse("");
    }

    public String readToken(final HttpServletRequest request) {
        String idToken = "";
        if(request.getCookies()!=null) {
            for (Cookie cookie : request.getCookies()) {
                if (cookie.getName().contains("id-token")) {
                    idToken = cookie.getValue();
                    break;
                }
            }
        }
        return idToken;
    }

    private Optional<String> getClaimFromJWSToken(String token, String claim) {
        JWSObject jwsObject;
        try {
            jwsObject = JWSObject.parse(token);
        } catch (ParseException e) {
            return Optional.empty();
        }
        String claimValue = (String) jwsObject.getPayload().toJSONObject().get(claim);
        return Optional.ofNullable(claimValue);
    }
}
