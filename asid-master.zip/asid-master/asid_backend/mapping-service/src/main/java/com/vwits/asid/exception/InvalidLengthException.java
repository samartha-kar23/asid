package com.vwits.asid.exception;

public class InvalidLengthException extends RuntimeException {
    public InvalidLengthException(String errorMessage) {
        super(errorMessage);
    }
}
