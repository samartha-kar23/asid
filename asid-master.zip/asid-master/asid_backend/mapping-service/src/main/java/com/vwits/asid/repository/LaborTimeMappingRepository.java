package com.vwits.asid.repository;

import com.vwits.asid.entity.LaborTimeMapping;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LaborTimeMappingRepository extends CrudRepository<LaborTimeMapping, Long> {
    List<LaborTimeMapping> findAllByLaborTimeId(String laborTime);

    List<LaborTimeMapping> findAllByAsid(String asid);
}
