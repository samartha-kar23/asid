package com.vwits.asid.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import vwg.digitallab.identitykit.clients.oauth2incoming.config.PlatformSecurityConfig;
import vwg.digitallab.identitykit.clients.oauth2incoming.config.PlatformSecurityConfigurer;

/**
 *To use this configuration simply annotate your SpringBootApplication's main class with
 *
 * @Import(IncomingSecurityUsingIDKitConfig.class)
 * Make sure you have whitelist clients in your environment
 */
@Profile("Auth")
@Configuration
@Import(BackendSecurityAdapter.class)
public class BackendSecurityConfig {

    @Value("${identitykit.whitelisted-client:none}")
    private String[] whitelistedClient;

    @Bean
    @Primary
    public PlatformSecurityConfig platformSecurityConfig() {
        PlatformSecurityConfigurer platformSecurityConfigurer = PlatformSecurityConfigurer
                .newBuilder()
                .enableOAuth2()
                .enableCsrf()
                .disableExternalAuthorization();
        for (String client : whitelistedClient) {
            platformSecurityConfigurer.addWhitelistedClient(client);
        }
        return platformSecurityConfigurer.build();
    }
}
