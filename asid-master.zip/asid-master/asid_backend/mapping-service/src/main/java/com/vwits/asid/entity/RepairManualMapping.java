package com.vwits.asid.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Wither;

import javax.persistence.*;

import static com.vwits.asid.utility.constants.MappingServiceConstants.RL_MAPPING;

@Entity
@Table(name = RL_MAPPING)
@Wither
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RepairManualMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column
    String asid;

    @Column(name = "rl_id")
    String repairManualId;

}
