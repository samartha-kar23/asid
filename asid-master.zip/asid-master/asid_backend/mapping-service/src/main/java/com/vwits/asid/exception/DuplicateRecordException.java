package com.vwits.asid.exception;

public class DuplicateRecordException extends RuntimeException {
    public DuplicateRecordException(String errorMessage) {
        super(errorMessage);
    }
}
