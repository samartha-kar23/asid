package com.vwits.asid.service;

import com.vwits.asid.entity.LaborTimeMapping;
import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.entity.RepairManualMappingDTO;
import com.vwits.asid.exception.DuplicateRecordException;
import com.vwits.asid.exception.InvalidLengthException;
import com.vwits.asid.repository.LaborTimeMappingRepository;
import com.vwits.asid.repository.RepairManualDirectMappingRepository;
import com.vwits.asid.repository.SlpEboMappingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static com.vwits.asid.utility.Utils.splitStringByComma;

@Service
public class MappingService {

    public static final String MESSAGE_WHILE_ADDING_ILLEGAL_CHARS = "The entry you are trying to add contains one of these not allowed characters: * % ' (space)";
    public static final String MESSAGE_WHEN_ID_LENGTH_INVALID = "Id length should be from 1 to 15 characters";
    public static final String MESSAGE_WHEN_ADDING_DUPLICATE_RECORDS = "Entry is already existing";
    private static final int MINIMUM_LTID_ALLOWED_SIZE = 4;
    private static final int MAXIMUM_LTID_ALLOWED_SIZE = 6;
    private static final int MAXIMUM_LTID_ALLOWED_SIZE_ETKA = 12;


    @Autowired
    RepairManualDirectMappingRepository repairManualDirectMappingRepository;

    @Autowired
    LaborTimeMappingRepository laborTimeRepository;

    @Autowired
    SlpEboMappingRepository slpEboMappingRepository;

    public List<String> getASIDForRepairManualID(String repairManualId) {

        List<String> rlIds = splitStringByComma(repairManualId);
        return repairManualDirectMappingRepository.findDistinctAsidByRepairManualIdIn(rlIds);

    }

    public List<String> getASIDForLaborTimeID(String laborTimeId) {
        List<String> asidList = new ArrayList<>();

        List<LaborTimeMapping> lTMappingList;
        lTMappingList = getLaborTimeMappings(laborTimeId);

        if (lTMappingList != null) {
            for (LaborTimeMapping mapping : lTMappingList) {
                asidList.add(mapping.getAsid());
            }
        }
        return asidList;
    }

    private List<LaborTimeMapping> getLaborTimeMappings(String laborTimeId) {

        List<LaborTimeMapping> ltMappingList = new ArrayList<>();
        List<String> ltIds = splitStringByComma(laborTimeId);
        for (String ltId : ltIds) {
            List<LaborTimeMapping> ltMappingTempList = null;
            int ltIdSize = ltId.length();

            if (ltIdSize >= MINIMUM_LTID_ALLOWED_SIZE && ltIdSize < MAXIMUM_LTID_ALLOWED_SIZE) {
                ltId = ltId.substring(0, MINIMUM_LTID_ALLOWED_SIZE);
                ltMappingTempList = laborTimeRepository.findAllByLaborTimeId(ltId);
            } else if (ltIdSize >= MAXIMUM_LTID_ALLOWED_SIZE && ltIdSize <= MAXIMUM_LTID_ALLOWED_SIZE_ETKA) {
                ltId = ltId.substring(0, MAXIMUM_LTID_ALLOWED_SIZE);
                ltMappingTempList = laborTimeRepository.findAllByLaborTimeId(ltId);
                if (ltMappingTempList.isEmpty()) {
                    ltId = ltId.substring(0, MINIMUM_LTID_ALLOWED_SIZE);
                    ltMappingTempList = laborTimeRepository.findAllByLaborTimeId(ltId);
                }

            }

            ltMappingList.addAll(ltMappingTempList);
        }

        return ltMappingList;
    }

    public List<RepairManualMapping> getAllRepairManualMapping() {
        return (List<RepairManualMapping>) repairManualDirectMappingRepository.findAll();
    }

    public RepairManualMapping addRlMapping(RepairManualMappingDTO repairManualMappingDTO) {

        if (isIdLengthInvalid(repairManualMappingDTO.getAsid()) ||
                isIdLengthInvalid(repairManualMappingDTO.getRepairManualId())) {
            throw new InvalidLengthException(MESSAGE_WHEN_ID_LENGTH_INVALID);
        }

        if (isIllegalCharPresentInId(repairManualMappingDTO.getAsid()) ||
                isIllegalCharPresentInId(repairManualMappingDTO.getRepairManualId())) {
            throw new IllegalArgumentException(MESSAGE_WHILE_ADDING_ILLEGAL_CHARS);
        }
        RepairManualMapping repairManualMapping = getRepairManualMappingFromDTO(repairManualMappingDTO);

        if (isRlMappingAlreadyPresent(repairManualMapping)) {
            throw new DuplicateRecordException(MESSAGE_WHEN_ADDING_DUPLICATE_RECORDS);
        }

        return repairManualDirectMappingRepository.save(repairManualMapping);
    }

    private RepairManualMapping getRepairManualMappingFromDTO(RepairManualMappingDTO repairManualMappingDTO) {
        return new RepairManualMapping()
                .withRepairManualId(repairManualMappingDTO.getRepairManualId())
                .withAsid(repairManualMappingDTO.getAsid())
                .withId(repairManualMappingDTO.getId());
    }

    private boolean isRlMappingAlreadyPresent(RepairManualMapping repairManualMapping) {
        return (null != repairManualDirectMappingRepository.findByAsidAndRepairManualId(repairManualMapping.getAsid(), repairManualMapping.getRepairManualId()));
    }

    private boolean isIdLengthInvalid(String id) {
        return id == null || id.length() < 1 || id.length() >= 15;
    }

    public void deleteRepairManualMapping(String asid, String repairManualId) {
        repairManualDirectMappingRepository.deleteByAsidAndRepairManualId(asid, repairManualId);
    }

    private boolean isIllegalCharPresentInId(String id) {
        Pattern illegalCharPattern = Pattern.compile("[*%' ]", Pattern.CASE_INSENSITIVE);
        return illegalCharPattern.matcher(id).find();
    }

    public List<String> getASIDForMlCode(String mlCode) {

        List<String> mlCodes = splitStringByComma(mlCode);
        return slpEboMappingRepository.findDistinctAsidByMlCodeIn(mlCodes);
    }
}
