package com.vwits.asid.service;

import com.vwits.asid.entity.LaborTimeMapping;
import com.vwits.asid.entity.SlpEboMapping;
import com.vwits.asid.repository.LaborTimeMappingRepository;
import com.vwits.asid.repository.RepairManualDirectMappingRepository;
import com.vwits.asid.repository.RepairManualMappingIndirectLinkRepository;
import com.vwits.asid.repository.SlpEboMappingRepository;
import com.vwits.asid.utility.entity.Scope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.vwits.asid.utility.Utils.splitStringByComma;

@Service
public class ReverseMappingService {

    @Autowired
    private LaborTimeMappingRepository laborTimeMappingRepository;

    @Autowired
    private RepairManualDirectMappingRepository repairManualDirectMappingRepository;

    @Autowired
    private SlpEboMappingRepository slpEboMappingRepository;

    @Autowired
    private RepairManualMappingIndirectLinkRepository indirectRepairManualMappingRepository;

    public List<String> getLaborTimeIdForAsid(String asid) {
        List<LaborTimeMapping> laborTimeMappingList = laborTimeMappingRepository.findAllByAsid(asid);
        List<String> list = new ArrayList<>();
        for (LaborTimeMapping mapping : laborTimeMappingList) {
            list.add(mapping.getLaborTimeId());
        }
        return list;
    }

    public List getRepairManualIdsForAsid(String asid, Scope mappingType) {
        List<String> asiDs = splitStringByComma(asid);
        switch (mappingType) {
            case DIRECT:
                return repairManualDirectMappingRepository.findRepairManualDirectIdByAsid(asiDs);
            case INDIRECT:
                return indirectRepairManualMappingRepository.findRepairManualIndirectIdByAsid(asiDs);
            case ALL:
                List<String> rlIdList = new ArrayList<>();
                rlIdList.addAll(repairManualDirectMappingRepository.findRepairManualDirectIdByAsid(asiDs));
                rlIdList.addAll(indirectRepairManualMappingRepository.findRepairManualIndirectIdByAsid(asiDs));
                return rlIdList;
            default:
                return new ArrayList();
        }
    }

    public List<String> getMlCodeForAsid(String asid) {
        List<String> asiDs = splitStringByComma(asid);
        List<SlpEboMapping> mlCodeList = slpEboMappingRepository.findAllByAsidIn(asiDs);
        List<String> list = new ArrayList<>();
        for (SlpEboMapping mapping : mlCodeList) {
            list.add(mapping.getMlCode());
        }
        return list;
    }
}
