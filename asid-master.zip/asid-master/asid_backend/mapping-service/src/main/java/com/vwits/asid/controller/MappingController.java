package com.vwits.asid.controller;

import com.newrelic.api.agent.NewRelic;
import com.vwits.asid.entity.SlpEboMapping;
import com.vwits.asid.service.MappingService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.vwits.asid.utility.constants.MappingServiceConstants.*;

@RestController
@CrossOrigin
@Slf4j
public class MappingController {

    @Autowired
    MappingService mappingService;

    @GetMapping(path = {GET_ASID_PATH, ADMIN_GET_ASID_PATH})
    @ApiOperation(value = "This API is used to fetch asid by providing infoMediaId. To get the value of ASID, you need to enter either of the three parameters")

    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = String.class, responseContainer = "List")})

    @CrossOrigin(allowCredentials = "true")
    public ResponseEntity getASID(@ApiParam(value = "Repair Manual Id, e.g. eng.93.9.2", example = "eng.93.9.2") @RequestParam(value = GETASID_RLID_PARAM, required = false) String rlId,
                                  @ApiParam(value = "Labour Time Id, e.g. 907450") @RequestParam(value = GETASID_LTID_PARAM, required = false) String laborTimeId,
                                  @ApiParam(value = "Mother List Code, e.g. E168") @RequestParam(value = GETASID_MLCODE_PARAM, required = false) String mlCode) {
        setupNewRelicParams(rlId, laborTimeId, mlCode);
        if (!StringUtils.isEmpty(laborTimeId)) {
            return getASIDFromLaborId(laborTimeId);
        } else if (!StringUtils.isEmpty(rlId)) {
            return getASIDFromRepairManualId(rlId);
        } else if (!StringUtils.isEmpty(mlCode)) {
            return getASIDFromMLCode(mlCode);
        }
        return ResponseEntity.badRequest().body("atleast one id is required.");
    }

    private ResponseEntity getASIDFromRepairManualId(String rlId) {
        List<String> asidForRepairManualID = mappingService.getASIDForRepairManualID(rlId);
        if (asidForRepairManualID.isEmpty())
            return ResponseEntity.noContent().build();

        return ResponseEntity.ok(asidForRepairManualID);
    }

    private ResponseEntity getASIDFromLaborId(String laborTimeId) {
        List<String> asidForLaborTimeID = mappingService.getASIDForLaborTimeID(laborTimeId);
        if (asidForLaborTimeID.isEmpty())
            return ResponseEntity.noContent().build();

        return ResponseEntity.ok(asidForLaborTimeID);
    }

    private ResponseEntity getASIDFromMLCode(String mlCode) {
        List<String> asidForMlCode = mappingService.getASIDForMlCode(mlCode);
        if (asidForMlCode.isEmpty())
            return ResponseEntity.noContent().build();
        return ResponseEntity.ok(asidForMlCode);
    }

    private void setupNewRelicParams(String rlId, String laborTimeId, String mlCode) {
        NewRelic.setTransactionName("Web", "repair_manual");
        NewRelic.addCustomParameter("rlid", rlId);
        NewRelic.addCustomParameter("ltid", laborTimeId);
        NewRelic.addCustomParameter("mlcode", mlCode);
    }
}
