package com.vwits.asid.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Profile(value = {"NoAuth", "!trailblazrTest","!adminIntegTest"})
@Configuration
@EnableWebSecurity
@Order(4)
public class NoAuthSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception{
        http.csrf().disable().cors().and().authorizeRequests().anyRequest().permitAll();
    }
}
