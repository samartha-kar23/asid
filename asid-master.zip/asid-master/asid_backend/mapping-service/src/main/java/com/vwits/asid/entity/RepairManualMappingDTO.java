package com.vwits.asid.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Wither;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Wither
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RepairManualMappingDTO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column
    String asid;

    @Column(name = "rl_id")
    String repairManualId;
}
