package com.vwits.asid.config;

import com.vwits.asid.service.AuthorizationService;
import com.vwits.asid.service.IDTokenHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import vwg.digitallab.identitykit.clients.authcodeflow.EnableIdentityKitAuthCodeFlow;
import vwg.digitallab.identitykit.clients.authcodeflow.IdentityKitAuthenticationEntryPoint;
import vwg.digitallab.identitykit.clients.authcodeflow.IdentityKitCallbackAuthenticationFilter;
import vwg.digitallab.identitykit.clients.core.config.IdentityKitCookieConfiguration;

import static com.vwits.asid.utility.constants.MappingServiceConstants.*;

@Profile("Auth & !trailblazrTest")
@Configuration
@EnableIdentityKitAuthCodeFlow
@Order(1)
public class FrontendSecurityAdapter extends WebSecurityConfigurerAdapter {

    @Autowired
    private IdentityKitCookieConfiguration identityKitCookieConfiguration;

    @Autowired
    private IdentityKitAuthenticationEntryPoint identityKitAuthenticationEntryPoint;

    @Autowired
    private IdentityKitCallbackAuthenticationFilter identityKitCallbackAuthenticationFilter;

    @Autowired
    private IDTokenHelper idTokenHelper;

    @Autowired
    private AuthorizationService authorizationService;


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http
                .authorizeRequests().antMatchers("/","/error").permitAll()
                .and()
                .addFilterBefore(identityKitCallbackAuthenticationFilter, BasicAuthenticationFilter.class)
                .antMatcher("/admin/**")
                .addFilterAfter(new AuthorizationFilter(idTokenHelper, authorizationService), BasicAuthenticationFilter.class)
                .exceptionHandling()
                .authenticationEntryPoint(identityKitAuthenticationEntryPoint)
                .and()
                .authorizeRequests().antMatchers(LOGOUT_USER, LOGGEDIN_USER_DETAILS_PATH, ADMIN_RL_MAPPING_ADD_PATH, ADMIN_RL_DELETE_PATH, ADMIN_GET_RL_MAPPING_DATA_CSV_PATH, ADMIN_GET_ASID_PATH, ADMIN_GET_RL_ID_PATH, AUTH_CALLBACK_PATH).authenticated()
                .and()
                .csrf().disable().cors().and()
                .logout()
                .deleteCookies(identityKitCookieConfiguration.getCookieNames());
    }
}
