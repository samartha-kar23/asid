package com.vwits.asid.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Wither;

import javax.persistence.*;

import static com.vwits.asid.utility.constants.MappingServiceConstants.AZ_MAPPING;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Wither
@Table(name = AZ_MAPPING)
public class LaborTimeMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String asid;

    @Column(name = "kdnr")
    String laborTimeId;
}
