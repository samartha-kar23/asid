package com.vwits.asid.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Profile(value = {"Auth", "adminIntegTest"})
@Service
@Slf4j
public class AuthorizationService {
    @Value("${internal.auth.service.url}")
    private String authServiceUrl;

    @Autowired
    RestTemplate restTemplate;

    public boolean isUserAuthorized(String emailId) {
        final String authUrl = authServiceUrl + "?emailId=" + emailId;
        final HttpHeaders headers = new HttpHeaders();
        final HttpEntity<Object> requestEntity = new HttpEntity<>(headers);
        final ResponseEntity<Boolean> exchange;
        try {
            exchange = restTemplate.exchange(authUrl, HttpMethod.GET, requestEntity, Boolean.class);
        } catch (Exception e) {
            log.error("Error while calling auth service url:{} ", authUrl, e);
            return false;
        }
        return exchange.getBody();
    }
}
