package com.vwits.asid.controller;

import com.vwits.asid.entity.RepairManualMapping;
import com.vwits.asid.entity.RepairManualMappingDTO;
import com.vwits.asid.exception.DuplicateRecordException;
import com.vwits.asid.exception.InvalidLengthException;
import com.vwits.asid.service.MappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import static com.vwits.asid.utility.constants.MappingServiceConstants.*;

@Profile(value = {"Auth","adminIntegTest"})
@RestController
@CrossOrigin(allowCredentials = "true")
public class MappingDataController {

    @Autowired
    private MappingService mappingService;

    @GetMapping(value = ADMIN_GET_RL_MAPPING_DATA_CSV_PATH, produces = "text/csv")
    public ResponseEntity getRepairManualMappingData(HttpServletRequest request) {

        List<RepairManualMapping> repairManualMappingList = mappingService.getAllRepairManualMapping();

        if (repairManualMappingList.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Content-Disposition", "attachment; filename=rlmappingdata.csv");
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);

        return ResponseEntity.ok()
                .headers(httpHeaders)
                .body(generateCSVFileFromRepairManualMappingList(repairManualMappingList));
    }

    @DeleteMapping(value = ADMIN_RL_DELETE_PATH)
    public ResponseEntity deleteMappingRowForRepairManual(HttpServletRequest request, @RequestParam String asid, @RequestParam String rlid) {
        mappingService.deleteRepairManualMapping(asid, rlid);
        return ResponseEntity.noContent().build();
    }

    private String generateCSVFileFromRepairManualMappingList(List<RepairManualMapping> repairManualMappingList) {
        StringBuilder repairManualCSV = new StringBuilder();
        repairManualCSV.append("asid,rlid");
        repairManualCSV.append("\n");
        for (RepairManualMapping repairManualMapping : repairManualMappingList) {
            repairManualCSV.append(repairManualMapping.getAsid());
            repairManualCSV.append(",");
            repairManualCSV.append(repairManualMapping.getRepairManualId());
            repairManualCSV.append("\n");
        }
        return repairManualCSV.toString();
    }

    @PostMapping(value = ADMIN_RL_MAPPING_ADD_PATH)
    public ResponseEntity addRlMapping(HttpServletRequest request, @RequestBody RepairManualMappingDTO repairManualMappingDTO) {
        try {
            return ResponseEntity.ok(mappingService.addRlMapping(repairManualMappingDTO));
        } catch (IllegalArgumentException | InvalidLengthException e) {
            return ResponseEntity.unprocessableEntity().body(e.getMessage());
        } catch (DuplicateRecordException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }
    }

}
