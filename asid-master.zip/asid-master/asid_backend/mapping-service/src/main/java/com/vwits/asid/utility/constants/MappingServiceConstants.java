package com.vwits.asid.utility.constants;

public final class MappingServiceConstants {
    public static final String GET_ASID_PATH = "/getasid";
    public static final String REVERSE_MAPPING_APOS_ID_PATH = "/aposid";
    public static final String REVERSE_MAPPING_RL_ID_PATH = "/rlid";
    public static final String GETASID_RLID_PARAM = "rlid";
    public static final String GETASID_LTID_PARAM = "ltid";
    public static final String GETASID_MLCODE_PARAM = "mlcode";
    public static final String REVERSE_MAPPING_ML_CODE_PATH = "/getmlcode";
    public static final String RL_MAPPING = "rl_mapping";
    public static final String RL_MAPPING_INDIRECT_LINK = "rl_mapping_indirect_link";
    public static final String SLP_EBO_MAPPING = "slp_ebo_mapping";
    public static final String AZ_MAPPING = "az_mapping";

    public static final String ERROR_PATH = "/error";

    public static final String ADMIN_GET_RL_MAPPING_DATA_CSV_PATH = "/admin/rlmappingdata";
    public static final String ADMIN_RL_MAPPING_ADD_PATH = "/admin/addrlmapping";
    public static final String ADMIN_RL_DELETE_PATH = "/admin/deleterlmapping";
    public static final String ADMIN_GET_RL_ID_PATH = "/admin/rlid";
    public static final String ADMIN_GET_ASID_PATH = "/admin/getasid";
    public static final String AUTH_CALLBACK_PATH = "/admin";
    public static final String AUTH_CALLBACK_ERROR_PATH = "/admin-error";
    public static final String LOGOUT_USER = "/admin/logout-user";
    public static final String SUCCESSFUL_LOGOUT = "/admin/logoutsuccess";
    public static final String LOGGEDIN_USER_DETAILS_PATH = "/admin/userdetails";
    public static final String SWAGGER_UI_PATH = "/swagger-ui.html";


    private MappingServiceConstants() {
    }
}

