package com.vwits.asid.controller;

import com.vwits.asid.service.IDTokenHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.utils.URIBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URLDecoder;

import static com.vwits.asid.utility.constants.MappingServiceConstants.*;

@Profile(value = {"Auth", "adminIntegTest"})
@RestController
@CrossOrigin(allowCredentials = "true")
@Slf4j
public class AuthenticationController {

    @Autowired
    private IDTokenHelper idTokenHelper;

    @Value("${admin.pageUrl}")
    private String uiHome;
    @Value("${logoutsuccess.redirectUrl}")
    private String logoutSuccessRedirect;
    @Value("${identitykit.issuer}")
    private String issuer;

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public void setLogoutSuccessRedirect(String logoutSuccessRedirect) {
        this.logoutSuccessRedirect = logoutSuccessRedirect;
    }

    @GetMapping(AUTH_CALLBACK_PATH)
    public ModelAndView authCallBack() {
        return new ModelAndView("redirect:" + uiHome);
    }

    @GetMapping(AUTH_CALLBACK_ERROR_PATH)
    public ResponseEntity authCallBackError(final HttpServletResponse response) {
        return ResponseEntity.status(response.getStatus()).build();
    }

    @GetMapping(LOGGEDIN_USER_DETAILS_PATH)
    public ResponseEntity getLoggedInUserDetails(HttpServletRequest request) {
        final String email = idTokenHelper.getEmail(request);
        return email.isEmpty() ? ResponseEntity.status(HttpStatus.UNAUTHORIZED).build() : ResponseEntity.ok(email);
    }

    @GetMapping(LOGOUT_USER)
    public void logout(HttpServletRequest request, HttpServletResponse response) throws URISyntaxException, IOException {
        final String idToken = idTokenHelper.readToken(request);
        final String customRedirectUrl = logoutSuccessRedirect.trim() + SUCCESSFUL_LOGOUT;
        final String redirectUrl = new URIBuilder(issuer)
                .setPath("/oidc/v1/logout")
                .addParameter("id_token_hint", idToken)
                .addParameter("post_logout_redirect_uri", customRedirectUrl)
                .build()
                .toURL().toString();
        request.getSession().invalidate();
        response.sendRedirect(URLDecoder.decode(redirectUrl, "UTF-8"));
    }

    @GetMapping(value = SUCCESSFUL_LOGOUT)
    public Boolean logoutSuccessFull() {
        return true;
    }
}
