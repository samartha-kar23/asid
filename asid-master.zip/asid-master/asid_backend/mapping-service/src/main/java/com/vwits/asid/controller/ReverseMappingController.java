package com.vwits.asid.controller;

import com.newrelic.api.agent.NewRelic;
import com.vwits.asid.service.ReverseMappingService;
import com.vwits.asid.utility.entity.Scope;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.vwits.asid.utility.constants.MappingServiceConstants.*;

@RestController
@CrossOrigin
public class ReverseMappingController {

    @Autowired
    ReverseMappingService reverseMappingService;

    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = String.class, responseContainer = "List")})
    @GetMapping(path = REVERSE_MAPPING_APOS_ID_PATH)
    @ApiOperation("Fetch aposId by providing asid")
    public ResponseEntity<Object> getLaborTimeIdFromAsid(@ApiParam(value = "After Sales Id, e.g. 971X9745", example = "971X9745") @RequestParam(value = "asid") String asid) {
        setupNewRelicParams(asid);
        List<String> laborTimeIdForAsid = reverseMappingService.getLaborTimeIdForAsid(asid);
        if (laborTimeIdForAsid == null || laborTimeIdForAsid.isEmpty())
            return ResponseEntity.noContent().build();
        return ResponseEntity.ok(laborTimeIdForAsid);
    }

    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = String.class, responseContainer = "List")})
    @GetMapping(path = {REVERSE_MAPPING_RL_ID_PATH, ADMIN_GET_RL_ID_PATH})
    @ApiOperation("Fetch rlId by providing asid")
    @CrossOrigin(allowCredentials = "true")
    public ResponseEntity<Object> getRepairManualIdFromAsid(@ApiParam(value = "After Sales Id can be single id or comma separated string of ids , e.g. 915X2708,915X8", example = "915X2708,915X8") @RequestParam(value = "asid") String asid, @RequestParam(value = "scope", required = false, defaultValue = "1") int scopeValue) {
        setupNewRelicParams(asid);
        final Scope scope = Scope.getByValue(scopeValue);
        List<String> repairManualIdForAsid = reverseMappingService.getRepairManualIdsForAsid(asid, scope);
        if (repairManualIdForAsid == null || repairManualIdForAsid.isEmpty())
            return ResponseEntity.noContent().build();
        return ResponseEntity.ok(repairManualIdForAsid);
    }

    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = String.class, responseContainer = "List")})
    @ApiOperation("Fetch MLCode by providing asid")
    @GetMapping(path = REVERSE_MAPPING_ML_CODE_PATH)
    public ResponseEntity<Object> getMlCodeFromAsid(@ApiParam(value = "After Sales Id can be single id or comma separated string of ids, e.g. 858X6809,915X2708", example = "858X6809,915X2708") @RequestParam(value = "asid") String asid) {
        setupNewRelicParams(asid);
        List<String> mlCodeForAsid = reverseMappingService.getMlCodeForAsid(asid);
        if (mlCodeForAsid == null || mlCodeForAsid.isEmpty())
            return ResponseEntity.noContent().build();
        return ResponseEntity.ok(mlCodeForAsid);
    }

    private void setupNewRelicParams(String asid) {
        NewRelic.setTransactionName("Web", "mapping_service");
        NewRelic.addCustomParameter("asid", asid);
    }

}
