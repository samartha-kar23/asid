package com.vwits.asid;

import com.vwits.asid.entity.UsageStatisticsEntity;
import com.vwits.asid.repository.UsageStatisticsRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase
public class UsageStatisticsRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private UsageStatisticsRepository usageStatisticsRepository;

    private LocalDateTime startDate = LocalDateTime.of(2019, 9, 21, 8, 20, 50);
    private LocalDateTime dummyDate = LocalDateTime.of(2019, 9, 22, 8, 20, 50);

    private LocalDateTime endDate = LocalDateTime.of(2019, 9, 24, 11, 35, 50);

    @Before
    @Transactional
    public void setUp() {

        UsageStatisticsEntity transactionStatisticsDAOForLT = UsageStatisticsEntity.builder()
                .appName("LT").asid("dummy").brand("A")
                .timeStamp(startDate)
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                        language("english").responseCode(200).responseTime(200L).build();

        UsageStatisticsEntity transactionStatisticsDAOForRL = UsageStatisticsEntity.builder()
                .appName("RL").asid("dummy").brand("A")
                .timeStamp(endDate)
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                        language("english").responseCode(200).responseTime(200L).build();

        UsageStatisticsEntity transactionStatisticsDAOForParts = UsageStatisticsEntity.builder()
                .appName("Parts").asid("dummy").brand("A")
                .timeStamp(dummyDate)
                .dealerId("dealer_dummy").endPoint("dummy_endpoint").
                        language("english").responseCode(200).responseTime(200L).build();

        entityManager.persist(transactionStatisticsDAOForLT);
        entityManager.persist(transactionStatisticsDAOForRL);
        entityManager.persist(transactionStatisticsDAOForParts);
    }

    @Test
    public void shouldReturnMonitoringData() {
        final List<UsageStatisticsEntity> actualResponse = usageStatisticsRepository.findAllByTimeStampBetween(startDate, endDate);
        assertEquals(3, actualResponse.size());
    }
}
