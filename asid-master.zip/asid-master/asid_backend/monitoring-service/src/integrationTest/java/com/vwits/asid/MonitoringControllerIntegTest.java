package com.vwits.asid;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.entity.UsageStatisticsEntity;
import com.vwits.asid.repository.UsageStatisticsRepository;
import com.vwits.asid.utility.testutils.SpringTestWithMockIDKit;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.List;

import static com.vwits.asid.utility.testutils.IntegTestHelper.getMockTokenForIdKit;
import static org.junit.Assert.assertEquals;
import static org.springframework.test.annotation.DirtiesContext.MethodMode.AFTER_METHOD;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringTestWithMockIDKit
@AutoConfigureMockMvc
public class MonitoringControllerIntegTest {

    public static final String FETCH_USAGE_STATISTICS_URI = "/api/fetch-usage-statistics";

    private ObjectMapper objectMapper = new ObjectMapper();

    private String token;

    @Autowired
    private MockMvc mvc;

    private String startDate = "2019-09-11T12:00:00";
    private String endDate = "2019-09-12T12:00:00";

    private HttpHeaders httpHeaders;

    private MultiValueMap<String, String> requestParams;

    @Autowired
    private UsageStatisticsRepository usageStatisticsRepository;

    @Before
    public void setUp() {
        token = getMockTokenForIdKit();
        requestParams = new LinkedMultiValueMap<>();
        httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.AUTHORIZATION, "Bearer ".concat(token));
    }


    @Test
    @DirtiesContext(methodMode = AFTER_METHOD)
    public void getMonitoringData_WhenValidStartAndEndDateIsProvided_itShouldReturn200WhenDataIsPresent() throws Exception {
        this.saveDummyDataForMonitoring();
        requestParams.add("startDate", startDate);
        requestParams.add("endDate", endDate);

        final UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(FETCH_USAGE_STATISTICS_URI).queryParams(requestParams).build();
        final String urlTemplate = uriComponents.toUriString();

        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isOk()).andReturn();
        final List responseList = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), List.class);
        assertEquals(2, responseList.size());
    }

    @Test
    @DirtiesContext(methodMode = AFTER_METHOD)
    public void getMonitoringData_WhenValidStartDateIsProvidedAndEndDateIsEmpty_itShouldReturn200WhenDataIsPresent() throws Exception {
        this.saveDummyDataForMonitoring();
        requestParams.add("startDate", startDate);
        requestParams.add("endDate", null);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(FETCH_USAGE_STATISTICS_URI).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();


        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isOk()).andReturn();
        final List responseList = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), List.class);
        assertEquals(3, responseList.size());
    }


    @Test
    public void getMonitoringData_WhenValidStartAndEndDateIsProvided_itShouldReturn204WhenDataIsNotPresent() throws Exception {

        requestParams.add("startDate", "2019-09-11T09:00:00");
        requestParams.add("endDate", "2019-09-11T11:00:00");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(FETCH_USAGE_STATISTICS_URI).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();


        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isNoContent());
    }

    @Test
    public void getMonitoringData_WhenInValidFormatStartAndEndDateIsProvided_itShouldReturn400() throws Exception {

        requestParams.add("startDate", "2019-09-31 T 12:00:00");
        requestParams.add("endDate", "2019-09-1 T 12:00:00");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(FETCH_USAGE_STATISTICS_URI).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();


        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void getMonitoringData_WhenStartDateIsNotProvided_itShouldReturn400() throws Exception {

        requestParams.add("startDate", "");
        requestParams.add("endDate", "2019-09-1T12:00:00");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(FETCH_USAGE_STATISTICS_URI).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void getLaborTime_ShouldFail_whenWrongTokenIsPassed() throws Exception {
        requestParams.add("startDate", startDate);
        requestParams.add("endDate", endDate);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(FETCH_USAGE_STATISTICS_URI).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        String wrongToken = "";
        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + wrongToken))
                .andExpect(status().isUnauthorized());
    }

    private void saveDummyDataForMonitoring() {
        usageStatisticsRepository.save(UsageStatisticsEntity.builder()
                .appName("dev")
                .asid("831X5751")
                .dealerId("authorisedDealerId")
                .endPoint("repair-manual-service-development")
                .responseCode(200)
                .timeStamp(LocalDateTime.of(2019, 9, 11, 12, 00, 00))
                .build());

        usageStatisticsRepository.save(UsageStatisticsEntity.builder()
                .appName("dev")
                .asid("831X5751")
                .dealerId("authorisedDealerId")
                .endPoint("repair-manual-service-development")
                .responseCode(200)
                .timeStamp(LocalDateTime.of(2019, 9, 12, 12, 00, 00))
                .build());

        usageStatisticsRepository.save(UsageStatisticsEntity.builder()
                .appName("dev")
                .asid("831X5751")
                .dealerId("authorisedDealerId")
                .endPoint("repair-manual-service-development")
                .responseCode(200)
                .timeStamp(LocalDateTime.of(2019, 9, 19, 8, 20, 50))
                .build());
    }
}
