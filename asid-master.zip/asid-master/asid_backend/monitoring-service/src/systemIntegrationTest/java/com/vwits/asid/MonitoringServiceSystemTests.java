package com.vwits.asid;

import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import com.vwits.asid.utility.testutils.entity.IdKitClientCredential;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

import static com.vwits.asid.utility.GeneralUtility.getHttpEntityWithHeaderToken;
import static com.vwits.asid.utility.testutils.TokenUtil.getToken;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class MonitoringServiceSystemTests {

    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("monitoring-service", false);
    private RestTemplate template;
    private MultiValueMap<String, String> requestParams;
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    private IdKitClientCredential idKitCredential = new IdKitClientCredential();
    private String startDate = "2019-09-20T10:17:53";
    private String endDate = "2019-09-23T10:09:32";
    public static final String FETCH_USAGE_STATISTICS_URI = "/api/fetch-usage-statistics";


    @Before
    public void setUp() {
        requestParams = new LinkedMultiValueMap<>();
        template = new RestTemplate();
    }

    @Test
    public void testSwaggerUrl() {
        if (serviceURL.contains("acceptance")) {
            String url = serviceURL + "/swagger-ui.html";
            ResponseEntity<String> forEntity = template.getForEntity(url, String.class);
            assertEquals(HttpStatus.OK.value(), forEntity.getStatusCode().value());
        } else {
            assertTrue("Test case is not applicable for this environment, hence skipping it", true);
        }
    }

    @Test
    public void getMonitoringData_itShouldGet2XX_ifCalledWithCorrectToken() {

        requestParams.add("startDate", startDate);
        requestParams.add("endDate", endDate);

        String validToken = getToken(template, idKitCredential);

        ResponseEntity actualResponse = getMonitoringData(validToken, requestParams);
        assertTrue(actualResponse.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void getMonitoringData_itShouldGet401_ifCalledWithInCorrectToken() {

        requestParams.add("startDate", startDate);
        requestParams.add("endDate", endDate);
        String invalidToken = "dummy token";

        thrown.expect(HttpClientErrorException.class);
        thrown.expectMessage(containsString("401 Unauthorized"));
        thrown.expect(hasProperty("statusCode", is(HttpStatus.UNAUTHORIZED)));
        thrown.expect(hasProperty("statusText", containsString("Unauthorized")));

        getMonitoringData(invalidToken, requestParams);
    }

    private ResponseEntity getMonitoringData(String validToken, MultiValueMap<String, String> testData) {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(FETCH_USAGE_STATISTICS_URI).queryParams(testData).build();
        HttpEntity<String> request = getHttpEntityWithHeaderToken(validToken);
        return template.exchange(serviceURL + uriComponents.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List>() {
        });

    }


}
