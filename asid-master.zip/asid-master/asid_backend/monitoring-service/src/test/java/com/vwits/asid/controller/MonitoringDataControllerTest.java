package com.vwits.asid.controller;

import com.vwits.asid.service.MonitoringService;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MonitoringDataControllerTest {

    private MonitoringController monitoringController;

    @Mock
    private MonitoringService monitoringService;

    private LocalDateTime startDate;

    private LocalDateTime endDate;


    @Before
    public void setUp() {
        monitoringController = new MonitoringController(monitoringService);
        startDate = LocalDateTime.of(2019, 9, 21, 8, 20, 50);
        endDate = LocalDateTime.of(2019, 9, 24, 11, 35, 50);
    }

    @Test
    public void fetchUsageData_WhenValidStartAndEndDateIsPassed_itShouldReturn200() {

        when(monitoringService.getData(startDate, endDate)).thenReturn(Collections.singletonList(UsageStatisticsDTO.builder().build()));
        final ResponseEntity responseEntity = monitoringController.fetchUsageData(startDate, endDate);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
    }

    @Test
    public void fetchUsageData_WhenValidStartDateAndEndDateIsPassed_itShouldReturn204() {
        final ResponseEntity actualResponse = monitoringController.fetchUsageData(startDate, endDate);
        assertEquals(HttpStatus.NO_CONTENT, actualResponse.getStatusCode());
    }

    @Test
    public void fetchUsageData_WhenEndDateIsEmpty_itShouldReturn200BySettingEndDateAsCurrentDate() {

        when(monitoringService.getData(any(LocalDateTime.class), any(LocalDateTime.class))).thenReturn(Collections.singletonList(UsageStatisticsDTO.builder().build()));
        final ResponseEntity actualResponse = monitoringController.fetchUsageData(startDate, null);

        assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
        assertNotNull(actualResponse.getBody());
    }
}
