package com.vwits.asid.service;

import com.vwits.asid.entity.UsageStatisticsEntity;
import com.vwits.asid.repository.UsageStatisticsRepository;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MonitoringServiceTest {

    private MonitoringService monitoringService;

    @Mock
    private UsageStatisticsRepository usageStatisticsRepository;

    private LocalDateTime startDate;
    private LocalDateTime endDate;

    @Before
    public void setUp() {
        monitoringService = new MonitoringService(usageStatisticsRepository);
        startDate = LocalDateTime.of(2019, 9, 21, 8, 20, 50);
        endDate = LocalDateTime.of(2019, 9, 24, 11, 35, 50);
    }

    @Test
    public void getData_itShouldReturnMonitoringDataBetweenStartAndEndDate() {
        // given

        when(usageStatisticsRepository.findAllByTimeStampBetween(startDate, endDate)).thenReturn(
                Arrays.asList(UsageStatisticsEntity.builder()
                        .appName("repair-manual-service")
                        .asid("asid")
                        .timeStamp(endDate)
                        .build()));

        final List<UsageStatisticsDTO> usageStatisticsDTOList = Arrays.asList(
                UsageStatisticsDTO.builder()
                        .appName("repair-manual-service")
                        .asid("asid")
                        .timeStamp(endDate)
                        .build()
        );

        // when
        List<UsageStatisticsDTO> result = monitoringService.getData(startDate, endDate);

        // then
        assertEquals(1, result.size());
        assertEquals(usageStatisticsDTOList, result);
    }

    @Test
    public void getData_itShouldReturnEmptyListWhenDataIsNotFoundForSpecificStartAndEndDate() {
        // given
        when(usageStatisticsRepository.findAllByTimeStampBetween(startDate, endDate)).thenReturn(Collections.emptyList());

        // when
        List<UsageStatisticsDTO> response = monitoringService.getData(startDate, endDate);

        // then
        assertTrue(response.isEmpty());
    }

}
