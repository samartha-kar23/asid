package com.vwits.asid.controller;

import com.vwits.asid.service.MonitoringService;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api")
public class MonitoringController {

    private MonitoringService monitoringService;

    public MonitoringController(MonitoringService monitoringService) {
        this.monitoringService = monitoringService;
    }

    @ApiOperation(value = "This API helps to fetch usage data after providing required parameters. The endDate is an optional parameter. If you don't provide endDate, it will pick the current time")
    @ApiResponses(@ApiResponse(code = 200, message = "Success", response = UsageStatisticsDTO.class))
    @GetMapping(path = "/fetch-usage-statistics")
    public ResponseEntity fetchUsageData(@ApiParam(value = "Start Date, e.g. 2019-09-11T12:00:00", example = "2019-09-11T12:00:00") @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
                                         @ApiParam(value = "End Date, e.g. 2019-09-12T12:00:00", example = "2019-09-12T12:00:00") @RequestParam(value = "endDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {


        endDate = endDate == null ? LocalDateTime.now() : endDate;

        final List<UsageStatisticsDTO> response = monitoringService.getData(startDate, endDate);


        if (response == null || response.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok().body(response);
    }
}
