package com.vwits.asid.service;

import com.vwits.asid.entity.UsageStatisticsEntity;
import com.vwits.asid.repository.UsageStatisticsRepository;
import com.vwits.asid.utility.entity.UsageStatisticsDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MonitoringService {

    private UsageStatisticsRepository usageStatisticsRepository;

    public MonitoringService(UsageStatisticsRepository usageStatisticsRepository) {
        this.usageStatisticsRepository = usageStatisticsRepository;
    }

    public List<UsageStatisticsDTO> getData(LocalDateTime startDate, LocalDateTime endDate) {
        final List<UsageStatisticsEntity> usageStatisticsEntities = usageStatisticsRepository.findAllByTimeStampBetween(startDate, endDate);
        return usageStatisticsEntities.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());

    }

    private UsageStatisticsDTO toDTO(UsageStatisticsEntity usageStatisticsEntity) {
        return UsageStatisticsDTO.builder()
                .asid(usageStatisticsEntity.getAsid())
                .appName(usageStatisticsEntity.getAppName())
                .brand(usageStatisticsEntity.getBrand())
                .language(usageStatisticsEntity.getLanguage())
                .dealerId(usageStatisticsEntity.getDealerId())
                .endPoint(usageStatisticsEntity.getEndPoint())
                .responseCode(usageStatisticsEntity.getResponseCode())
                .responseTime(usageStatisticsEntity.getResponseTime())
                .timeStamp(usageStatisticsEntity.getTimeStamp())
                .build();
    }
}
