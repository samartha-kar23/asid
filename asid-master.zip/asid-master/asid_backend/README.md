# ASID
Mapping the After Sales world.

## Setup

### Git Related
- be sure to be added in .pairs file
- be sure to use duet-commit

### Project related

How to set up project (on a local dev machine):
- be sure to checkout to ~/workspace
- have a look in the ~/workspace/asid/scripts ReadMe file and to the bash_profile magic
- make sure the mysqlinitdb.sh script ran. Verify (by listing the tables of the asidmock database)
- Have a credential file (as for now: Grab it from another machine)

### IDE Related
Setting up the IDE:
- do a gradle setup
- Import Lombok PlugIn
- Activate Annotation Processing

### New submodules
To create new submodules
- go to start.spring.io and define your module as gradle project
- extract the zip that was created in your downloads folder and move its contents to the asid_backend folder.
- in intellij open up "Project Structure" and select "Modules", then mark "asid_backend", and hit the '+' Button, select your newly created folder and follow the instructions.
- now you will have the src folders and stuff all marked correctly.
- Sadly the gradle settings are not correct now. Adjust the settings.gradle file in asid_backend and add an include to your project.
- If you open up the gradle slider you notice that your project is now listed twice: once under the asid_backend (with is ok and originates from the include) once aside the asid_backend (don't know where that comes from) Delete the one aside the asid_backend.
- Be sure to add the manifest files to git-crypt!
