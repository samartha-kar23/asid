#!/bin/sh
set -e

cf_access_token=$(curl --user $CLIENT_ID:$CLIENT_SECRET -d "grant_type=client_credentials" https://uaa.sys.emea.vwapps.io/oauth/token)
access_token=$(echo $cf_access_token | jq -r '.access_token')
user_credentials=$(curl -H "Authorization: Bearer $access_token" $CREDENTIALS_ENDPOINT)
cf_api_url=$(echo $user_credentials | jq -r '.cf_api_url')
username=$(echo $user_credentials | jq -r '.username')
password=$(echo $user_credentials | jq -r '.password')
echo "↳ ☂ Securing endpoints on " $ENVIRONMENT
cf login -a $cf_api_url -u $username -p $password -o $CF_ORG -s $ENVIRONMENT

echo ${SOURCE_APPS}
echo ${DESTINATION_APPS}

SOURCE_APP_NAMES=$(echo $SOURCE_APPS | tr "," "\n")
DESTINATION_APP_NAMES=$(echo $DESTINATION_APPS | tr "," "\n")

for SOURCE_APP in $SOURCE_APP_NAMES
  do
    for DESTINATION_APP in $DESTINATION_APP_NAMES
    do
        if ! cf add-network-policy ${SOURCE_APP} --destination-app ${DESTINATION_APP} --port 8080 --protocol tcp
        then
         echo "** Failed to configured " ${SOURCE_APP} " with internal service named, " ${DESTINATION_APP} " **"
         exit 1
        else
         echo "** Successfully configured " ${SOURCE_APP} " with internal service named, " ${DESTINATION_APP} " **"
        fi
    done
  cf network-policies --source ${SOURCE_APP}
done