#!/bin/sh
set -e -u

cf_access_token=$(curl --user $CLIENT_ID:$CLIENT_SECRET -d "grant_type=client_credentials" https://uaa.sys.emea.vwapps.io/oauth/token)

access_token=$(echo $cf_access_token | jq -r '.access_token')

user_credentials=$(curl -H "Authorization: Bearer $access_token" $CREDENTIALS_ENDPOINT)
cf_api_url=$(echo $user_credentials | jq -r '.cf_api_url')
username=$(echo $user_credentials | jq -r '.username')
password=$(echo $user_credentials | jq -r '.password')

echo "↳ ☂ Securing endpoints on " $ENVIRONMENT
cf login -a $cf_api_url -u $username -p $password -o $CF_ORG -s $ENVIRONMENT

 app_name=$(cat ${manifest}  | grep "name:" | awk '{print $3}')

deploy_artifact()
{
cf push -p ${artifact_path} $new_app_name --no-start -f $manifest
echo "args : " $@
echo "===================="

  for i in "$@"
   do
   value=$(env | grep ^$i= | cut -d= -f2-)

   if [ -z  $value ]
   then
      echo "value is not passed for  "$i
   else
         cf set-env $new_app_name $i $value
   fi
  done
}

new_app_name=${app_name}-blue
deploy_artifact "$@"
route_real=$(cat ${manifest}  | grep "route:" | awk '{print $3}')
hostname_real="`echo ${route_real} | awk -F. '{print $1}'`"
domain=`echo ${route_real} | awk '{split($0,a,'\"${hostname_real}.\"'); print a[2] }'`

cf unmap-route ${new_app_name} ${domain} --hostname ${hostname_real}
cf create-route ${ENVIRONMENT} ${domain} --hostname ${hostname_real}-test
cf map-route ${new_app_name} ${domain} --hostname ${hostname_real}-test
if ! cf start $new_app_name; then
    echo "*** Failed to start blue app"
    exit 1
fi
