#!/bin/bash
set -e

cf_access_token=$(curl --user $CLIENT_ID:$CLIENT_SECRET -d "grant_type=client_credentials" https://uaa.sys.emea.vwapps.io/oauth/token)

access_token=$(echo $cf_access_token | jq -r '.access_token')

user_credentials=$(curl -H "Authorization: Bearer $access_token" $CREDENTIALS_ENDPOINT)
cf_api_url=$(echo $user_credentials | jq -r '.cf_api_url')
username=$(echo $user_credentials | jq -r '.username')
password=$(echo $user_credentials | jq -r '.password')

echo "↳ ☂ Securing endpoints on " $ENVIRONMENT
cf login -a $cf_api_url -u $username -p $password -o $CF_ORG -s $ENVIRONMENT

green_app=$(cat ${manifest}  | grep "name:" | awk '{print $3}')

blue_app=${green_app}-blue

if cf app  ${green_app}; then

    echo "when green app is exist then:"

    route_real="`cf app ${green_app} | grep 'routes:' | awk -v var='routes: ' '{print $2}'`"
    hostname_real="`echo ${route_real} | awk -F. '{print $1}'`"
    domain=`echo ${route_real} | awk '{split($0,a,'\"${hostname_real}.\"'); print a[2] }'`

    if ! cf map-route ${blue_app} ${domain} --hostname ${hostname_real}; then
        echo "*** Failed to map real route to blue app, Fallback version is up"
        exit 1
    fi

    cf unmap-route ${blue_app} ${domain} --hostname ${hostname_real}-test

    cf rename ${green_app}  ${green_app}-old

    cf rename ${blue_app} ${green_app}

    if [ "${ENVIRONMENT}" != "acceptance" ] && [ "${green_app}" != "user-auth-service" ] && [ "${green_app}" != "internal-mapping-service" ] && [ "${green_app}" != "internal-monitoring-service" ] && [ "${green_app}" != "monitoring-service" ]; then

        cf bind-service ${green_app} newrelic_${ENVIRONMENT}

        if ! cf restage ${green_app}; then
            cf delete ${green_app} -f
            cf rename ${green_app}-old ${green_app}
            echo "*** Failed to restage temp green app, Fallback version is up"
            exit 1
        fi
    fi

    cf delete ${green_app}-old -f

else
    echo "when green app does not exist then:"
    route_real="`cf app ${blue_app} | grep 'routes:' | awk -v var='routes: ' '{print $2}'`"
    hostname_blue="`echo ${route_real} | awk -F. '{print $1}'`"
    domain=`echo ${route_real} | awk '{split($0,a,'\"${hostname_blue}.\"'); print a[2] }'`

    hostname_real="`echo ${hostname_blue} | awk -F-test '{print $1}'`"

    if ! cf map-route ${blue_app} ${domain} --hostname ${hostname_real}; then
        echo "*** Failed to map real route to blue app"
        exit 1
    fi

    cf unmap-route ${blue_app} ${domain} --hostname ${hostname_blue}
    cf rename ${blue_app} ${green_app}
    if [ "${ENVIRONMENT}" != "acceptance" ] && [ "${green_app}" != "user-auth-service" ] && [ "${green_app}" != "internal-mapping-service" ] && [ "${green_app}" != "monitoring-service" ] && [ "${green_app}" != "internal-monitoring-service" ]; then
        cf bind-service ${green_app} newrelic_${ENVIRONMENT}
        cf restage ${green_app}
    fi
fi
