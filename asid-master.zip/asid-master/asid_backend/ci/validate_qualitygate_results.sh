#!/usr/bin/env bash

source ./build/sonar/report-task.txt
echo "Inside the validate Quality Gate Script file"
sonar_login=${sonarLogin}
sonar_host_url=${serverUrl}
task_id=${ceTaskId}
project_key=${projectKey}

task_info="./ce_task.json"
task_status="PENDING"
project_status='NONE'

function get_task_details {
  if [[ ! -z "${1}" ]] && [[ "${1}" != "" ]]; then
    flags="-s -L -u ${1}"
  fi
  url="${2}/api/ce/task?id=${3}&additionalField=stacktrace,scannerContext"
  cmd="curl ${flags} ${url}"
  ${cmd}
}

function get_project_status {
  if [[ ! -z "${1}" ]] && [[ "${1}" != "" ]]; then
    flags="-s -L -u ${1}"
  fi
  url="${2}/api/qualitygates/project_status?projectKey=${3}"
  cmd="curl ${flags} ${url}"
  ${cmd}
}


until [[ "${task_status}" != "PENDING" ]] && [[ "${task_status}" != "IN_PROGRESS" ]]; do

  get_task_details "${sonar_login}:" "${sonar_host_url}" "${task_id}" > "${task_info}"
  task_status=$(jq -r '.task.status // ""' < "${task_info}")

  if [[ "${task_status}" != "PENDING" ]] && [[ "${task_status}" != "IN_PROGRESS" ]]; then
    echo "Waiting for sonar to analyse results"
    sleep 5
  fi
done

if [[ "${task_status}" == "SUCCESS" ]]; then
  project_status_json="./qualitygate_project_status.json"
  get_project_status "${sonar_login}:" "${sonar_host_url}" "${project_key}" > "${project_status_json}"
  project_status=$(jq -r '.projectStatus.status // ""' < "${project_status_json}")
fi

printf "=================================\n"
if [[ "${project_status}" == "OK" ]]; then
    printf "QUALITY GATE PASSED\n"
    exit 0
fi
printf "QUALITY GATE NOT PASSED\n"
exit 1