#!/bin/sh
set -e
export ROOT_FOLDER=$( pwd )
        export GRADLE_USER_HOME="${ROOT_FOLDER}/.gradle"
        cd spring-boot-concourse/asid_backend
        ./gradlew :file-server:test