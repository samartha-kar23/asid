#!/bin/sh
node -v