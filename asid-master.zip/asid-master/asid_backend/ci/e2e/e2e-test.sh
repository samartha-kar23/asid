#!/usr/bin/env bash

set -o errexit

export TERM=dumb

sudo apt-get install jq

echo "printing newman version"

newman -version

echo "printing npm version"
npm --version

newman run asid_backend/e2e-test/asid-collections.postman_collection.json -e asid_backend/e2e-test/Sandbox_ASID.postman_environment.json --global-var e2e-whitelist-client-id=${E2E_CLIENT_ID} --global-var e2e-client-secret=${E2E_CLIENT_SECRET}

#newman run asid-collections.postman_collection.json -e Sandbox_ASID.postman_environment.json --globals ASID_Workspace.postman_globals.json
