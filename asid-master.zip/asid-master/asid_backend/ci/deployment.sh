#!/bin/sh
path=${1?Error: Enter correct smoke test path}
manifest_path=${2?Error: Enter correct manifest file path}
pwd

export CF_CLI_VERSION="6.34.1"
export CF_BGD_VERSION="1.3.0"
export CF_BGD_CHECKSUM="c74995ae0ba3ec9eded9c2a555e5984ba536d314cf9dc30013c872eb6b9d76b6"
export CF_BGD_TEMPFILE="/tmp/blue-green-deploy.linux64"

curl -L "https://cli.run.pivotal.io/stable?release=linux64-binary&version=${CF_CLI_VERSION}" | tar -zx -C /usr/local/bin
curl -L -o "${CF_BGD_TEMPFILE}" \
  "https://github.com/bluemixgaragelondon/cf-blue-green-deploy/releases/download/v${CF_BGD_VERSION}/blue-green-deploy.linux64" \
  && echo "${CF_BGD_CHECKSUM}  ${CF_BGD_TEMPFILE}" | sha256sum -c - \
  && chmod +x "${CF_BGD_TEMPFILE}" \
  && cf install-plugin -f "${CF_BGD_TEMPFILE}" \
  && rm "${CF_BGD_TEMPFILE}"

 cf login \
        -a ${CF_API_ENDPOINT} \
        -u ${CF_USER} \
        -p ${CF_PASS} \
        -o ${CF_ORG} \
        -s ${ENVIRONMENT}

cf blue-green-deploy ${APP_NAME} --smoke-test "${path}" -f ${manifest_path}
