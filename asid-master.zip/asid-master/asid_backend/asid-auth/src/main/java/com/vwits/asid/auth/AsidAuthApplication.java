package com.vwits.asid.auth;

import com.vwits.idkit.asid.utility.config.newrelic.NewRelicRequestFilter;
import com.vwits.idkit.asid.utility.config.proxy.ProxyConfiguration;
import com.vwits.idkit.asid.utility.config.proxy.ProxyRestTemplate;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import({ProxyConfiguration.class, ProxyRestTemplate.class})
public class AsidAuthApplication {


    @Bean
    public FilterRegistrationBean<NewRelicRequestFilter> loggingFilter(){
        FilterRegistrationBean<NewRelicRequestFilter> registrationBean
                = new FilterRegistrationBean<>();
        registrationBean.setFilter(new NewRelicRequestFilter());
        return registrationBean;
    }

    public static void main(String[] args) {
        SpringApplication.run(AsidAuthApplication.class, args);
    }

}
