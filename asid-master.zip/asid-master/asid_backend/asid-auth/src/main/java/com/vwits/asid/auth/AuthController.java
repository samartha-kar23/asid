package com.vwits.asid.auth;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED_VALUE;

@RestController
@Slf4j
public class AuthController {

    protected static final String CLIENT_ID_KEY = "client_id";
    protected static final String CLIENT_SECRET_KEY = "client_secret";
    protected static final String SERVICE_PATH_FOR_TOKEN = "token";

    private static final String GRANT_TYPE_KEY = "grant_type";
    private static final String PRECONDITIONS_FAILD_PREFIX = "Preconditions not met: Missing credentials in post body, need values for keys: ";
    @Autowired
    RestTemplate restTemplate;
    @Value("${identitykit.token-endpoint}")
    private String tokenUrl;
    @Value("${identitykit.grant-type}")
    private String grantType;

    @Autowired
    private Environment environment;

    @PostMapping(value = "/" + SERVICE_PATH_FOR_TOKEN, consumes = APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<String> getAuthToken(@RequestBody MultiValueMap<String, String> credentials) {

        if (!checkPreconditions(credentials))
            return ResponseEntity.badRequest().body(PRECONDITIONS_FAILD_PREFIX + CLIENT_SECRET_KEY + " and " + CLIENT_ID_KEY);

        return handleResponse(createIDKitRequest(credentials));
    }

    private ResponseEntity<String> handleResponse(HttpEntity<MultiValueMap<String, String>> request) {
        ResponseEntity<String> responseEntity;

        try {
            responseEntity = restTemplate.postForEntity(tokenUrl, request, String.class);
        } catch (HttpClientErrorException e) {
            log.error("Error while calling idkit ", e);
            responseEntity = new ResponseEntity<>(e.getStatusText(), e.getStatusCode());
        } catch (RuntimeException re) {
            log.error("The idkit service is unavailable ", re);
            responseEntity = new ResponseEntity(HttpStatus.SERVICE_UNAVAILABLE);
        }
        return responseEntity;
    }

    private HttpEntity<MultiValueMap<String, String>> createIDKitRequest(MultiValueMap<String, String> credentials) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add(GRANT_TYPE_KEY, grantType);
        map.add(CLIENT_ID_KEY, credentials.getFirst(CLIENT_ID_KEY));
        map.add(CLIENT_SECRET_KEY, credentials.getFirst(CLIENT_SECRET_KEY));

        return new HttpEntity<>(map, headers);
    }

    private boolean checkPreconditions(@RequestBody MultiValueMap<String, String> credentials) {
        return credentials.containsKey(CLIENT_SECRET_KEY) && credentials.containsKey(CLIENT_ID_KEY);
    }
}
