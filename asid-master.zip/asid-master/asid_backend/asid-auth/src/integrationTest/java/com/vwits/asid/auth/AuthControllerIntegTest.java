package com.vwits.asid.auth;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;

import java.net.URLEncoder;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("Test")
@AutoConfigureMockMvc
public class AuthControllerIntegTest {

    @Autowired
    MockMvc mvc;
    @Value("${identitykit.client-secret}")
    private String clientSecret;
    @Value("${identitykit.client-id}")
    private String clientId;


    @Test
    public void shouldReturnValidToken_forValidCredentials() throws Exception {

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_id", clientId);
        map.add("client_secret", clientSecret);
        final ResultActions response = mvc.perform(post("/token")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .content(buildUrlEncodedFormEntity(
                        "client_id", clientId,
                        "client_secret", clientSecret
                )))
                .andExpect(status().is(HttpStatus.OK.value()));

        response.andExpect(content().string(Matchers.containsString("\"access_token\":")));
        response.andExpect(content().string(Matchers.containsString("\"user_id\":\"" + clientId + "\"")));
        response.andExpect(content().string(Matchers.containsString("\"token_type\":\"bearer\"")));
        response.andExpect(content().string(Matchers.not(Matchers.containsString("\"access_token:{}\""))));

    }

    String buildUrlEncodedFormEntity(String... params) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < params.length; i += 2) {
            if (i > 0) result.append('&');
            result.append(URLEncoder.encode(params[i]))
                    .append('=')
                    .append(URLEncoder.encode(params[i + 1]));
        }
        return result.toString();
    }

    @Test
    public void shouldReturnUnauthorized_forInValidCredentials() {
        String invalidClientId = "invalid";
        String invalidClientSecret = "invalid";

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_id", invalidClientId);
        map.add("client_secret", invalidClientSecret);

        final ResultActions response;
        try {
            response = mvc.perform(post("/token")
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .content(buildUrlEncodedFormEntity(
                            "client_id", invalidClientId,
                            "client_secret", invalidClientSecret
                    ))).andExpect(status().is(HttpStatus.UNAUTHORIZED.value()));
        } catch (HttpClientErrorException e) {
            assertTrue(e.getMessage().contains("401"));

        } catch (Exception e) {
            e.printStackTrace();
            fail("there was an exception that should not occur");
        }
    }

}
