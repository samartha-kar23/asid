package com.vwits.asid.auth;

import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static com.vwits.asid.auth.AuthController.CLIENT_ID_KEY;
import static com.vwits.asid.auth.AuthController.CLIENT_SECRET_KEY;
import static com.vwits.asid.auth.AuthController.SERVICE_PATH_FOR_TOKEN;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class AuthSystemTests {
    private RestTemplate template = new RestTemplate();
    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("asid-auth", false);

    @Test
    public void getToken_itShouldGet401_whenInvalidCredentialsProvided() {
        try {
            String invalid = "invalid";
            getToken(invalid, invalid);
        } catch (HttpClientErrorException exception) {
            assertEquals(HttpStatus.UNAUTHORIZED.value(), exception.getRawStatusCode());
        }
    }

    @Test
    public void getToken_itShouldGet200_whenValidCredentialsProvided() {
        String clientId = System.getenv("identitykit.client-id");
        String clientSecret = System.getenv("identitykit.client-secret");

        ResponseEntity response = getToken(clientId, clientSecret);

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        assertNotNull(response.getBody());
    }


    private ResponseEntity getToken(String clientId, String clientSecret) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> map =
                new LinkedMultiValueMap<String, String>();
        map.add(CLIENT_ID_KEY, clientId);
        map.add(CLIENT_SECRET_KEY, clientSecret);

        HttpEntity<MultiValueMap<String, String>> entity =
                new HttpEntity<MultiValueMap<String, String>>(map, headers);

        ResponseEntity<String> responseEntity = template.exchange(serviceURL + "/" +SERVICE_PATH_FOR_TOKEN, HttpMethod.POST, entity, String.class);
        return responseEntity;
    }

}
