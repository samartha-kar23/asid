package com.vwits.asid.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.utility.entity.Token;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Ignore
public class AuthControllerTest {

    @Mock
    RestTemplate restTemplate;

    @InjectMocks
    AuthController authController;

    @Value("${identitykit.token-endpoint}")
    private static String TOKEN_URL;

    @Test
    public void shouldUseRestTemplateWithCredentialsFromOutside() {
        // given
        MultiValueMap<String, String> credsFromOutside = new LinkedMultiValueMap();
        credsFromOutside.add("client_id", "foo");
        credsFromOutside.add("client_secret", "secretfoo");
        ArgumentCaptor<HttpEntity<MultiValueMap<String, String>>> templateCaptor = ArgumentCaptor.forClass((Class)HttpEntity.class);

        // when
        authController.getAuthToken(credsFromOutside);
        // then
        verify(restTemplate).postForEntity(anyString(), templateCaptor.capture(), any());

        assertEquals("foo", templateCaptor.getValue().getBody().getFirst("client_id"));
        assertEquals("secretfoo", templateCaptor.getValue().getBody().getFirst("client_secret"));
        assertTrue(templateCaptor.getValue().getBody().containsKey("grant_type"));

    }

    @Test
    public void shouldThrowBadRequestWhenMapEntryIsMissing() {
        // given
        MultiValueMap<String, String> credsFromOutside = new LinkedMultiValueMap();
        // when
        ResponseEntity<String> realResponse = authController.getAuthToken(credsFromOutside);
        // then
        verifyZeroInteractions(restTemplate);
        assertEquals(HttpStatus.BAD_REQUEST, realResponse.getStatusCode());
    }

    @Test
    public void shouldThrowServiceUnavailableOnInternalRestTemplateErrors() {
        // given
        MultiValueMap<String, String> credsFromOutside = new LinkedMultiValueMap();
        credsFromOutside.add("client_id", "foo");
        credsFromOutside.add("client_secret", "secretfoo");
        when(restTemplate.postForEntity(eq(TOKEN_URL), any(), eq(String.class)))
                .thenThrow(new RuntimeException());
        // when
        ResponseEntity<String> realResponse = authController.getAuthToken(credsFromOutside);
        // then
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, realResponse.getStatusCode());
    }

    @Test
    public void shouldForwardAllRuntimeExceptionsWhenCallingIDKit() {
        // given
        MultiValueMap<String, String> credsFromOutside = new LinkedMultiValueMap();
        credsFromOutside.add("client_id", "foo");
        credsFromOutside.add("client_secret", "secretfoo");
        when(restTemplate.postForEntity(eq(TOKEN_URL), any(), eq(String.class)))
                .thenThrow(new ResourceAccessException("Someone pulled the plug"));
        // when
        ResponseEntity<String> realResponse = authController.getAuthToken(credsFromOutside);
        // then
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, realResponse.getStatusCode());
    }

    @Test
    public void shouldForwardAllHttpExceptionsWhenCallingIDKit() {
            // given
        MultiValueMap<String, String> credsFromOutside = new LinkedMultiValueMap();
        credsFromOutside.add("client_id", "foo");
        credsFromOutside.add("client_secret", "secretfoo");
        String expectedErrorBody = "Someone changed IDKit and we cannot cope with it";
        when(restTemplate.postForEntity(eq(TOKEN_URL), any(), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_ACCEPTABLE, expectedErrorBody));
        // when
        ResponseEntity<String> realResponse = authController.getAuthToken(credsFromOutside);
        // then
        assertEquals(HttpStatus.NOT_ACCEPTABLE, realResponse.getStatusCode());
        assertEquals(expectedErrorBody, realResponse.getBody());
    }

    @Test
    public void shouldGetAValidToken() throws IOException {
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_id", "valid id");
        map.add("client_secret", "valid secret");

        String mockedAccessToken = "valid token";
        final Token mockedToken = new Token().withAccessToken(mockedAccessToken);
        ObjectMapper objectMapper = new ObjectMapper();
        final String tokenJson = objectMapper.writeValueAsString(mockedToken);
        when(restTemplate.postForEntity(eq(TOKEN_URL), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(tokenJson, null, HttpStatus.OK));
        final ResponseEntity<String> authToken = authController.getAuthToken(map);
        final Token token = objectMapper.readValue(authToken.getBody(), Token.class);
        assertNotNull(token);
        assertEquals(mockedAccessToken, token.getAccessToken());
    }

    @Test
    public void shouldReturnUnauthorized_whenInvalidCredentialsPassed() {
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_id", "invalid id");
        map.add("client_secret", "invalid secret");

        final String expectedErrorMessage = "unauthorized credentials";
        final String mockedErrorMessage = "unauthorized credentials";
        when(restTemplate.postForEntity(eq(TOKEN_URL), any(), eq(String.class)))
                .thenReturn(new ResponseEntity<>(mockedErrorMessage, HttpStatus.UNAUTHORIZED));
        final ResponseEntity<String> authTokenErrorResponse = authController.getAuthToken(map);
        assertEquals(HttpStatus.UNAUTHORIZED, authTokenErrorResponse.getStatusCode());
        assertEquals(expectedErrorMessage, authTokenErrorResponse.getBody());
    }
}