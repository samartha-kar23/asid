package com.vwits.asid.authcodeflow.controller;

import com.vwits.asid.authcodeflow.entity.LaborTimeBlackList;
import com.vwits.asid.authcodeflow.entity.RepairManualBlackList;
import com.vwits.asid.authcodeflow.entity.UserAuthorization;
import com.vwits.asid.authcodeflow.repository.LaborTimeDealerAuthorizationRepository;
import com.vwits.asid.authcodeflow.repository.RepairManualDealerAuthorizationRepository;
import com.vwits.asid.authcodeflow.repository.UserAuthorizationRepository;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import static com.vwits.asid.authcodeflow.controller.AuthorizationController.VALIDATE_DEALER;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;


@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
public class AuthorizationControllerIntegTest {

    private String blacklistedDealer = "blacklistedDealer";
    private MultiValueMap<String, String> requestParams;
    private String validEmailId = "abc@xyz.com";

    @Autowired
    private MockMvc mvc;

    @Autowired
    private RepairManualDealerAuthorizationRepository repairManualDealerAuthorizationRepository;

    @Autowired
    private LaborTimeDealerAuthorizationRepository laborTimeDealerAuthorizationRepository;

    @Autowired
    private UserAuthorizationRepository userAuthorizationRepository;

    private static final String RL_INFO = "rlinfo";

    private static final String LT_INFO = "aposinfo";

    @Before
    public void setUp() {
        repairManualDealerAuthorizationRepository.save(new RepairManualBlackList(1, blacklistedDealer));
        laborTimeDealerAuthorizationRepository.save(new LaborTimeBlackList(1, blacklistedDealer));
        userAuthorizationRepository.save(new UserAuthorization(1, validEmailId, "ADMIN"));
    }

    @Test
    public void isDealerAuthorized_shouldReturnBooleanTrue_whenValidDealerIdProvidedForRL() throws Exception {

        createRequestParams(RL_INFO, blacklistedDealer);
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(VALIDATE_DEALER).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.content().string("true"));
    }

    @Test
    public void isDealerAuthorized_shouldReturnBooleanFalse_whenInvalidDealerIdProvidedForRL() throws Exception {
        createRequestParams(RL_INFO, "SuperMan");
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(VALIDATE_DEALER).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.content().string("false"));
    }

    @Test
    public void isDealerAuthorized_shouldReturnBooleanTrue_whenValidDealerIdProvidedForLT() throws Exception {

        createRequestParams(LT_INFO, blacklistedDealer);
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(VALIDATE_DEALER).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.content().string("true"));
    }

    @Test
    public void isDealerAuthorized_shouldReturnBooleanFalse_whenInvalidDealerIdProvidedForLT() throws Exception {
        createRequestParams(LT_INFO, "SuperMan");
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(VALIDATE_DEALER).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.content().string("false"));
    }


    @Test
    public void isUserAuthorized_shouldReturnBooleanTrue_whenValidEmailIdProvided() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("emailId", validEmailId);
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path("/").queryParams(params).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.content().string("true"));
    }

    @Test
    public void isUserAuthorized_shouldReturnBooleanFalse_whenInvalidEmailIdProvided() throws Exception {
        String invalidEmailId = "invalid@xyz.com";
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("emailId", invalidEmailId);
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path("/").queryParams(params).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.content().string("false"));
    }

    @After
    public void tearDown() {
        repairManualDealerAuthorizationRepository.deleteAll();
        laborTimeDealerAuthorizationRepository.deleteAll();
    }

    private void createRequestParams(String infoMediaType, String dealerId) {
        requestParams = new LinkedMultiValueMap<>();
        requestParams.add("dealerid", dealerId);
        requestParams.add("infomediatype", infoMediaType);
    }
}
