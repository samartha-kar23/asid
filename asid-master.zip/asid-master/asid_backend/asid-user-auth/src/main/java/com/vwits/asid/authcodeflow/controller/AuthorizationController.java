package com.vwits.asid.authcodeflow.controller;

import com.vwits.asid.authcodeflow.service.DealerAuthorizationService;
import com.vwits.asid.authcodeflow.service.UserAuthorizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthorizationController {
    @Autowired
    UserAuthorizationService authorizationService;

    @Autowired
    DealerAuthorizationService dealerAuthorizationService;

    public static final String VALIDATE_DEALER = "/validatedealer";

    @GetMapping
    public boolean isUserAuthorized(@RequestParam String emailId) {
        return authorizationService.isUserAuthorized(emailId);
    }


    @GetMapping(path = VALIDATE_DEALER)
    public boolean isDealerAuthorized(@RequestParam(name = "dealerid") String dealerId,@RequestParam(name = "infomediatype") String infoMediaType) {
       return dealerAuthorizationService.isDealerBlacklisted(dealerId,infoMediaType);
    }
}
