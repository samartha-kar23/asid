package com.vwits.asid.authcodeflow.repository;

import com.vwits.asid.authcodeflow.entity.UserAuthorization;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserAuthorizationRepository extends CrudRepository<UserAuthorization,Integer> {
    List<String> findRolesByEmailId(String emailId);
}
