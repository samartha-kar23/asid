package com.vwits.asid.authcodeflow.service;

import com.vwits.asid.authcodeflow.repository.UserAuthorizationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserAuthorizationService {

    public static final String USER_AUTHORIZATION_TABLE = "user_authorization";

    @Autowired
    UserAuthorizationRepository userAuthorizationRepository;

    public boolean isUserAuthorized(String emailId) {
        return !(userAuthorizationRepository.findRolesByEmailId(emailId).isEmpty());
    }
}
