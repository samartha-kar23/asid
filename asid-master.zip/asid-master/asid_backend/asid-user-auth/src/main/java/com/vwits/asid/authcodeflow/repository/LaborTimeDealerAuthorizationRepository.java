package com.vwits.asid.authcodeflow.repository;

import com.vwits.asid.authcodeflow.entity.LaborTimeBlackList;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaborTimeDealerAuthorizationRepository extends CrudRepository<LaborTimeBlackList, Integer> {
    int countAllByDealerId(String dealerId);
}
