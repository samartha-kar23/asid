package com.vwits.asid.authcodeflow.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Wither;

import javax.persistence.*;

import static com.vwits.asid.authcodeflow.service.UserAuthorizationService.USER_AUTHORIZATION_TABLE;


@NoArgsConstructor
@Data
@Wither
@Entity
@AllArgsConstructor
@Table(name = USER_AUTHORIZATION_TABLE)
public class UserAuthorization {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer id;
    String emailId;
    String role;
}
