package com.vwits.asid.authcodeflow.service;


import com.vwits.asid.authcodeflow.repository.LaborTimeDealerAuthorizationRepository;
import com.vwits.asid.authcodeflow.repository.RepairManualDealerAuthorizationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DealerAuthorizationService {

    @Autowired
    private LaborTimeDealerAuthorizationRepository laborTimeDealerAuthorizationRepository;

    @Autowired
    private RepairManualDealerAuthorizationRepository repairManualDealerAuthorizationRepository;

    private static final String RL_INFO = "rlinfo";

    private static final String LT_INFO = "aposinfo";

    public boolean isDealerBlacklisted(String dealerId, String infoMediaType) {
        switch (infoMediaType) {
            case RL_INFO:
                return repairManualDealerAuthorizationRepository.countAllByDealerId(dealerId) > 0;
            case LT_INFO:
                return laborTimeDealerAuthorizationRepository.countAllByDealerId(dealerId) > 0;
            default:
                return false;
        }

    }
}
