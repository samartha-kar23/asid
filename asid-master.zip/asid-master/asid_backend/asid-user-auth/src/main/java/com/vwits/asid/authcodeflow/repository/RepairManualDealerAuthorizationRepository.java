package com.vwits.asid.authcodeflow.repository;

import com.vwits.asid.authcodeflow.entity.RepairManualBlackList;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepairManualDealerAuthorizationRepository extends CrudRepository<RepairManualBlackList, Long> {
    int countAllByDealerId(String dealerId);
}
