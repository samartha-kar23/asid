package com.vwits.asid.authcodeflow.service;

import com.vwits.asid.authcodeflow.repository.UserAuthorizationRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserAuthorizationServiceTest {

    @InjectMocks
    UserAuthorizationService authorizationService;

    @Mock
    UserAuthorizationRepository userAuthorizationRepository;

    @Test
    public void isUserAuthorized_itShouldReturnTrue_whenJWTTokenProvidesAValidEmailId(){
        String token="testUser";
        when(userAuthorizationRepository.findRolesByEmailId(token)).thenReturn(Collections.singletonList("ADMIN"));
        boolean actualResult=authorizationService.isUserAuthorized(token);
        assertTrue(actualResult);
    }

    @Test
    public void isUserAuthorized_itShouldReturnfalse_whenEmailIdIsInvalid(){
        String userId="testUser";
        when(userAuthorizationRepository.findRolesByEmailId(userId)).thenReturn(Collections.emptyList());
        boolean actualResult=authorizationService.isUserAuthorized(userId);
        assertFalse(actualResult);
    }
}