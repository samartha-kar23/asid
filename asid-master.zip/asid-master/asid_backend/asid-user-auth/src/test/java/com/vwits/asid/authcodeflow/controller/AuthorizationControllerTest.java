package com.vwits.asid.authcodeflow.controller;

import com.vwits.asid.authcodeflow.service.DealerAuthorizationService;
import com.vwits.asid.authcodeflow.service.UserAuthorizationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AuthorizationControllerTest {

    @Mock
    private DealerAuthorizationService dealerAuthorizationService;

    @Mock
    private UserAuthorizationService userAuthorizationService;

    @InjectMocks
    private AuthorizationController authorizationController;

    private String validDealerId = "validDealerId";

    private static final String RL_INFO = "rlinfo";

    @Test
    public void isDealerAuthorized_shouldReturnBooleanTrue_whenValidDealerIdAndInfoMediaTypeProvided() {
        when(dealerAuthorizationService.isDealerBlacklisted(validDealerId, RL_INFO)).thenReturn(true);
        assertTrue(authorizationController.isDealerAuthorized(validDealerId, RL_INFO));
    }

    @Test
    public void isDealerAuthorized_shouldReturnBooleanFalse_whenInvalidDealerIdAndInfoMediaTypeProvided() {
        String invalid_dealerId = "invalid_dealerId";
        when(dealerAuthorizationService.isDealerBlacklisted(invalid_dealerId, RL_INFO)).thenReturn(false);
        assertFalse(authorizationController.isDealerAuthorized(invalid_dealerId, RL_INFO));
    }

    @Test
    public void isDealerAuthorized_shouldReturnBooleanFalse_whenValidDealerIdAndInvalidInfoMediaTypeProvided() {
        when(dealerAuthorizationService.isDealerBlacklisted(validDealerId, "Invalid_infoMedia")).thenReturn(false);
        assertFalse(authorizationController.isDealerAuthorized(validDealerId, "Invalid_infoMedia"));
    }

    @Test
    public void isUserAuthorized_shouldReturnBooleanTrue_whenValidEmailIdProvided() {
        String validEmailId = "abc@xyz.com";
        when(userAuthorizationService.isUserAuthorized(validEmailId)).thenReturn(true);
        assertTrue(authorizationController.isUserAuthorized(validEmailId));
    }

    @Test
    public void isUserAuthorized_shouldReturnBooleanFalse_whenInvalidEmailIdProvided() {
        String inValidEmailId = "invalid@xyz.com";
        when(userAuthorizationService.isUserAuthorized(inValidEmailId)).thenReturn(false);
        assertFalse(authorizationController.isUserAuthorized(inValidEmailId));
    }
}
