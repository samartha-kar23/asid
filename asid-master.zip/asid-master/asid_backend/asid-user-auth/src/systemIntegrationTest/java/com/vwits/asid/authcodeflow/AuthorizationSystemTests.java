package com.vwits.asid.authcodeflow;

import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import static org.hamcrest.Matchers.containsString;

public class AuthorizationSystemTests {

    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("asid-user-auth", true);

    private RestTemplate template = new RestTemplate();

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void shouldNotBeReachablePublicy() {
        thrown.expect(ResourceAccessException.class);
        thrown.expectMessage(containsString("apps.internal"));
        template.exchange(serviceURL, HttpMethod.GET, null, String.class);
    }
}
