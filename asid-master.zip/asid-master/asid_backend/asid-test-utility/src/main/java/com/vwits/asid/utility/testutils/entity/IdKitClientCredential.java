package com.vwits.asid.utility.testutils.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@Getter
@Slf4j
public class IdKitClientCredential {
    private String tokenURL;
    private String clientId;
    private String secret;
    private String grantType;


    public IdKitClientCredential() {
        this.secret = System.getenv("identitykit.client-secret");
        this.clientId = System.getenv("identitykit.client-id");
        this.tokenURL = System.getenv("identitykit.token-endpoint");
        this.grantType = System.getenv("identitykit.grant-type");
    }

}
