package com.vwits.asid.utility.testutils;


import com.vwits.asid.utility.testutils.entity.IdKitClientCredential;
import com.vwits.asid.utility.testutils.entity.Token;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

public class TokenUtil {

    private static IdKitClientCredential idKitCredential = new IdKitClientCredential();
    private static TestRestTemplate restTemplate = new TestRestTemplate();

    private TokenUtil() {
    }

    public static String getToken(RestTemplate restTemplate, IdKitClientCredential idKitCredential) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_secret", idKitCredential.getSecret());
        map.add("client_id", idKitCredential.getClientId());
        map.add("grant_type", idKitCredential.getGrantType());

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
        final ResponseEntity<Token> response = restTemplate.postForEntity(idKitCredential.getTokenURL(), request, Token.class);
        return response.getBody().getAccessToken();
    }

    public static String getToken() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_secret", idKitCredential.getSecret());
        map.add("client_id", idKitCredential.getClientId());
        map.add("grant_type", idKitCredential.getGrantType());

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
        final ResponseEntity<Token> response = restTemplate.postForEntity(idKitCredential.getTokenURL(), request, Token.class);
        return response.getBody().getAccessToken();
    }
}
