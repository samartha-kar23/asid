package com.vwits.asid.utility.testutils;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;

public class SubjectUrlProvider {

    private SubjectUrlProvider() {
        
    }

    private static String getEnvironmentDependentSubjectURL(String domain, String protocol) {
        JSONObject vcap = parseVcap();
        if (vcap != null) {
            String name = (String) vcap.get("name");
            String stage = (String) vcap.get("space_name");
            String subjectUrl = protocol + name + "-" + stage + "." + domain;
            System.out.println(" returning subject url from computed from cf" + subjectUrl);
            return subjectUrl;
        }
        return null;
    }

    public static String provideSITSubjectUrl(String defaultName, boolean isInternal) {
        String subjectUrlFromCI = System.getenv("subject.url");
        if (subjectUrlFromCI != null && subjectUrlFromCI.length() > 0) {
            return subjectUrlFromCI;
        }
        System.out.println("Computing subject url for SIT");
        String publicDomain = "apps.emea.vwapps.io";
        String internalDomain = "apps.internal:8080";

        String domain = isInternal ? internalDomain : publicDomain;
        String protocol = isInternal ? "http://" : "https://";

        String locallyUsedServiceURL = protocol + defaultName + "-development." + domain;

        String subjectUrl = getEnvironmentDependentSubjectURL(domain, protocol);
        if (subjectUrl != null) return subjectUrl;
        System.out.println("returning SIT Subject Url " + locallyUsedServiceURL);
        return locallyUsedServiceURL;
    }

    private static JSONObject parseVcap() {
        String vcap = System.getenv("VCAP_APPLICATION");
        if (vcap == null) {
            System.out.println("Failed to read VCAP_Application");
            return null;
        }
        System.out.println("VCAP_Application from environment: " + vcap);
        JSONParser parser = new JSONParser();
        JSONObject jsonObject = null;
        try {
            Object obj = parser.parse(vcap);
            jsonObject = (JSONObject) obj;
        } catch (Exception e) {
            System.out.println("Failed to parse VCAP_Application");
            return null;
        }
        System.out.println("VCAP_Application" + jsonObject.toString());
        return jsonObject;
    }

}
