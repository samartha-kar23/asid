package com.vwits.asid.utility.testutils.constant;

public interface ASIDTestConstants {

    /** This will remained unchanged for RL, LT and parts **/
    String VALID_ASID = "831X5751";

    /** This will remained unchanged for SLP EBO info media**/
    String VALID_ASID_FOR_SLP_EBO = "831X5751";

    String VALID_RL_ID = "kma.57.1.1";

    String VALID_LT_ID = "507390";

    String VALID_ML_CODE = "N764";

    String INVALID_ASID = "xxxxx";

}
