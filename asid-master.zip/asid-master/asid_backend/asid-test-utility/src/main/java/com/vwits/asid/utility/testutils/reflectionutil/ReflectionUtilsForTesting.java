package com.vwits.asid.utility.testutils.reflectionutil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.context.ConfigurableWebApplicationContext;

import java.lang.reflect.Field;

public class ReflectionUtilsForTesting {

    /**
     * reflectively wire a field value into a test subject.
     */
    public static void injectField(Object target, String name, Class<?> fieldClass, Object value) {
        final Field field = findField(target, name, fieldClass);

        ReflectionUtils.setField(field, target, value);
    }

    public static void injectAnyField(Object target, String name, Class<?> fieldClass, Object value) {
        Field field = ReflectionUtils.findField(target.getClass(),name, fieldClass );
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, target , value);
    }

    /**
     * reflectively wire a field value into a test subject.
     */
    public static void injectField(Object target, String name, Class<?> fieldClass, String qualifier, Object value) {
        if (qualifier == null) throw new IllegalArgumentException("null qualifier");

        final Field field = findField(target, name, fieldClass);
        final Qualifier qualifierAnnotation = field.getAnnotation(Qualifier.class);
        if (qualifierAnnotation == null || !qualifierAnnotation.value().equals(qualifier)) {
            throw new RuntimeException("\"" + name + "\" field not qualified with \"" + qualifier + "\" on " + target);
        }

        ReflectionUtils.setField(field, target, value);
    }

    private static Field findField(Object target, String name, Class<?> valueClass) {
        if (target == null) throw new IllegalArgumentException("null target");

        Field field = ReflectionUtils.findField(target.getClass(), name, valueClass);
        if (field == null) {
            throw new RuntimeException("\"" + name + "\" field not found on " + target);
        }

        final Autowired autowiredAutowired = field.getAnnotation(Autowired.class);
        if (autowiredAutowired == null) {
            throw new RuntimeException("\"" + name + "\" field not @Autowired on " + target);
        }

        ReflectionUtils.makeAccessible(field);
        return field;
    }


    public static ConfigurableWebApplicationContext startSpringBootApplicationWithAdditionalProfile(Class springBootApplicationClass, String... additionalProfiles) {
        SpringApplication springApplication=new SpringApplication(springBootApplicationClass);
        springApplication.setAdditionalProfiles(additionalProfiles);
        return  (ConfigurableWebApplicationContext) springApplication.run();
    }
}

