package com.vwits.asid.etka.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Wither;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@Wither
public class ASInfo implements Serializable {
    private String vin;
    private String brand;
    @JsonProperty("ETKA")
    private PartsInfoWithStatus partsInfoWithStatus;
    private String lang;
    private String country;
    private String asid;
}