package com.vwits.asid.etka.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Wither;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Wither
public class PartsInfo {
    @JsonProperty("Illustration")
    private String illustration;

    @JsonProperty("Quantity")
    private String quantity;
    @JsonProperty("Price")
    private Price price;
    @JsonProperty("RemarkLine")
    private String remarkLine;
    @JsonProperty("PartNumber")
    private String partNumber;
    @JsonProperty("DenominationLine")
    private String[] denominationLine;

}
