package com.vwits.asid.etka;

import com.vwits.asid.etka.entity.ASInfo;
import com.vwits.asid.etka.entity.PartsInfo;
import com.vwits.asid.etka.entity.PartsInfoDTO;
import com.vwits.asid.etka.entity.PartsInfoWithStatus;
import com.vwits.asid.utils.Utility;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.net.HttpHeaders.ACCEPT;
import static com.google.common.net.HttpHeaders.AUTHORIZATION;
import static com.vwits.asid.utility.GeneralUtility.isEmpty;
import static com.vwits.asid.utils.ApplicationConstants.*;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.MediaType.APPLICATION_XML_VALUE;

@Service
public class ETKAService {

    @Autowired
    RestTemplate restTemplate;
    @Autowired
    Environment env;
    private String etkaServiceUrl;
    private String etkaUserName;
    private String etkaServicePassword;

    @Value(ENV_ETKA_URL)
    void setEtkaURL(final String url) {
        this.etkaServiceUrl = url;
    }

    @Value(ENV_ETKA_USERNAME)
    void setEtkaUserName(final String userName) {
        this.etkaUserName = userName;
    }

    @Value(ENV_ETKA_PASS)
    void setEtkaPassword(final String password) {
        this.etkaServicePassword = password;
    }

    ASInfo getPartsInformationFromETKA(String asid, String vin, String language, String country, String brand) throws IOException {
        String etkaRequestType = "ETKA";
        String xml = makeRequestToETKA(asid, vin, language, country, brand, etkaRequestType);
        String utf8DecodedXML = new String(xml.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
        return Utility.parsePartInformationXML(utf8DecodedXML);
    }

    String makeRequestToETKA(String asid, String vin, String language, String country, String brand, String type) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(etkaServiceUrl)
                .queryParam("country", country)
                .queryParam("lang", language)
                .queryParam("vin", vin)
                .queryParam("brand", brand)
                .queryParam("asid", asid)
                .queryParam("type", type);

        HttpEntity<String> entity = new HttpEntity<>(createHeaders(etkaUserName, etkaServicePassword));

        final URI url = builder.build().toUri();
        final ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        if (isNoContent(responseEntity))
            return "";
        String responseBody = responseEntity.getBody();
        if (isRejected(responseBody))
            responseBody = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();
        return responseBody;
    }

    private boolean isNoContent(ResponseEntity<String> responseEntity) {
        return responseEntity.getStatusCode().equals(NO_CONTENT);
    }

    private boolean isRejected(String responseBody) {
        return responseBody.contains("rejected");
    }

    private HttpHeaders createHeaders(final String username, final String password) {
        HttpHeaders headers = new HttpHeaders();
        String authHeader = encodeAuthHeaders(username, password);
        headers.set(AUTHORIZATION, authHeader);
        headers.add(CONTENT_TYPE, APPLICATION_XML_VALUE);
        headers.add(ACCEPT, APPLICATION_XML_VALUE);
        return headers;
    }

    private String encodeAuthHeaders(String username, String password) {
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(
                auth.getBytes(StandardCharsets.US_ASCII));
        return "Basic " + new String(encodedAuth);
    }

    public List<PartsInfoDTO> getPartInformation(String asid, String vin, String language, String country, String brand) throws IOException {

        final PartsInfoWithStatus partsInfoWithStatus = getPartsInformationFromETKA(asid, vin, language, country, brand).getPartsInfoWithStatus();

        if (partsInfoNotAvailable(partsInfoWithStatus)) return new ArrayList<>();

        return transformToPartsInfoDTO(partsInfoWithStatus.getPartsInfoArray());
    }

    private boolean partsInfoNotAvailable(PartsInfoWithStatus partsInfoWithStatus) {
        return partsInfoWithStatus == null || partsInfoWithStatus.getStatus() == null
                || partsInfoWithStatus.getStatus().equals(NO_CONTENT.toString())
                || isEmpty(partsInfoWithStatus.getPartsInfoArray());
    }

    private List<PartsInfoDTO> transformToPartsInfoDTO(PartsInfo[] partsInfoList) {
        List<PartsInfoDTO> partsInfoDTOList = new ArrayList<>();
        for (PartsInfo partsInfo : partsInfoList) {
            PartsInfoDTO partsInfoDTO = new PartsInfoDTO(partsInfo);
            partsInfoDTOList.add(partsInfoDTO);
        }
        return partsInfoDTOList;
    }
}
