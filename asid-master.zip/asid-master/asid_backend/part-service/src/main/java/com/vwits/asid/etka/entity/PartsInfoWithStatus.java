package com.vwits.asid.etka.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Wither;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Wither
public class PartsInfoWithStatus implements Serializable {
    private String status;
    @JsonProperty("ETKAPosition")
    private PartsInfo[] partsInfoArray;
}
