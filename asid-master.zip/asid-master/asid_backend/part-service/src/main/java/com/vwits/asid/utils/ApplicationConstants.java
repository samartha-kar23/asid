package com.vwits.asid.utils;

public final class  ApplicationConstants {

    private ApplicationConstants() {
    }

    public static final String PART_INFO_API = "/partsinfo";
    public static final String ENV_ETKA_URL = "${etka-service-url}";
    public static final String ENV_ETKA_USERNAME = "${etka-service-username}";
    public static final String ENV_ETKA_PASS = "${etka-service-password}";
}
