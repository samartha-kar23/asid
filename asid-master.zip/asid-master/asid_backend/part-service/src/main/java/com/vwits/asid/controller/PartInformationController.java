package com.vwits.asid.controller;

import com.newrelic.api.agent.NewRelic;
import com.vwits.asid.etka.ETKAService;
import com.vwits.asid.etka.entity.PartsInfoDTO;
import com.vwits.asid.utility.GeneralUtility;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

import static com.vwits.asid.utility.GeneralUtility.isEmpty;
import static com.vwits.asid.utils.ApplicationConstants.PART_INFO_API;

@RestController
public class PartInformationController {

    @Autowired
    private ETKAService etkaService;

    @ApiOperation(value = "This API helps in getting information about different parts like cost, description etc")
    @ApiResponses({@ApiResponse(code = 200, message = "Success",response = PartsInfoDTO[].class), @ApiResponse(code = 204, message = "No Content", response = Object.class), @ApiResponse(code = 401, message = "UnAuthorised Access"), @ApiResponse(code = 400, message = "Bad Request")})
    @GetMapping(value = PART_INFO_API, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getPartInformationFromASInfo(@ApiParam(value = "After Sales Id , e.g. 017X9422", example = "017X9422") @RequestParam String asid,
                                                       @ApiParam(value = "Vehicle Identification Number , e.g. WVWZZZ3HZJE123456", example = "WVWZZZ3HZJE123456") @RequestParam String vin,
                                                       @ApiParam(value = "Language, e.g. en", example = "en") @RequestParam(name = "lang") String language,
                                                       @ApiParam(value = "Country, e.g. DE", example = "DE") @RequestParam String country,
                                                       @ApiParam(value = "Brand, e.g. V", example = "V") @RequestParam String brand,
                                                       @ApiParam(value = "App Name, e.g. devs", example = "devs") @RequestParam(name = "appname") String appName,
                                                       @ApiParam(value = "Dealer Id, e.g. ASIDTESTS", example = "ASIDTESTS") @RequestParam(required = false, name = "dealerid") String dealerId) throws IOException {
        setupNewRelicParams(vin, asid, language, country,brand, dealerId, appName);

        List<PartsInfoDTO> partsInfoDTOList = etkaService.getPartInformation(asid, vin, language, country, brand);

        if (isEmpty(partsInfoDTOList)) return ResponseEntity.noContent().build();

        return ResponseEntity.ok(partsInfoDTOList);
    }



    private void setupNewRelicParams(String vin, String asid, String language, String country, String brand, String dealerId, String appName) {
        NewRelic.setTransactionName("Web", "repair_manual");
        NewRelic.addCustomParameter("dealerId", dealerId);
        NewRelic.addCustomParameter("asid", asid);
        NewRelic.addCustomParameter("language", language);
        NewRelic.addCustomParameter("country", country);
        NewRelic.addCustomParameter("brand", brand);
        NewRelic.addCustomParameter("appname", appName);
        NewRelic.addCustomParameter("salestype", GeneralUtility.extractSalesTypeFromVIN(vin));

    }
}
