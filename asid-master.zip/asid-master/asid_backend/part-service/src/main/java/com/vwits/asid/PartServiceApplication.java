package com.vwits.asid;

import com.vwits.idkit.asid.utility.config.auth.IncomingSecurityUsingIDKitConfig;
import com.vwits.idkit.asid.utility.config.proxy.ProxyConfiguration;
import com.vwits.idkit.asid.utility.config.proxy.ProxyRestTemplate;
import com.vwits.idkit.asid.utility.config.swagger.SwaggerConfiguration;
import com.vwits.idkit.asid.utility.config.swagger.SwaggerNoAuthConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@Import({IncomingSecurityUsingIDKitConfig.class, ProxyConfiguration.class, ProxyRestTemplate.class, SwaggerConfiguration.class, SwaggerNoAuthConfiguration.class})
public class PartServiceApplication {

    @Profile("!cloud")
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    public static void main(String[] args) {
        SpringApplication.run(PartServiceApplication.class, args);
    }
}
