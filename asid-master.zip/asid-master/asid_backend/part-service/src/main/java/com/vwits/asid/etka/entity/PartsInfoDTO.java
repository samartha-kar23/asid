package com.vwits.asid.etka.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Wither;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Wither
public class PartsInfoDTO {
    // TODO: 08/10/18 This class should be removed after lexcom start giving remark_line instead of RemarkLine for ex.
    @JsonProperty("illustration")
    private String illustration;
    @JsonProperty("quantity")
    private String quantity;
    @JsonProperty("price")
    private Price price;
    @JsonProperty("remark_line")
    private String remarkLine;
    @JsonProperty("part_number")
    private String partNumber;
    @JsonProperty("denomination_line")
    private String[] denominationLine;

    public PartsInfoDTO(PartsInfo partsInfo) {
        setDenominationLine(partsInfo.getDenominationLine());
        setIllustration(partsInfo.getIllustration());
        setPartNumber(partsInfo.getPartNumber());
        setPrice(partsInfo.getPrice());
        setQuantity(partsInfo.getQuantity());
        setRemarkLine(partsInfo.getRemarkLine());
    }

}
