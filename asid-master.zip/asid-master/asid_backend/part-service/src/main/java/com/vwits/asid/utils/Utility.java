package com.vwits.asid.utils;

import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.vwits.asid.etka.entity.ASInfo;

import java.io.IOException;

import static org.springframework.util.StringUtils.isEmpty;

public class Utility {
    private Utility() {
    }

    public static ASInfo parsePartInformationXML(String xml) throws IOException {
        if (isEmpty(xml))
            return new ASInfo();
        JacksonXmlModule module = new JacksonXmlModule();
        module.setDefaultUseWrapper(false);
        XmlMapper objectMapper = new XmlMapper(module);
        return objectMapper.readValue(xml, ASInfo.class);
    }
}
