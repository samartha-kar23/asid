package com.vwits.asid.etka;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockClassRule;
import com.vwits.asid.etka.entity.PartsInfo;
import com.vwits.asid.etka.entity.PartsInfoDTO;
import com.vwits.asid.utility.testutils.SpringTestWithMockIDKit;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.google.common.net.HttpHeaders.ACCEPT;
import static com.vwits.asid.utility.testutils.IntegTestHelper.getMockTokenForIdKit;
import static com.vwits.asid.utils.ApplicationConstants.ENV_ETKA_PASS;
import static com.vwits.asid.utils.ApplicationConstants.ENV_ETKA_USERNAME;
import static com.vwits.asid.utils.ApplicationConstants.PART_INFO_API;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.MediaType.APPLICATION_XML_VALUE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringTestWithMockIDKit
@AutoConfigureMockMvc
@ActiveProfiles("acc")
public class PartInfoControllerTest {

    @Autowired
    private MockMvc mvc;

    private MultiValueMap<String, String> requestParams;
    private ArrayList<PartsInfo> expectedETKAPositionList = new ArrayList<>();
    private ObjectMapper mapper = new ObjectMapper();
    private String token;
    private String etkaResponse;

    @Value(ENV_ETKA_USERNAME)
    private String etkaUserName;

    @Value(ENV_ETKA_PASS)
    private String etkaServicePassword;


    @ClassRule
    public static WireMockClassRule etkaServiceMockRule = new WireMockClassRule(8447);

    @Rule
    public WireMockClassRule etkaServiceMock = etkaServiceMockRule;

    @Before
    public void init() {
        token = getMockTokenForIdKit();

        requestParams = new LinkedMultiValueMap<>();
        requestParams.add("appname", "dev");

        expectedETKAPositionList = new ArrayList<>();
        PartsInfo etkaPosition = new PartsInfo();

        expectedETKAPositionList.add(etkaPosition);

        etkaResponse = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<ASInfo country=\"DE\" lang=\"DE\" vin=\"WVWZZZ3HZHE700154\" brand=\"V\" asid=\"906X1705\">\n" +
                "    <ETKA status=\"ok\">\n" +
                "        <ETKAPosition>\n" +
                "            <Illustration>130-010</Illustration>\n" +
                "            <PartNumber>03N906054</PartNumber>\n" +
                "            <DenominationLine>Drucksensor</DenominationLine>\n" +
                "            <RemarkLine>M18X1,5</RemarkLine>\n" +
                "            <Quantity> 1</Quantity>\n" +
                "            <Price currency=\"EUR\">84.40</Price>\n" +
                "        </ETKAPosition>\n" +
                "    </ETKA>\n" +
                "</ASInfo>";

        generateAllStub();
    }

    private void generateAllStub() {
        String authHeader = "ZXRrYVVzZXI6ZXRrYVBhc3M=";

        etkaServiceMock.stubFor(WireMock.get(anyUrl())
                .withHeader(AUTHORIZATION, matching("Basic " + authHeader))
                .withHeader(CONTENT_TYPE, matching(APPLICATION_XML_VALUE))
                .withHeader(ACCEPT, matching(APPLICATION_XML_VALUE))
                .withQueryParam("country", equalTo("DE"))
                .withQueryParam("lang", equalTo("DE"))
                .withQueryParam("vin", equalTo("WVWZZZ3HZHE700154"))
                .withQueryParam("brand", equalTo("V"))
                .withQueryParam("asid", equalTo("906X1705"))
                .withQueryParam("type", equalTo("ETKA"))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withBody(etkaResponse)
                        .withStatus(OK.value())));


        etkaServiceMock.stubFor(WireMock.get(anyUrl())
                .withHeader(AUTHORIZATION, matching("Basic " + authHeader))
                .withHeader(CONTENT_TYPE, matching(APPLICATION_XML_VALUE))
                .withHeader(ACCEPT, matching(APPLICATION_XML_VALUE))
                .withQueryParam("country", equalTo("dummy"))
                .withQueryParam("lang", equalTo("dummy"))
                .withQueryParam("vin", equalTo("dummy"))
                .withQueryParam("brand", equalTo("dummy"))
                .withQueryParam("asid", equalTo("dummy"))
                .withQueryParam("type", equalTo("ETKA"))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(NO_CONTENT.value())));


        etkaServiceMock.stubFor(WireMock.get(anyUrl())
                .withHeader(AUTHORIZATION, matching("Basic " + authHeader))
                .withHeader(CONTENT_TYPE, matching(APPLICATION_XML_VALUE))
                .withHeader(ACCEPT, matching(APPLICATION_XML_VALUE))
                .withQueryParam("country", equalTo("de"))
                .withQueryParam("lang", equalTo("DE"))
                .withQueryParam("vin", equalTo("WVWZZZ3HZHE700154"))
                .withQueryParam("brand", equalTo("V"))
                .withQueryParam("asid", equalTo("906X1705"))
                .withQueryParam("type", equalTo("ETKA"))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withBody(etkaResponse)
                        .withStatus(OK.value())));

        etkaServiceMock.stubFor(WireMock.get(anyUrl())
                .withHeader(AUTHORIZATION, matching("Basic " + authHeader))
                .withHeader(CONTENT_TYPE, matching(APPLICATION_XML_VALUE))
                .withHeader(ACCEPT, matching(APPLICATION_XML_VALUE))
                .withQueryParam("country", equalTo("DE"))
                .withQueryParam("lang", equalTo("de"))
                .withQueryParam("vin", equalTo("WVWZZZ3HZHE700154"))
                .withQueryParam("brand", equalTo("V"))
                .withQueryParam("asid", equalTo("906X1705"))
                .withQueryParam("type", equalTo("ETKA"))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withBody(etkaResponse)
                        .withStatus(OK.value())));

    }


    @Test
    public void getPartInformationFromASInfo_itShouldReturnPartInfo_whenASInfoIsValid() throws Exception {
        prepareQueryParams();

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer " + token);
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andReturn();

        PartsInfoDTO[] etkaPosition = mapper.readValue(mvcResult.getResponse().getContentAsString(), PartsInfoDTO[].class);
        assertTrue(etkaPosition.length > 0);
        assertNotNull(etkaPosition[0].getPrice());
    }

    @Test
    public void getLaborTime_ShouldFail_whenWrongTokenIsPassed() throws Exception {
        prepareQueryParams();

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        String wrongToken = "";
        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + wrongToken))
                .andExpect(status().is4xxClientError());
    }

    private void prepareQueryParams() {
        requestParams.add("asid", "906X1705");
        requestParams.add("country", "DE");
        requestParams.add("brand", "V");
        requestParams.add("lang", "DE");
        String vin = "WVWZZZ3HZHE700154";
        requestParams.add("vin", vin);

    }

    @Test
    public void getPartInformationFromASInfo_itShouldReturn204_whenASInfoIsValid_butNoDataForThatASInfo() throws Exception {
        requestParams.set("asid", "dummy");
        requestParams.set("country", "dummy");
        requestParams.set("brand", "dummy");
        requestParams.set("lang", "dummy");
        requestParams.set("vin", "dummy");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + token))
                .andExpect(status().isNoContent());
    }

    @Test
    public void shouldGiveDataEveryTime_withProperRequest() throws Exception {
        prepareQueryParams();

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn();
        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn();

    }

    @Test
    public void shouldForwardRequestWithCapsForCountry() throws Exception {
        prepareQueryParams();
        requestParams.remove("country");
        requestParams.add("country", "de");
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer " + token);
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andReturn();

        PartsInfoDTO[] etkaPosition = mapper.readValue(mvcResult.getResponse().getContentAsString(), PartsInfoDTO[].class);
        assertTrue(etkaPosition.length > 0);
    }

    @Test
    public void shouldForwardRequestWithCapsForLanguage() throws Exception {
        prepareQueryParams();
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        requestParams.remove("lang");
        requestParams.add("lang", "de");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer " + token);
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andReturn();

        PartsInfoDTO[] etkaPosition = mapper.readValue(mvcResult.getResponse().getContentAsString(), PartsInfoDTO[].class);
        assertTrue(etkaPosition.length > 0);
    }

    @Test
    public void shouldContainJsonPropertiesWithoutCamelCase() throws Exception {

        prepareQueryParams();

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer " + token);
        mvc.perform(get(urlTemplate)
                .contentType(MediaType.APPLICATION_JSON)
                .headers(httpHeaders))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"part_number\"")))
                .andExpect(content().string(not(containsString("partNumber"))))
                .andExpect(content().string(not(containsString("denominationLine"))))
                .andReturn();
    }

}
