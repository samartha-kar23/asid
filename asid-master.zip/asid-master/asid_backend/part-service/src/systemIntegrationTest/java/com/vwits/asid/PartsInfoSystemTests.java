package com.vwits.asid;

import com.vwits.asid.etka.entity.PartsInfo;
import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import com.vwits.asid.utility.testutils.entity.IdKitClientCredential;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

import static com.vwits.asid.utility.GeneralUtility.getHttpEntityWithHeaderToken;
import static com.vwits.asid.utility.testutils.TokenUtil.getToken;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_ASID;
import static com.vwits.asid.utils.ApplicationConstants.PART_INFO_API;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class PartsInfoSystemTests {
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    private IdKitClientCredential idKitCredential = new IdKitClientCredential();

    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("part-service", false);
    private RestTemplate template;
    private MultiValueMap<String, String> testData;

    @Before
    public void setUp() {
        testData = new LinkedMultiValueMap<>();
        testData.add("lang", "en");
        testData.add("country", "DE");
        testData.add("brand", "V");
        testData.add("vin", "WVWZZZ1JZ3U001121");
        testData.add("appname", "etka");
        testData.add("dealerid", "DEU05025V");
        template = new RestTemplate();
    }

    @Test
    public void getPartsInfo_itShouldGet2XX_ifCalledWithCorrectToken() {

        testData.add("asid", VALID_ASID);
        String validToken = getToken(template, idKitCredential);

        ResponseEntity<List<PartsInfo>> response = getPartsInformation(validToken, testData);

        assertTrue(response.getStatusCode().is2xxSuccessful());
    }

    @Test
    public void getPartsInfo_itShouldGet401_ifCalledWithInCorrectToken() {
        testData.add("asid", VALID_ASID);
        String invalidToken = "dummy token";

        thrown.expect(HttpClientErrorException.class);
        thrown.expectMessage(containsString("401 Unauthorized"));
        thrown.expect(hasProperty("statusCode", is(HttpStatus.UNAUTHORIZED)));
        thrown.expect(hasProperty("statusText", containsString("Unauthorized")));

        getPartsInformation(invalidToken, testData);

    }

    private ResponseEntity<List<PartsInfo>> getPartsInformation(String authToken, MultiValueMap<String, String> parameters) {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(PART_INFO_API).queryParams(parameters).build();
        HttpEntity<String> request = getHttpEntityWithHeaderToken(authToken);
        System.out.println("Calling part service with " + serviceURL);
        return template.exchange(serviceURL + uriComponents.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<PartsInfo>>() {
        });
    }

    @Test
    public void testSwaggerUrl() {
        if (serviceURL.contains("acceptance")) {
            String url = serviceURL + "/v2/api-docs?group=Swagger Specification for Part Service";
            ResponseEntity<String> forEntity = template.getForEntity(url, String.class);
            assertEquals(HttpStatus.OK.value(), forEntity.getStatusCode().value());
        } else {
            assertTrue("Test case is not applicable for this environment, hence skipping it", true);
        }
    }

}