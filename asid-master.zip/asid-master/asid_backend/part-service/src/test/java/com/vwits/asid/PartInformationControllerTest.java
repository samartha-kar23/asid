package com.vwits.asid;

import com.vwits.asid.controller.PartInformationController;
import com.vwits.asid.etka.ETKAService;
import com.vwits.asid.etka.entity.PartsInfoDTO;
import com.vwits.asid.etka.entity.Price;
import com.vwits.asid.utility.entity.BZD;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class PartInformationControllerTest {

    String asid = "1234";
    String lang = "EN";
    String country = "DE";
    String brand = "SUPERB";
    String appname = "etka";
    String vin = "vin";
    private String dealerid = "dealerid";

    ArrayList<PartsInfoDTO> expectedPartsInfoDTOList = new ArrayList<>();

    @Mock
    ETKAService etkaService;

    @InjectMocks
    PartInformationController partInformationController;
    private BZD bzd;

    @Before
    public void setUp() {
        bzd = new BZD();
        bzd.setBrand(brand);
        bzd.setCountry(country);
        bzd.setLang(lang);
    }

    @Test
    public void getPartInformationFromASInfo_itShouldReturnPartInformation_whenASInfoIsValid() throws Exception {

        // TODO: 08/10/18 Revert this
        PartsInfoDTO partsInfoDTO0 = new PartsInfoDTO("illustation", "quantity", new Price(), "remark", "part_number", new String[0]);
        PartsInfoDTO partsInfoDTO1 = new PartsInfoDTO("illustation", "quantity", new Price(), "remark", "part_number", new String[0]);
        expectedPartsInfoDTOList.add(partsInfoDTO0);
        expectedPartsInfoDTOList.add(partsInfoDTO1);

        Mockito.when(etkaService.getPartInformation(asid, vin, lang, country, brand)).thenReturn(expectedPartsInfoDTOList);

        ResponseEntity laborTimeInfo = partInformationController.getPartInformationFromASInfo(asid, vin, lang, country, brand, appname, dealerid);

        Assert.assertEquals(HttpStatus.OK, laborTimeInfo.getStatusCode());
        Assert.assertEquals(expectedPartsInfoDTOList, laborTimeInfo.getBody());
    }

    @Test
    public void getLaborTimeFromASInfo_itShouldNotLaborTime_whenASInfoIsValid() throws Exception {
        Mockito.when(etkaService.getPartInformation(asid, vin, lang, country, brand)).thenReturn(expectedPartsInfoDTOList);

        ResponseEntity laborTimeInfo = partInformationController.getPartInformationFromASInfo(asid, vin, lang, country, brand, appname, dealerid);

        Assert.assertEquals(HttpStatus.NO_CONTENT, laborTimeInfo.getStatusCode());
    }

    @Test
    public void shouldPassCapsCountryAndLangToEtkaCall() throws Exception {
        Mockito.when(etkaService.getPartInformation(asid, vin, lang, country, brand)).thenReturn(expectedPartsInfoDTOList);

        ResponseEntity<Object> laborTimeInfo = partInformationController.getPartInformationFromASInfo(asid, vin, lang, country, brand, appname, dealerid);
        verify(etkaService).getPartInformation(asid, vin, lang, country, brand);

        Assert.assertEquals(HttpStatus.NO_CONTENT, laborTimeInfo.getStatusCode());
    }
}
