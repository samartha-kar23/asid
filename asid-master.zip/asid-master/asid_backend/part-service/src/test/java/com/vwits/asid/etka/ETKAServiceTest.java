package com.vwits.asid.etka;

import com.vwits.asid.etka.entity.ASInfo;
import com.vwits.asid.etka.entity.PartsInfo;
import com.vwits.asid.etka.entity.PartsInfoDTO;
import com.vwits.asid.etka.entity.PartsInfoWithStatus;
import com.vwits.asid.utils.Utility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.List;

import static junit.framework.TestCase.assertNotNull;
import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.spy;

@RunWith(PowerMockRunner.class)
@PrepareForTest({Utility.class})
public class ETKAServiceTest {
    @Mock
    RestTemplate restTemplate;

    @InjectMocks
    ETKAService etkaService;
    String etkaDummyUrl = "http://google.com";
    private String country;
    private String language;
    private String vin;
    private String brand;
    private String asid;
    private String type;
    private String responseFromEtka;
    private UriComponentsBuilder builder;
    private String emptyPartsInfo;
    private String dealerid;

    @Before
    public void setUp() {
        responseFromEtka = "<ASInfo country=\"de\" lang=\"de\" vin=\"WVWZZZ3HZJE500087\" brand=\"V\" asid=\"906X1705\">\n" +
                "    <ETKA status=\"ok\">\n" +
                "        <ETKAPosition>\n" +
                "            <Illustration>130-000</Illustration>\n" +
                "            <PartNumber>04L906054</PartNumber>\n" +
                "            <DenominationLine>KÃ¼hlerlÃ¼fter mit LÃ¼fter-</DenominationLine>\n" +
                "            <RemarkLine>M18X1,5</RemarkLine>\n" +
                "            <Quantity> 1</Quantity>\n" +
                "            <Price></Price>\n" +
                "        </ETKAPosition>\n" +
                "    </ETKA>\n" +
                "</ASInfo>";
        emptyPartsInfo = "<ASInfo country=\"de\" lang=\"de\" vin=\"WVWZZZ3HZJE500087\" brand=\"V\" asid=\"906X1705\"></ASInfo>";
        country = "dummy";
        language = "dummy";
        vin = "dummy";
        brand = "dummy";
        asid = "dummy";
        type = "ETKA";
        brand = "SUPERB";
        dealerid = "dealerid";

        etkaService.setEtkaURL(etkaDummyUrl);
        etkaService.setEtkaUserName("some_user_name");
        etkaService.setEtkaPassword("some_password");

        builder = UriComponentsBuilder.fromHttpUrl(etkaDummyUrl)
                .queryParam("country", country)
                .queryParam("lang", language)
                .queryParam("vin", vin)
                .queryParam("brand", brand)
                .queryParam("asid", asid)
                .queryParam("type", type);
    }

    @Test
    public void getPartsInformationFromETKA_itShouldReturnPartsInfo_whenAllDetailsAreProvided() throws IOException {

        String xml_output = "<partsInfoArray>\n" +
                "<Illustration>941-000</Illustration>\n" +
                "</partsInfoArray>";

        ASInfo expected = new ASInfo().withPartsInfoWithStatus(new PartsInfoWithStatus().withPartsInfoArray(new PartsInfo[]{new PartsInfo().withIllustration("941-000")}));

        ETKAService etkaServiceSpy = spy(etkaService);
        doReturn(xml_output).when(etkaServiceSpy).makeRequestToETKA(anyString(), anyString(), anyString(), anyString(), anyString(), anyString());

        PowerMockito.mockStatic(Utility.class);
        PowerMockito.when(Utility.parsePartInformationXML(anyString())).thenReturn(expected);

        ASInfo actual = etkaServiceSpy.getPartsInformationFromETKA(asid, vin, brand, country, language);

        assertEquals(expected, actual);
    }

    @Test
    public void makeRequestToETKA_itShouldMakeRequestTOETKAServerAndGetUsRequiredInfoInXML() {
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok(responseFromEtka));
        String xml = etkaService.makeRequestToETKA(asid, vin, language, country, brand, type);

        assertEquals(responseFromEtka, xml);
    }

    @Test
    public void getPartInformationByASInfo_itShouldReturnETKAPositionList() throws IOException {
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(responseFromEtka));
        List<PartsInfoDTO> partInformationByASInfo = etkaService.getPartInformation(asid, vin, language, country, brand);

        assertNotNull(partInformationByASInfo);
        assertEquals(1, partInformationByASInfo.size());
        assertEquals("130-000", partInformationByASInfo.get(0).getIllustration());
        assertEquals("04L906054", partInformationByASInfo.get(0).getPartNumber());
        assertEquals("Kühlerlüfter mit Lüfter-", partInformationByASInfo.get(0).getDenominationLine()[0]);
        assertEquals("M18X1,5", partInformationByASInfo.get(0).getRemarkLine());
        assertEquals(" 1", partInformationByASInfo.get(0).getQuantity());
        assertNull(partInformationByASInfo.get(0).getPrice());
    }

    @Test
    public void shouldReturnEmptyListWhenReceiveEmptyResponseFromEtka() throws IOException {
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.noContent().build());
        List<PartsInfoDTO> responsePartsInfoDTO = etkaService.getPartInformation(asid, vin, language, country, brand);

        assertNotNull(responsePartsInfoDTO);
        assertEquals(0, responsePartsInfoDTO.size());
    }

    @Test
    public void shouldReturnEmptyListWhenReceiveResponseFromEtkaButNoPartsInfo() throws IOException {
        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(emptyPartsInfo));
        List<PartsInfoDTO> responsePartsInfoDTO = etkaService.getPartInformation(asid, vin, language, country, brand);

        assertNotNull(responsePartsInfoDTO);
        assertEquals(0, responsePartsInfoDTO.size());
    }

    @Test
    public void getPartInformationByASInfo_itShouldReturnETKAPositionList_askedMultipleTimes() {
        String expectedRejectedResponse = "<partsInfoWithStatus status=\"rejected\"/>";

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(etkaDummyUrl)
                .queryParam("country", country)
                .queryParam("lang", language)
                .queryParam("vin", vin)
                .queryParam("brand", brand)
                .queryParam("asid", asid)
                .queryParam("type", type);

        when(restTemplate.exchange(eq(builder.build().toUri()), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok(expectedRejectedResponse), ResponseEntity.ok(responseFromEtka));
        String actualResponse = etkaService.makeRequestToETKA(asid, vin, language, country, brand, type);

        assertEquals(responseFromEtka, actualResponse);

    }
}
