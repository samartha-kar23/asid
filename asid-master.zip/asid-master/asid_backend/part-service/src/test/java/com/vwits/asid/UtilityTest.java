package com.vwits.asid;

import com.vwits.asid.etka.entity.ASInfo;
import com.vwits.asid.utils.Utility;
import org.junit.Test;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;


public class UtilityTest {

    @Test
    public void parsePartInformationXML_shouldParseAndReturnXMLAsASInfo() throws IOException, URISyntaxException {
        URL resource = getClass().getResource("/sample.xml");
        String xml = new String(Files.readAllBytes(Paths.get(resource.toURI())));
        ASInfo asInfo = Utility.parsePartInformationXML(xml);
        assertNotNull(asInfo);
    }

    @Test
    public void shouldReturnEmptyObjectWhenXmlIsEmpty() throws IOException {
        String xml = "";
        ASInfo asInfo = Utility.parsePartInformationXML(xml);
        assertNotNull(asInfo);
        assertNull(asInfo.getAsid());
        assertNull(asInfo.getBrand());
        assertNull(asInfo.getCountry());
        assertNull(asInfo.getLang());
        assertNull(asInfo.getVin());
    }
}