package com.vwits.asid.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockClassRule;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import com.vwits.asid.entity.DealerData;
import com.vwits.asid.entity.LaborTimeInformation;
import com.vwits.asid.entity.aposnf.LabourOperation;
import com.vwits.asid.entity.aposnf.LabourOperationWorkTime;
import com.vwits.asid.entity.aposnf.WorkTimeCalculation;
import com.vwits.asid.repository.DealerDataRepository;
import com.vwits.asid.utility.testutils.SpringTestWithMockIDKit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.junit.After;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static com.vwits.asid.service.LaborTimeInformationService.APOSNF_CALCULATE_WORK_TIME_URL;
import static com.vwits.asid.service.LaborTimeInformationService.APOSNF_LABOR_OPERATION_URL;
import static com.vwits.asid.service.LaborTimeInformationService.UNAUTHORIZED_DEALER_ID_MESSAGE;
import static com.vwits.asid.utility.constants.ASIDAppConstants.APOS_API_PATH;
import static com.vwits.asid.utility.constants.ASIDAppConstants.REVERSE_MAPPING_SERVICE_APOSID_PATH;
import static com.vwits.asid.utility.testutils.IntegTestHelper.getMockTokenForIdKit;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringTestWithMockIDKit
@AutoConfigureMockMvc
public class LaborTimeInformationControllerTest {
    MultiValueMap<String, String> requestParams;

    @ClassRule
    public static WireMockClassRule mappingServiceMockRule = new WireMockClassRule(8447);
    @Rule
    public WireMockClassRule mappingServiceMock = mappingServiceMockRule;


    @ClassRule
    public static WireMockClassRule aposNFServiceMockRule = new WireMockClassRule(8448);
    @Rule
    public WireMockClassRule aposNFServiceMock = aposNFServiceMockRule;


    @ClassRule
    public static WireMockClassRule dealerBlacklistMockRule = new WireMockClassRule(8449);
    @Rule
    public WireMockClassRule dealerBlackListFilterMock = dealerBlacklistMockRule;

    @Autowired
    MockMvc mvc;

    ArrayList<LaborTimeInformation> expectedLaborTimeInfoList;

    private ObjectMapper mapper = new ObjectMapper();
    TestingData testingData;


    @Autowired
    DealerDataRepository dealerDataRepository;

    private String token;
    private String noContentModelYear = "2011";
    private String exceptional5XXModelYear="2012";
    private ObjectMapper objectMapper = new ObjectMapper();
    private Long exceptionalLopId1=101L;
    private String wrongToken="incorrect token";
    private String blacklistedDealerId = "IncorrectDealerId";


    @Before
    public void init() throws JsonProcessingException {
        token = getMockTokenForIdKit();

        createMockedTestingData();
        createRequestParams();



        expectedLaborTimeInfoList = new ArrayList<>();

        List<LabourOperation> labourOperations = Arrays.asList(
                new LabourOperation(testingData.getActivityId1(), "1701", null, testingData.getBaseNumber(), testingData.getDescription1(), null, testingData.getLopId1(), null, null),
                new LabourOperation(testingData.getActivityId2(), "1701", null, testingData.getBaseNumber(), testingData.getDescription2(), null, testingData.getLopId2(), null, null)
        );
        String laborOpJSON = objectMapper.writeValueAsString(labourOperations);

        List<LabourOperationWorkTime> labourOperationWorkTimeList = Arrays.asList(
                new LabourOperationWorkTime(testingData.getLopId1(), 24, 24),
                new LabourOperationWorkTime(testingData.getLopId2(), 55, 31));

        WorkTimeCalculation workTimeCalculationList = new WorkTimeCalculation(79, 55, labourOperationWorkTimeList);
        String laborWorkTimeJSON =objectMapper.writeValueAsString(workTimeCalculationList);

        expectedLaborTimeInfoList.add(new LaborTimeInformation(testingData.getBaseNumber(), testingData.getDescription1(), 24, testingData.getActivityId1()));
        expectedLaborTimeInfoList.add(new LaborTimeInformation(testingData.getBaseNumber(), testingData.getDescription2(), 55, testingData.getActivityId2()));

        generateStubForMappingRequest();
        generateStubForDealerAuthorization();

        generateStubForAPOSRequest(HttpStatus.OK,laborOpJSON);
        generateStubForAPOSRequest(HttpStatus.NOT_FOUND,null);

        generateStubForAPOSWorkTimeRequest(HttpStatus.OK,laborWorkTimeJSON);
        generateStubForAPOSRequest(HttpStatus.NO_CONTENT,null);
        generateStubForAPOSRequest(HttpStatus.INTERNAL_SERVER_ERROR,null);

        dealerDataRepository.save(new DealerData("AuthorisedDealerId", "Description"));

    }

    @Test
    public void getLaborTime_ShouldFail_whenWrongTokenIsPassed() throws Exception {

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .header(AUTHORIZATION, "bearer " + wrongToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError());
    }

    @Test
    public void itShouldReturnLaborTime_whenASInfoIsValid() throws Exception {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(mapper.writeValueAsString(expectedLaborTimeInfoList)));
    }

    @Test
    public void itShouldReturnForbidden403_whenDealerIdIsBlacklisted() throws Exception {
        requestParams.set("dealerid", blacklistedDealerId);
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden());
    }

    @Test
    public void itShouldReturnUnAuthorised_whenDealerIdIsUnAuthorized() throws Exception {
        requestParams.add("dealerid", "randomDealerId");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate).header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.UNAUTHORIZED.value()))
                .andExpect(content().string(UNAUTHORIZED_DEALER_ID_MESSAGE));
    }

    @Test
    public void itShouldAcceptMultiplePRNumbers() throws Exception {

        requestParams.set("prnumber","K097A1MLBLKJ,K097A1MLBLKJsadf,K097A1MLBLKJdsgds");
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(mapper.writeValueAsString(expectedLaborTimeInfoList)));
    }

    @Test
    public void itShouldReturn204_whenASInfoIsValid_butNoDataForThatASInfo() throws Exception {
        requestParams.set("asid", testingData.getFakeAsid());

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    public void itShouldReturn204_whenASInfoIsInvalid() throws Exception {

        requestParams.set("modelyear", noContentModelYear);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate).header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

    }

    @Test
    public void itShouldReturn502_whenAPOSThrows5XXException() throws Exception {

        requestParams.set("modelyear", exceptional5XXModelYear);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate).header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.BAD_GATEWAY.value()));

    }

    @Test
    public void itShouldReturn502_whenAPOSThrows4XXException() throws Exception {


        List<LabourOperation> labourOperations = Arrays.asList(
                new LabourOperation(testingData.getActivityId1(), "1701", null, testingData.getBaseNumber(), testingData.getDescription1(), null, exceptionalLopId1, null, null)
        );
        String laborOpJSON = objectMapper.writeValueAsString(labourOperations);
        generateStubForAPOSRequest(HttpStatus.OK,laborOpJSON);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate).header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.BAD_GATEWAY.value()));

    }

    @Test
    public void itShouldPassReceivedToken_To_APOSNF() throws Exception {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(requestParams).build();
        String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .header(AUTHORIZATION, "bearer "+token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    public void itShouldReturn400BadRequest_whenEmptyValuePassedForParameters() throws Exception {
        // when appname is blank
        requestParams.set("appname", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when lang is blank
        requestParams.set("appname", testingData.getAppname());
        requestParams.set("lang", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when country is blank
        requestParams.set("lang", testingData.getLang());
        requestParams.set("country", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when country is blank
        requestParams.set("country", testingData.getCountry());
        requestParams.set("asid", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when mkb is blank
        requestParams.set("asid", testingData.getAsid());
        requestParams.set("mkb", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when gkb is blank
        requestParams.set("mkb", testingData.getMkb());
        requestParams.set("gkb", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when brand is blank
        requestParams.set("gkb", testingData.getGkb());
        requestParams.set("brand", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when vt is blank
        requestParams.set("brand", testingData.getBrand());
        requestParams.set("vt", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    private String getRequestParams(MultiValueMap<String, String> params) {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(params).build();
        return uriComponents.toUriString();
    }

    @After
    public void tearDown() {
        requestParams.clear();
    }


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    static class TestingData {
        private Long lopId1;
        private Long lopId2;
        private String asid;
        private String fakeAsid;
        private String lang;
        private String country;
        private String mkb;
        private String gkb;
        private String modelyear;
        private String prnumber;
        private String brand;
        private String vt;
        private String extid;
        private String appname;
        private String baseNumber;
        private String description1;
        private String description2;
        private String activityId1;
        private String activityId2;
        private String dealerId;
    }

    private void generateStubForAPOSWorkTimeRequest(HttpStatus status, String laborWorkTimeJSON) {

        String lopId="";
        if(status.value()==HttpStatus.NOT_FOUND.value()){
            lopId=exceptionalLopId1.toString();
        }
        else{
            lopId=String.valueOf(testingData.getLopId1());
        }
        aposNFServiceMock.stubFor(WireMock.get(urlPathEqualTo(APOSNF_CALCULATE_WORK_TIME_URL))
                .withHeader(AUTHORIZATION, new EqualToPattern("bearer " + token))
                .withQueryParam("manufacturer", equalTo(testingData.getBrand()))
                .withQueryParam("lopIds", containing(lopId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(HttpStatus.OK.value())
                        .withBody(laborWorkTimeJSON)
                ));
    }

    private void generateStubForDealerAuthorization() {
        final String authorizedDealerId = testingData.getDealerId();
        dealerBlackListFilterMock.stubFor(WireMock.get(anyUrl())
                .withQueryParam("dealerid", equalTo(authorizedDealerId))
                .withQueryParam("infomediatype", equalTo("aposinfo")).willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(HttpStatus.OK.value())
                        .withBody(FALSE.toString())));

        dealerBlackListFilterMock.stubFor(WireMock.get(anyUrl())
                .withQueryParam("dealerid", equalTo(blacklistedDealerId))
                .withQueryParam("infomediatype", equalTo("aposinfo")).willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(HttpStatus.OK.value())
                        .withBody(TRUE.toString())));
    }

    private void generateStubForMappingRequest() throws JsonProcessingException {
        mappingServiceMock.stubFor(WireMock.get(urlPathEqualTo(REVERSE_MAPPING_SERVICE_APOSID_PATH))
                .withQueryParam("asid", equalTo(testingData.getAsid()))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(HttpStatus.OK.value())
                        .withBody(objectMapper.writeValueAsString(Collections.singletonList(testingData.getBaseNumber())))
                )
        );

        mappingServiceMock.stubFor(WireMock.get(urlPathEqualTo(REVERSE_MAPPING_SERVICE_APOSID_PATH))
                .withQueryParam("asid", equalTo(testingData.getFakeAsid()))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(HttpStatus.NO_CONTENT.value())
                )

        );

        mappingServiceMock.stubFor(WireMock.get(urlPathEqualTo(REVERSE_MAPPING_SERVICE_APOSID_PATH))
                .withQueryParam("asid", equalTo(""))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(HttpStatus.BAD_REQUEST.value())
                )

        );

    }

    private void generateStubForAPOSRequest(HttpStatus state, String body) throws JsonProcessingException {
        String modelYear = "";
        switch (state){
            case OK: modelYear="2018";break;
            case NO_CONTENT:modelYear=noContentModelYear; break;
            case INTERNAL_SERVER_ERROR: modelYear=exceptional5XXModelYear; break;
        }
        aposNFServiceMock.stubFor(WireMock.get(urlPathEqualTo(APOSNF_LABOR_OPERATION_URL))
                .withHeader(AUTHORIZATION, new EqualToPattern("bearer " + token))
                .withQueryParam("basenumbers", equalTo(testingData.getBaseNumber()))
                .withQueryParam("engines", equalTo(testingData.getMkb()))
                .withQueryParam("language", equalTo(testingData.getLang() + "-" + testingData.getCountry()))
                .withQueryParam("manufacturer", equalTo(testingData.getBrand()))
                .withQueryParam("modelCode", equalTo(testingData.getVt()))
                .withQueryParam("modelYear", equalTo(modelYear))
                .withQueryParam("transmissions", equalTo(testingData.getGkb()))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE + "; charset=UTF-8")
                        .withStatus(state.value())
                        .withBody(body)
                ));
    }

    private void createRequestParams() {
        requestParams = new LinkedMultiValueMap<>();
        requestParams.add("asid", testingData.getAsid());
        requestParams.add("lang", testingData.getLang());
        requestParams.add("country", testingData.getCountry());
        requestParams.add("mkb", testingData.getMkb());
        requestParams.add("gkb", testingData.getGkb());
        requestParams.add("modelyear", testingData.getModelyear());
        requestParams.add("prnumber", testingData.getPrnumber());
        requestParams.add("brand", testingData.getBrand());
        requestParams.add("vt", testingData.getVt());
        requestParams.add("appname", testingData.getAppname());
        requestParams.add("dealerid", testingData.getDealerId());
    }

    private void createMockedTestingData() {
        testingData = new TestingData().builder()
                .asid("107X1701")
                .lang("de")
                .country("DE")
                .mkb("CZPB")
                .gkb("SBK")
                .modelyear("2018")
                .prnumber("K097A1MLBLKJ")
                .brand("V")
                .vt("3H73HZ")
                .extid("1234ABC")
                .appname("etka")
                .lopId1(11626906L)
                .activityId1("35")
                .description1("Motoröl prüfen und ergänzen")
                .lopId2(11625613L)
                .activityId2("17S")
                .description2("Motoröl ablassen und auffüllen")
                .baseNumber("107010")
                .fakeAsid("dummy")
                .dealerId("AuthorisedDealerId").build();
        ;
    }


}


