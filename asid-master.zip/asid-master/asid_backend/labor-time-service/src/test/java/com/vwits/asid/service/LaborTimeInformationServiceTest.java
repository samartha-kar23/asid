package com.vwits.asid.service;


import com.vwits.asid.entity.DealerData;
import com.vwits.asid.entity.LaborTimeInformation;
import com.vwits.asid.exception.InvalidDealerIDException;
import com.vwits.asid.utility.mapping.ReverseMappingServiceProvider;
import com.vwits.asid.repository.DealerDataRepository;
import com.vwits.asid.utility.entity.BZD;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.vwits.asid.service.LaborTimeInformationService.APOSNF_CALCULATE_WORK_TIME_URL;
import static com.vwits.asid.service.LaborTimeInformationService.APOSNF_LABOR_OPERATION_URL;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpStatus.NO_CONTENT;


@RunWith(MockitoJUnitRunner.class)
public class LaborTimeInformationServiceTest {

    private BZD bzd = new BZD();
    private String asid = "100X1001";
    private String lang = "en";
    private String country = "GB";
    private String mkb = "K12";
    private String gkb = "75K";
    private int modelyear = 2010;
    private String prnumber = "K097A1MLBLKJ";
    private String brand = "V";
    private String vt = "3H7123";
    private String appname = "etka";
    private int lopID = 11626906;
    private String dealerId = "dealerId";

    private ArrayList<LaborTimeInformation> expectedLaborTimeInfoList = new ArrayList<>();
    private List<String> baseNumberList = new ArrayList<>();

    @Mock
    private ReverseMappingServiceProvider mappingServiceProvider;

    @InjectMocks
    private LaborTimeInformationService laborTimeInformationService;

    @Mock
    private HttpServletRequest mockRequest;

    @Mock
    private RestTemplate restTemplate;
    private JSONArray expectedLaborOperationResponse;
    private JSONObject expectedWorkTimeResponse;

    @Mock
    private DealerDataRepository dealerDataRepository;


    @Before
    public void setUp() {

        bzd.setBrand(brand);
        bzd.setCountry(country);
        bzd.setLang(lang);
        bzd.setMkb(mkb);
        bzd.setGkb(gkb);
        bzd.setModelyear(modelyear);
        bzd.setPrnumber(Collections.singletonList(prnumber));
        bzd.setVt(vt);

        baseNumberList.add("402111");
        baseNumberList.add("702090");

        laborTimeInformationService.aposnfEndPoint = "http://www.dummyurl.com";


        expectedLaborOperationResponse = new JSONArray()
                .put(0, new JSONObject()
                        .put("lopId", lopID)
                        .put("basenumberIdentifier", 107010)
                        .put("activityIdentifier", "S35")
                        .put("description", "Motoröl prüfen und ergänzen")
                        .put("afterSalesNumber", 1701)
                );

        expectedWorkTimeResponse = new JSONObject()
                .put("totalWorkTime", 79)
                .put("totalEffectiveWorkTime", 55)
                .put("labourOperations", new JSONArray()
                        .put(0, new JSONObject()
                                .put("lopId", lopID)
                                .put("workTime", 24)
                                .put("effectiveWorkTime", 24)
                        )
                );

        expectedLaborTimeInfoList.add(new LaborTimeInformation("107010", "Motoröl prüfen und ergänzen", 24, "S35"));
        String token = "some token";
        when(mockRequest.getHeader("Authorization")).thenReturn(token);

        DealerData dealerDataAuthorised = new DealerData(dealerId, "dealer description");
        when(dealerDataRepository.findByDealerId(dealerId)).thenReturn(dealerDataAuthorised);

    }

    @Test
    public void shouldReturnEmptyList_whenASInfoProvided_butNoBaseNumberPresent() throws Exception {
        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(new ArrayList<>());

        List<LaborTimeInformation> actualLaborTimeInfoList = laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, "token");

        verify(mappingServiceProvider, times(1)).getLaborTimeIds(anyString());

        assertEquals(new ArrayList<>(), actualLaborTimeInfoList);
    }

    @Test
    public void shouldReturnLaborTime_whenASInfoIsProvided() throws IOException {

        //given
        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(baseNumberList);
        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok(expectedLaborOperationResponse.toString()))
                .thenReturn(ResponseEntity.ok(expectedWorkTimeResponse.toString()));

        //when
        List<LaborTimeInformation> actualResponse = laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, "token");
        verify(restTemplate, times(2)).exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class));
        verify(mappingServiceProvider).getLaborTimeIds(anyString());
        assertEquals(expectedLaborTimeInfoList, actualResponse);
    }

    @Test(expected = InvalidDealerIDException.class)
    public void shouldThrowInvalidDealerIdExceptionWhenDealerIdIsNotValid() throws IOException {
        String unauthorisedDealerId = "UnauthorisedDealerId";
        when(dealerDataRepository.findByDealerId(unauthorisedDealerId)).thenReturn(null);
        laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, unauthorisedDealerId, "token");
    }

    @Test
    public void shouldSendMultiplePrNumberToAPOSNFService() throws IOException {
        ArgumentCaptor<URI> uriCaptor = ArgumentCaptor.forClass(URI.class);
        String anotherPrnumber = "another_prnumber";
        List<String> prNumberList = Arrays.asList(prnumber, anotherPrnumber);
        bzd.setPrnumber(prNumberList);
        //given
        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(baseNumberList);
        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok(expectedLaborOperationResponse.toString()))
                .thenReturn(ResponseEntity.ok(expectedWorkTimeResponse.toString()));

        //when
        List<LaborTimeInformation> actualResponse = laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, "token");
        verify(restTemplate, times(2)).exchange(uriCaptor.capture(), eq(HttpMethod.GET), any(), eq(String.class));
        assertTrue(uriCaptor.getAllValues().get(0).getRawQuery().contains(prnumber));
        assertTrue(uriCaptor.getAllValues().get(0).getRawQuery().contains(anotherPrnumber));
    }


    @Test
    public void shouldReturnEmptyList_whenNoLaborTimeContentIsReceivedFromAPOS() throws IOException {
        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(baseNumberList);
        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(new ResponseEntity(NO_CONTENT));

        List<LaborTimeInformation> actualResponse = laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, "token");

        verify(mappingServiceProvider).getLaborTimeIds(anyString());
        verify(restTemplate).exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class));
        assertEquals(new ArrayList<>(), actualResponse);

    }

    @Test
    public void shouldReturnEmptyList_whenNoWorkTimeFound() throws IOException {
        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(baseNumberList);
        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok(expectedLaborOperationResponse.toString()))
                .thenReturn(new ResponseEntity(NO_CONTENT));

        List<LaborTimeInformation> actualResponse = laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, "token");

        verify(mappingServiceProvider).getLaborTimeIds(anyString());
        verify(restTemplate, times(2)).exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class));
        assertEquals(new ArrayList<>(), actualResponse);

    }


    @Test(expected = RestClientResponseException.class)
    public void shouldThrowRestClientResponseExcetion() throws IOException {

        String description = "Motoröl prüfen und ergänzen";
        String side = "some-side";
        int amount = 99;
        String position = "postion";
        String location = "location";

        expectedLaborOperationResponse.getJSONObject(0).put("side", side);
        expectedLaborOperationResponse.getJSONObject(0).put("amount", amount);
        expectedLaborOperationResponse.getJSONObject(0).put("position", position);
        expectedLaborOperationResponse.getJSONObject(0).put("location", location);


        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(baseNumberList);


        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenThrow(RestClientResponseException.class);
        laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, "token");

    }

    @Test
    public void shouldPassReceivedToken_To_AposNF_For_fetchLabourOperations() throws IOException {
        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(baseNumberList);
        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(ResponseEntity.status(NO_CONTENT).build());

        String token = "I'm a valid token";
        laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, token);

        ArgumentCaptor<HttpEntity> httpEntityArgumentCaptor = ArgumentCaptor.forClass(HttpEntity.class);
        ArgumentCaptor<URI> uriArgumentCaptor = ArgumentCaptor.forClass(URI.class);
        verify(restTemplate).exchange(uriArgumentCaptor.capture(), eq(HttpMethod.GET), httpEntityArgumentCaptor.capture(), eq(String.class));

        Assert.assertTrue(uriArgumentCaptor.getValue().getPath().contains(APOSNF_LABOR_OPERATION_URL));
        Assert.assertEquals(token, httpEntityArgumentCaptor.getValue().getHeaders().getFirst(AUTHORIZATION));
    }

    @Test
    public void shouldPassReceivedToken_To_AposNF_For_fetchWorkTime() throws IOException {
        when(mappingServiceProvider.getLaborTimeIds(eq(asid))).thenReturn(baseNumberList);
        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok(expectedLaborOperationResponse.toString()))
                .thenReturn(ResponseEntity.status(NO_CONTENT).build());

        String token = "I'm a valid token";
        laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, token);

        ArgumentCaptor<HttpEntity> httpEntityArgumentCaptor = ArgumentCaptor.forClass(HttpEntity.class);
        ArgumentCaptor<URI> uriArgumentCaptor = ArgumentCaptor.forClass(URI.class);
        verify(restTemplate, times(2)).exchange(uriArgumentCaptor.capture(), eq(HttpMethod.GET), httpEntityArgumentCaptor.capture(), eq(String.class));
        Assert.assertTrue(uriArgumentCaptor.getAllValues().get(1).getPath().contains(APOSNF_CALCULATE_WORK_TIME_URL));
        Assert.assertEquals(token, httpEntityArgumentCaptor.getAllValues().get(1).getHeaders().getFirst(AUTHORIZATION));
    }
}
