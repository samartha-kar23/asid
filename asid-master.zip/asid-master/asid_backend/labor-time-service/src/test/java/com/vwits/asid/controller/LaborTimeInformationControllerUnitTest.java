package com.vwits.asid.controller;

import com.vwits.asid.entity.LaborTimeInformation;
import com.vwits.asid.service.LaborTimeInformationService;
import com.vwits.asid.utility.entity.BZD;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.client.RestClientResponseException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@RunWith(MockitoJUnitRunner.class)
public class LaborTimeInformationControllerUnitTest {

    private String asid = "1234";
    private String lang = "en";
    private String country = "de";
    private String mkb = "K12";
    private String gkb = "75K";
    private int modelyear = 2010;
    private String prnumber = "K097A1MLBLKJ";
    private String brand = "SUPERB";
    private String vt = "abc123";
    private String appname = "etka";
    private String dealerId = "dealerId";

    private BZD bzd = new BZD();


    ArrayList<LaborTimeInformation> expectedLaborTimeInfoList;

    @Mock
    LaborTimeInformationService laborTimeInformationService;

    @InjectMocks
    LaborTimeInformationController laborTimeInformationController;

    private MockHttpServletRequest mockHttpServletRequest;
    private String token = "dummy_token";


    @Before
    public void setUp() {
        expectedLaborTimeInfoList = new ArrayList<>();
        mockHttpServletRequest = new MockHttpServletRequest();
        mockHttpServletRequest.addHeader(AUTHORIZATION, token);
        bzd.setBrand(brand);
        bzd.setCountry(country);
        bzd.setLang(lang);
        bzd.setMkb(mkb);
        bzd.setGkb(gkb);
        bzd.setModelyear(modelyear);
        bzd.setPrnumber(Collections.singletonList(prnumber));
        bzd.setVt(vt);

    }

    @Test
    public void getLaborTimeFromASInfo_itShouldReturnLaborTime_whenASInfoIsValid() throws Exception {

        LaborTimeInformation laborTimeInformation0 = new LaborTimeInformation(1l, "001060",
                "Inspektion mit Ölwechsel durchführen", 100, "102");
        LaborTimeInformation laborTimeInformation1 = new LaborTimeInformation(2l, "001030",
                "GFS/Geführte Funktion  vorbereiten", 120, "109");
        expectedLaborTimeInfoList.add(laborTimeInformation0);
        expectedLaborTimeInfoList.add(laborTimeInformation1);

        Mockito.when(laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, token)).thenReturn(expectedLaborTimeInfoList);

        ResponseEntity<Object> laborTimeInfo = laborTimeInformationController.getLaborTimeInfo(asid, bzd, appname, dealerId, mockHttpServletRequest);

        Assert.assertEquals(HttpStatus.OK, laborTimeInfo.getStatusCode());
        Assert.assertEquals(expectedLaborTimeInfoList, laborTimeInfo.getBody());
    }

    @Test
    public void getLaborTimeFromASInfo_itShouldNotReturnLaborTime_whenASInfoIsValid() throws Exception {
        Mockito.when(laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, token)).thenReturn(expectedLaborTimeInfoList);

        ResponseEntity<Object> laborTimeInfo = laborTimeInformationController.getLaborTimeInfo(asid, bzd, appname, dealerId, mockHttpServletRequest);

        Assert.assertEquals(HttpStatus.NO_CONTENT, laborTimeInfo.getStatusCode());
    }

    @Test
    public void getLaborTimeFromASInfo_shouldReturnBadGatewayWhenEncounterAnyErrorFromAPOS() throws IOException {

        RestClientResponseException exception = new RestClientResponseException("RunTimeException", 500, "Internal Server Error", null, null, null);

        Mockito.when(laborTimeInformationService.getLaborTimeInformationUsingASInfo(asid, bzd, dealerId, token)).thenThrow(exception);

        ResponseEntity<Object> laborTimeInfo = laborTimeInformationController.getLaborTimeInfo(asid, bzd, appname, dealerId, mockHttpServletRequest);
        Assert.assertEquals(HttpStatus.BAD_GATEWAY, laborTimeInfo.getStatusCode());


    }
}
