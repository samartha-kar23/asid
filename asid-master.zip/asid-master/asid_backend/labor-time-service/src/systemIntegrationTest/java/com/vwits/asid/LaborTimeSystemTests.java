package com.vwits.asid;

import com.vwits.asid.entity.LaborTimeInformation;
import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import com.vwits.asid.utility.testutils.entity.IdKitClientCredential;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

import static com.vwits.asid.utility.GeneralUtility.getHttpEntityWithHeaderToken;
import static com.vwits.asid.utility.constants.ASIDAppConstants.APOS_API_PATH;
import static com.vwits.asid.utility.testutils.TokenUtil.getToken;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.INVALID_ASID;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_ASID;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class LaborTimeSystemTests {
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("labor-time-service", false);
    private IdKitClientCredential idKitCredential = new IdKitClientCredential();
    private RestTemplate template;
    private MultiValueMap<String, String> testData;

    @Before
    public void setUp() {
        testData = new LinkedMultiValueMap<>();
        testData.add("lang", "de");
        testData.add("country", "DE");
        testData.add("mkb", "CZPB");
        testData.add("gkb", "SBK");
        testData.add("modelyear", "2018");
        testData.add("prnumber", "");
        testData.add("brand", "V");
        testData.add("vt", "3H73HZ");
        testData.add("appname", "dev");
        testData.add("dealerid", "ASIDTESTS");
        template = new RestTemplate();

    }


    @Test
    public void getLaborTimeInfo_shouldReturn204_whenAuthTokenIsValidAndASIDIsInvalid() {
        String authToken = getToken(template, idKitCredential);
        testData.add("asid", INVALID_ASID);

        ResponseEntity<List<LaborTimeInformation>> response = getLaborTimeInfo(authToken, testData);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Test
    public void getLaborTimeInfo_shouldReturn200WithInfo_whenAuthTokenIsValidAndASIDIsValid() {
        String authToken = getToken(template, idKitCredential);
        testData.add("asid", VALID_ASID);

        ResponseEntity<List<LaborTimeInformation>> response = getLaborTimeInfo(authToken, testData);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    public void getLaborTimeInfo_shouldReturn401_whenAuthTokenIsInValid() {
        String invalidToken = "dummy token";
        testData.add("asid", VALID_ASID);

        thrown.expect(HttpClientErrorException.class);
        thrown.expectMessage(containsString("401 Unauthorized"));
        thrown.expect(hasProperty("statusCode", is(HttpStatus.UNAUTHORIZED)));
        thrown.expect(hasProperty("statusText", containsString("Unauthorized")));

        getLaborTimeInfo(invalidToken, testData);
    }

    @Test
    public void getLaborTimeInfo_itShouldReturn403_whenDealerIdIsBlacklisted() {
        String authToken = getToken(template, idKitCredential);
        testData.add("asid", VALID_ASID);
        testData.set("dealerid", "LTBL001");

        thrown.expect(HttpClientErrorException.class);
        thrown.expectMessage(containsString("403 Forbidden"));
        thrown.expect(hasProperty("statusCode", is(HttpStatus.FORBIDDEN)));
        thrown.expect(hasProperty("statusText", containsString("Forbidden")));

        getLaborTimeInfo(authToken, testData);
    }

    @Test
    public void getLaborTimeInfo_itShouldReturn401_whenDealerIdIsUnAuthorized() {
        String authToken = getToken(template, idKitCredential);
        testData.add("asid", VALID_ASID);
        testData.remove("dealerid");
        testData.add("dealerid", "unAuthorizedDealerId");

        thrown.expect(HttpClientErrorException.class);
        thrown.expectMessage(containsString("401 Unauthorized"));
        thrown.expect(hasProperty("statusCode", is(HttpStatus.UNAUTHORIZED)));
        thrown.expect(hasProperty("statusText", containsString("Unauthorized")));

        getLaborTimeInfo(authToken, testData);
    }

    @Test
    public void testSwaggerUrl() {
        if (serviceURL.contains("acceptance")) {
            String url = serviceURL + "/v2/api-docs?group=Labor Time Specification";
            ResponseEntity<String> forEntity = template.getForEntity(url, String.class);
            assertEquals(HttpStatus.OK.value(), forEntity.getStatusCode().value());
        } else {
            assertTrue("Test case is not applicable for this environment, hence skipping it", true);
        }
    }

    private ResponseEntity<List<LaborTimeInformation>> getLaborTimeInfo(String authToken, MultiValueMap<String, String> testData) {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(APOS_API_PATH).queryParams(testData).build();
        HttpEntity<String> request = getHttpEntityWithHeaderToken(authToken);
        return template.exchange(serviceURL + uriComponents.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<LaborTimeInformation>>() {
        });

    }

}

