package com.vwits.asid;

import com.vwits.asid.utility.testutils.TokenUtil;
import org.apache.tomcat.util.codec.binary.Base64;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.nio.charset.Charset;
import java.util.ArrayList;

import static com.vwits.asid.service.LaborTimeInformationService.APOSNF_LABOR_OPERATION_URL;
import static org.junit.Assert.assertNotEquals;

public class AposNFServiceTest {

    private RestTemplate restTemplate = new RestTemplate();

    private String aposnfEndPoint;


    @Before
    public void setUp() throws Exception {
         aposnfEndPoint = System.getenv("aposnf.service-url");
    }

    @Test
    public void shouldBeAbleToSend8000CharacterLongRequestToAPOSNF() {
        ArrayList<CharSequence> elements = new ArrayList<>();
        String baseNum = "107010";
        elements.add(baseNum);
        for (int index = 0; index < 1055; index++) {
            elements.add(baseNum);
        }
        String commaSeparatedReferenceNumbers = String.join(",", elements);
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();

        queryParams.add("basenumbers", commaSeparatedReferenceNumbers);
        queryParams.add("engines", "CZPB");
        queryParams.add("language", "de-DE");
        queryParams.add("manufacturer", "V");
        queryParams.add("modelCode", "3H73HZ");
        queryParams.add("modelYear", "2018");
        queryParams.add("transmissions", "SBK12");

        ResponseEntity<String> responseEntity = makeRestCallToAposnf(aposnfEndPoint.concat(APOSNF_LABOR_OPERATION_URL), queryParams);

        assertNotEquals(HttpStatus.URI_TOO_LONG, responseEntity.getStatusCode());
    }

    private HttpHeaders createHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + TokenUtil.getToken());
        return headers;
    }

    private String encodeAuthHeaders(String username, String password) {
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(
                auth.getBytes(Charset.forName("US-ASCII")));
        return "Basic " + new String(encodedAuth);
    }

    private ResponseEntity<String> makeRestCallToAposnf(String url, MultiValueMap<String, String> queryParams) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParams(queryParams);
        URI uri = builder.build().toUri();
        HttpEntity<String> entity = new HttpEntity<>(createHeaders());
        try {
            return restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
        } catch (HttpClientErrorException e) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

    }
}
