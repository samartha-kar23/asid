package com.vwits.asid.exception;

public class InvalidDealerIDException extends RuntimeException {

    public InvalidDealerIDException(String message){
        super(message);
    }
}
