package com.vwits.asid.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LaborTimeInformation {

    @JsonIgnore
    private Long id;

    private String basenumberIdentifier;

    private String description;

    private Integer workTime;

    private String activityIdentifier;

    public LaborTimeInformation(String baseNumberIdentifier, String description, Integer workTime, String activityIdentifier) {
        this.basenumberIdentifier = baseNumberIdentifier;
        this.description = description;
        this.workTime = workTime;
        this.activityIdentifier = activityIdentifier;
    }
}
