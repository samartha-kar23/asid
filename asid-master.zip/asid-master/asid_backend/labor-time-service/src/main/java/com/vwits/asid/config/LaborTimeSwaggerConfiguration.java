package com.vwits.asid.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import springfox.documentation.builders.*;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.SecurityConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Arrays;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.Collections.singletonList;
import static springfox.documentation.builders.PathSelectors.any;

@Configuration
@EnableSwagger2
@Profile("Swagger")
public class LaborTimeSwaggerConfiguration extends WebMvcConfigurationSupport {

    @Bean
    public Docket api() {
        String swaggerToken = "token";
        return new Docket(DocumentationType.SWAGGER_2)
                .globalOperationParameters(singletonList(
                        new ParameterBuilder()
                                .name("Authorization")
                                .modelRef(new ModelRef("String"))
                                .parameterType("header")
                                .required(true)
                                .hidden(true)
                                .defaultValue("Bearer " + swaggerToken).build()))
                .groupName("Labor Time Specification")
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.vwits.asid.controller"))
                .paths(any())
                .paths(PathSelectors.regex("(?!/error).+"))
                .build()
                .useDefaultResponseMessages(false)
                .globalResponseMessage(RequestMethod.GET, newArrayList(new ResponseMessageBuilder()
                                .code(204)
                                .message("No Content")
                                .build(), new ResponseMessageBuilder()
                                .code(401)
                                .message("UnAuthorised Access").build(),
                        new ResponseMessageBuilder()
                                .code(400)
                                .message("Bad Request").build(),
                        new ResponseMessageBuilder()
                                .code(502)
                                .message("Bad Gateway").build()))
                .apiInfo(apiInfo())
                .securitySchemes(Arrays.asList(securityScheme()));
    }


    @Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("Labor Time Information Service").
                description("This Service helps in getting Labor Time Data after providing required parameters").version("1.0.1").build();
    }

    @Bean
    public SecurityConfiguration security() {
        return SecurityConfigurationBuilder.builder()
                .clientId("")
                .clientSecret("")
                .scopeSeparator(" ")
                .useBasicAuthenticationWithAccessCodeGrant(true)
                .build();
    }

    private OAuth securityScheme() {
        List<GrantType> grantTypes = newArrayList();
        GrantType passwordCredentialsGrant = new ResourceOwnerPasswordCredentialsGrant("https://identity-sandbox.vwgroup.io/oidc/v1/token");
        grantTypes.add(passwordCredentialsGrant);
        return new OAuth("oauth2", Arrays.asList(scopes()), grantTypes);
    }

    private AuthorizationScope[] scopes() {
        return new AuthorizationScope[]{
                new AuthorizationScope("read", "for read operations")};
    }


}
