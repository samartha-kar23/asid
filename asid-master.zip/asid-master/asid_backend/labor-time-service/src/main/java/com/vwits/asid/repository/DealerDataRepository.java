package com.vwits.asid.repository;


import com.vwits.asid.entity.DealerData;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DealerDataRepository extends CrudRepository<DealerData, String> {

    DealerData findByDealerId(String dealerId);


}
