package com.vwits.asid.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dealer_data")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class DealerData {

    @Id
    @Column(name = "dealer_id")
    private String dealerId;
    @Column(name = "description")
    private String description;
}
