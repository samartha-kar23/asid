package com.vwits.asid.entity.aposnf;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WorkTimeCalculation {

    @JsonProperty(required = true)
    private Integer totalWorkTime;
    @JsonProperty(required = true)
    private Integer totalEffectiveWorkTime;
    @JsonProperty(value = "labourOperations" ,required = true)
    private List<LabourOperationWorkTime> labourOperations;
}
