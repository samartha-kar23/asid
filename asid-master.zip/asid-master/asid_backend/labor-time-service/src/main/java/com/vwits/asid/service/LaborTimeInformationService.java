package com.vwits.asid.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.entity.DealerData;
import com.vwits.asid.entity.LaborTimeInformation;
import com.vwits.asid.entity.aposnf.LabourOperation;
import com.vwits.asid.entity.aposnf.LabourOperationWorkTime;
import com.vwits.asid.entity.aposnf.WorkTimeCalculation;
import com.vwits.asid.exception.InvalidDealerIDException;
import com.vwits.asid.repository.DealerDataRepository;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.entity.BZD;
import com.vwits.asid.utility.mapping.ReverseMappingServiceProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.lang.String.join;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Slf4j
@Service
public class LaborTimeInformationService {

    public static final String APOSNF_LABOR_OPERATION_URL = "/labourOperations";
    public static final String APOSNF_CALCULATE_WORK_TIME_URL = "/calculateWorkTime";
    public static final String UNAUTHORIZED_DEALER_ID_MESSAGE = "Dealer id is not authorised";

    @Value("${aposnf.service-url}")
    protected String aposnfEndPoint;
    @Autowired
    private ReverseMappingServiceProvider mappingServiceProvider;
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private DealerDataRepository dealerDataRepository;

    public List<LaborTimeInformation> getLaborTimeInformationUsingASInfo(String asid, BZD bzd, String dealerId, String token) throws IOException {

        DealerData dealerData = dealerDataRepository.findByDealerId(dealerId);
        if (dealerData == null) {
            throw new InvalidDealerIDException(UNAUTHORIZED_DEALER_ID_MESSAGE);
        }
        WorkTimeCalculation workTimeCalculation;
        List<String> laborTimeIds = mappingServiceProvider.getLaborTimeIds(asid);
        if (!laborTimeIds.isEmpty()) {
            List<LabourOperation> laborOperations = getLaborOperationsFromAposnf(bzd, laborTimeIds, token);
            if (!laborOperations.isEmpty()) {
                workTimeCalculation = getWorkTimeFromAposnf(getLopIds(laborOperations), bzd.getBrand(), token);
                if (workTimeCalculation.getLabourOperations() != null) {
                    List<LabourOperationWorkTime> labourOperationWorkTime = workTimeCalculation.getLabourOperations();
                    Map<Long, Integer> mapOfLopIdToTime = createMapOfLopIdToTime(labourOperationWorkTime);
                    return laborOperations.stream().map(labourOperation -> new LaborTimeInformation(
                            labourOperation.getBasenumberIdentifier(),
                            labourOperation.getDescription(),
                            mapOfLopIdToTime.get(labourOperation.getLopId()),
                            labourOperation.getActivityIdentifier())
                    ).collect(Collectors.toList());

                }
            }
        }
        return new ArrayList<>();
    }

    private String getLopIds(List<LabourOperation> laborOperations) {
        List<String> lopIdList = laborOperations.stream().map(labourOperation -> String.valueOf(labourOperation.getLopId())).collect(Collectors.toList());
        return join(",", lopIdList);
    }

    private Map<Long, Integer> createMapOfLopIdToTime(List<LabourOperationWorkTime> labourOperationWorkTimes) {
        return labourOperationWorkTimes
                .stream()
                .collect(Collectors.toMap(LabourOperationWorkTime::getLopId, LabourOperationWorkTime::getWorkTime, (oldLopId, newLopId) -> newLopId));
    }

    private ArrayList<LabourOperation> getLaborOperationsFromAposnf(BZD bzd, List<String> referenceNumberList, String token) throws IOException {
        String commaSeparatedReferenceNumbers = join(",", referenceNumberList);
        String languageISO = GeneralUtility.modifyLanguageToISO(bzd.getLang(), bzd.getCountry());
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("basenumbers", commaSeparatedReferenceNumbers);
        queryParams.add("engines", bzd.getMkb());
        queryParams.add("language", languageISO);
        queryParams.add("manufacturer", bzd.getBrand());
        queryParams.add("modelCode", bzd.getVt());
        queryParams.add("features", join(",", bzd.getPrnumber()));
        queryParams.add("modelYear", String.valueOf(bzd.getModelyear()));
        queryParams.add("transmissions", bzd.getGkb());

        ResponseEntity<String> responseEntity = makeRestCallToAposnf(aposnfEndPoint.concat(APOSNF_LABOR_OPERATION_URL), queryParams, token);

        if (isHTTPStatusOK(responseEntity)) {
            return new ObjectMapper().readValue(responseEntity.getBody(), new TypeReference<ArrayList<LabourOperation>>() {
            });
        } else {
            return new ArrayList<>();
        }
    }

    private WorkTimeCalculation getWorkTimeFromAposnf(String lopIds, String brand, String token) throws IOException {
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("lopIds", lopIds);
        queryParams.add("manufacturer", brand);

        ResponseEntity<String> responseEntity = makeRestCallToAposnf(aposnfEndPoint.concat(APOSNF_CALCULATE_WORK_TIME_URL), queryParams, token);

        if (isHTTPStatusOK(responseEntity)) {
            return new ObjectMapper().readValue(responseEntity.getBody(), WorkTimeCalculation.class);
        } else {
            return new WorkTimeCalculation();
        }

    }

    private boolean isHTTPStatusOK(ResponseEntity<String> responseEntity) {
        return HttpStatus.OK.value() == responseEntity.getStatusCode().value();
    }

    private HttpHeaders createHeader(final String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(AUTHORIZATION, token);
        return headers;
    }

    private ResponseEntity<String> makeRestCallToAposnf(String url, MultiValueMap<String, String> queryParams, String token) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParams(queryParams);
        URI uri = builder.build().toUri();

        HttpEntity<String> entity = new HttpEntity<>(createHeader(token));
        log.info("APOS NF URI is {}", uri);
        return restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);

    }
}
