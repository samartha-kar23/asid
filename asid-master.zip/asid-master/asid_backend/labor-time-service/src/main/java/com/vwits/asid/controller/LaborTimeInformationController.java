package com.vwits.asid.controller;


import com.newrelic.api.agent.NewRelic;
import com.vwits.asid.entity.LaborTimeInformation;
import com.vwits.asid.exception.InvalidDealerIDException;
import com.vwits.asid.service.LaborTimeInformationService;
import com.vwits.asid.utility.entity.BZD;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

import static com.vwits.asid.utility.constants.ASIDAppConstants.APOS_API_PATH;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@RestController
@Validated
@Slf4j
public class LaborTimeInformationController {

    @Autowired
    private LaborTimeInformationService laborTimeInformationService;

    @ApiOperation(value = "This API helps in getting Labor Time information after providing required parameters")
    @ApiResponses(@ApiResponse(code = 200, message = "Success",response = LaborTimeInformation.class))
    @GetMapping(path = APOS_API_PATH)

    public ResponseEntity getLaborTimeInfo(@ApiParam(value = "After Sales Id, e.g. 107X1701", example = "107X1701") @RequestParam @NotBlank String asid,
                                           @Valid BZD bzd,
                                           @ApiParam(value = "App Name, e.g. devs", example = "devs") @RequestParam(name = "appname") @NotBlank String appName,
                                           @ApiParam(value = "Dealer Id, e.g. ASIDTESTS", example = "ASIDTESTS") @RequestParam(name = "dealerid") String dealerId,
                                           HttpServletRequest request) throws IOException {

        setupNewRelicParams(asid, dealerId, appName, bzd.getVt());

        List<LaborTimeInformation> laborTimeInformationList;
        try {
            String token = request.getHeader(AUTHORIZATION);
            laborTimeInformationList = laborTimeInformationService.
                    getLaborTimeInformationUsingASInfo(asid, bzd,
                            dealerId, token);

        } catch (InvalidDealerIDException exception) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(exception.getMessage());
        } catch (RestClientResponseException exception) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).build();
        }

        if (laborTimeInformationList == null || laborTimeInformationList.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(laborTimeInformationList);
    }

    private void setupNewRelicParams(String asid, String dealerId, String appname, String vt) {
        NewRelic.setTransactionName("Web", "labor_time");
        NewRelic.addCustomParameter("asid", asid);
        NewRelic.addCustomParameter("dealerid", dealerId);
        NewRelic.addCustomParameter("salestype", vt);
        NewRelic.addCustomParameter("appname", appname);
    }

    @ExceptionHandler(value = { ConstraintViolationException.class })
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ResponseEntity<Type> handleConstraintViolationException(ConstraintViolationException e) {
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @ControllerAdvice
    public class RestErrorHandler extends ResponseEntityExceptionHandler {

        @Override
        protected ResponseEntity<Object> handleMethodArgumentNotValid(
                MethodArgumentNotValidException ex,
                HttpHeaders headers,
                HttpStatus status,
                WebRequest request) {

            String bodyOfResponse = ex.getMessage();
            return new ResponseEntity(bodyOfResponse, headers, status);
        }
    }
}
