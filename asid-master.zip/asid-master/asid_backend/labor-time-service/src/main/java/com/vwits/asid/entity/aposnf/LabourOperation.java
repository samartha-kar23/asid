package com.vwits.asid.entity.aposnf;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Wither;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Wither
public class LabourOperation {
    private String activityIdentifier;
    private String afterSalesNumber;
    private Integer amount;
    private String basenumberIdentifier;
    private String description;
    private String location;

    @JsonProperty(required = true)
    private Long lopId;

    private String position;
    private String side;

}