package com.vwits.asid.entity.aposnf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonRootName(value="labourOperations")
public class LabourOperationWorkTime {

    @JsonProperty(required = true)
    private Long lopId;
    @JsonProperty(required = true)
    private Integer workTime;
    @JsonProperty(required = true)
    private Integer effectiveWorkTime;
}
