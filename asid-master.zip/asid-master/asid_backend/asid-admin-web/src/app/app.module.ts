import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {AppComponent} from './app.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {FetchMappingComponent} from './fetch-mapping/fetch-mapping.component';
import {AddRlMappingComponent} from './add-rl-mapping/add-rl-mapping.component';
import {ToasterModule} from 'angular2-toaster';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterModule} from '@angular/router';
import {WindowRefService} from './windowRef.service';

@NgModule({
  declarations: [
    AppComponent,
    FetchMappingComponent,
    AddRlMappingComponent],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ToasterModule.forRoot(),
    BrowserAnimationsModule,
    RouterModule.forRoot([
      {
        path: '',
        component: AppComponent
      }
    ])
  ],
  providers: [{provide: WindowRefService, useValue: new WindowRefService()}],
  bootstrap: [AppComponent]
})
export class AppModule {
}
