import {ComponentFixture, TestBed} from '@angular/core/testing';

import {FetchMappingComponent} from './fetch-mapping.component';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {FormsModule} from '@angular/forms';
import {environment} from '../../environments/environment';

describe('FetchMappingComponent', () => {
  let component: FetchMappingComponent;
  let httpClient: HttpTestingController;
  let fixture: ComponentFixture<FetchMappingComponent>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [FetchMappingComponent]
    });

    fixture = TestBed.createComponent(FetchMappingComponent);
    httpClient = TestBed.get(HttpTestingController);

    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('View Mapping List', () => {
    it('should return list of mapped ids for the entered id', () => {
        component.isAsid = true;
        component.apiPath = '/abc=';
        component.infoMediaIdName = 'repair manual id';

        const asid = '102';
        component.fetchIds(asid);

      const url = '/admin' + component.apiPath + asid;
      mockHttpRequest('GET', url, ['123', '12', '23'] );
        expect(component.mappingList.length).toBe(3);

        httpClient.verify();
      }
    )
    ;


    it('should return empty list if no id is mapped to the entered id', () => {
      component.isAsid = true;
      component.apiPath = '/abc=';
      component.infoMediaIdName = 'repair manual id';

      const asid = '102';
      component.fetchIds(asid);

      const url = '/admin' + component.apiPath + asid;
      mockHttpRequest('GET', url, []);
      expect(component.mappingList.length).toBe(0);

      httpClient.verify();
    });
  });

  describe('Remove Mapping Entry', () => {
    it('should remove given mapping when confirmed and update the ui', () => {
      component.apiPath = '/abc=';

      const asid = '102';
      const infoMediaId = 'some-id';
      const deleteRLAPIPath = '/deleterlmapping';
      const urlParam = '?asid=' + asid + '&rlid=' + infoMediaId;
      const deleteUrl = environment.mappingServiceBaseURL.concat(deleteRLAPIPath).concat(urlParam);
      component.isAsid = true;

      spyOn(window, 'confirm').and.returnValue(true);
      spyOn(component, 'fetchIds').and.callFake((args) => expect(args).toBe(asid));

      component.removeMapping(asid, infoMediaId);

      const testRequest = httpClient.expectOne(deleteUrl, 'delete should be called');
      testRequest.flush('');
      expect(testRequest.request.method).toBe('DELETE');
      expect(component.fetchIds).toHaveBeenCalled();
      expect(window.confirm).toHaveBeenCalled();
      httpClient.verify();
    });

    it('should remove given mapping for rlid when confirmed and update the ui', () => {

      component.apiPath = '/abc=';

      const asid = '102';
      const infoMediaId = 'some-id';
      const deleteRLAPIPath = '/deleterlmapping';
      const urlParam = '?asid=' + asid + '&rlid=' + infoMediaId;
      const deleteUrl = environment.mappingServiceBaseURL.concat(deleteRLAPIPath).concat(urlParam);
      component.isAsid = false;

      spyOn(window, 'confirm').and.returnValue(true);
      const spy = spyOn(component, 'fetchIds');
      spy.and.callFake((args) => expect(args).toBe(infoMediaId));
      component.removeMapping(asid, infoMediaId);

      const testRequest = httpClient.expectOne(deleteUrl, 'delete should be called');
      testRequest.flush({
        statusText: '',
        status: 204
      });
      expect(testRequest.request.method).toBe('DELETE');
      expect(component.fetchIds).toHaveBeenCalled();
      expect(window.confirm).toHaveBeenCalled();
      httpClient.verify();

    });
  });

  function mockHttpRequest(methodType: string, regExUrl: string, mockResponseBody: any, requestBody?: any) {
    const req = httpClient.match(req => req.url.match(regExUrl).length > 0);
    expect(req.length).toBe(1);
    expect(req[0].request.method).toBe(methodType);
    req[0].flush(mockResponseBody);
  }
});
