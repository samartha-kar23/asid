import {Component, Input, OnInit} from '@angular/core';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';

@Component({
  selector: 'app-fetch-mapping',
  templateUrl: './fetch-mapping.component.html',
  styleUrls: ['./fetch-mapping.component.css']
})
export class FetchMappingComponent implements OnInit {
  @Input() infoMediaIdName: string;
  @Input() isAsid: boolean;
  @Input() apiPath: string;
  queriedId: string;
  mappingList: string[];
  enteredId: any;

  constructor(private httpclient: HttpClient) {
  }

  ngOnInit() {
    this.mappingList = [];
    this.queriedId = '';
  }

  fetchIds(id: string) {
    this.resetDataInView();

    const url = environment.mappingServiceBaseURL.concat(this.apiPath + id);

    this.httpclient.get<string>(url, { withCredentials: true, responseType: 'text' as 'json'}).subscribe(
      (result) => {
        this.mappingList = JSON.parse(result);
        this.queriedId = id;
      }, error => console.error(error));
  }

  private resetDataInView() {
    this.mappingList = [];
    this.queriedId = '';
  }
  getPlaceHolderText() {
    if (this.isAsid) {
      return 'enter asid here';
    } else {
      return 'enter ' + this.infoMediaIdName.toLocaleLowerCase();
    }
  }

  removeMapping(asid: string, infoMediaId: string) {
    if (!confirm('This action will delete the entry!')) {
      return;
    }
    const deleteRLAPIPath = '/deleterlmapping';
    const urlParam = '?asid=' + asid + '&rlid=' + infoMediaId;
    const url = environment.mappingServiceBaseURL.concat(deleteRLAPIPath).concat(urlParam);
    this.httpclient.delete(url, {withCredentials: true, responseType: 'text' as 'json'})
      .subscribe(() => {
        if (this.isAsid) {
          this.fetchIds(asid);
        } else {
          this.fetchIds(infoMediaId);
        }
      }, () => console.error('failed to delete'));

  }
}
