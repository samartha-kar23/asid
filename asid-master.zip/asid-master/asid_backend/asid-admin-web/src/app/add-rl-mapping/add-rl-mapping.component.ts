import {Component, OnInit} from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {ToasterService} from 'angular2-toaster';

@Component({
  selector: 'app-add-rl-mapping',
  templateUrl: './add-rl-mapping.component.html',
  styleUrls: ['./add-rl-mapping.component.css']
})
export class AddRlMappingComponent implements OnInit {

  public toasterService: ToasterService;
  asid: string;
  rlId: string;

  constructor(private httpClient: HttpClient, toasterService: ToasterService) {
    this.toasterService = toasterService;
  }

  ngOnInit() {
    this.asid = '';
    this.rlId = '';
  }

  addMapping(asid: string, rlId: string) {
    const addRLMappingUrl = environment.mappingServiceBaseURL.concat('/addrlmapping');
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      withCredentials: true
    };

    this.httpClient.post<string>(addRLMappingUrl, JSON.stringify({
      asid: asid, repairManualId: rlId
    }), httpOptions ).subscribe(
      data => {
        this.toasterService.pop('success', 'Success' , 'ASID ' + data['asid'] + ' successfully added');
      },
      error => {
        this.toasterService.pop('error', 'Failed' , error.error);
      });
  }
}
