import {ComponentFixture, TestBed} from '@angular/core/testing';

import {AddRlMappingComponent} from './add-rl-mapping.component';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {FormsModule} from '@angular/forms';
import {environment} from '../../environments/environment';
import {ToasterModule, ToasterService} from 'angular2-toaster';

describe('AddRlMappingComponent', () => {
  let component: AddRlMappingComponent;
  let httpClient: HttpTestingController;
  let fixture: ComponentFixture<AddRlMappingComponent>;
  let spyToasterObject: jasmine.SpyObj<ToasterService>;
  beforeEach(() => {
    const toasterSpy = jasmine.createSpyObj('ToasterService', ['pop']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, ToasterModule.forRoot()],
      declarations: [AddRlMappingComponent],
      providers: [
        {provide: ToasterService , useValue: toasterSpy}
      ]
    });

    fixture = TestBed.createComponent(AddRlMappingComponent);
    httpClient = TestBed.get(HttpTestingController);
    spyToasterObject = TestBed.get(ToasterService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add asid and its mapped rlid to rl mapping and show proper alerts', function () {
    const asid = 'asid-123';
    const rlid = 'rlid-123';
    component.addMapping(asid, rlid);

    const addURL = environment.mappingServiceBaseURL.concat('/addrlmapping');
    const data = {asid: asid, repairManualId: rlid};
    mockHttpRequest('POST', addURL).flush(data);
    expect(spyToasterObject.pop.calls.count()).toBe(1);
    expect(spyToasterObject.pop.calls.mostRecent().args.length).toBe(3);
    expect(spyToasterObject.pop.calls.mostRecent().args).toContain('success', 'wrong method type called');
    expect(spyToasterObject.pop.calls.mostRecent().args).toContain('Success', 'wrong title');
    expect(spyToasterObject.pop.calls.mostRecent().args[2]).toContain(asid, 'wrong message');
  });

  it('should try to add mapping and should show proper alerts for error response from server', function () {
    const asid = 'asid-123';
    const rlid = 'rlid-123';
    component.addMapping(asid, rlid);

    const addURL = environment.mappingServiceBaseURL.concat('/addrlmapping');
    const data = JSON.stringify({
      asid: asid, repairManualId: rlid
    });
    const errorMessage = 'abc';
    mockHttpRequest('POST', addURL).flush(errorMessage, {
      status: 422,
      statusText: ''
    });
    expect(spyToasterObject.pop.calls.count()).toBe(1);
    expect(spyToasterObject.pop.calls.mostRecent().args.length).toBe(3);
    expect(spyToasterObject.pop.calls.mostRecent().args).toContain('error', 'wrong method type called');
    expect(spyToasterObject.pop.calls.mostRecent().args).toContain('Failed', 'wrong title');
    expect(spyToasterObject.pop.calls.mostRecent().args).toContain(errorMessage, 'wrong message');
  });

  function mockHttpRequest(methodType: string, regExUrl: string) {
    const req = httpClient.match(req => req.url.match(regExUrl).length > 0);
    expect(req.length).toBe(1);
    expect(req[0].request.method).toBe(methodType);
    return req[0];
  }
});

