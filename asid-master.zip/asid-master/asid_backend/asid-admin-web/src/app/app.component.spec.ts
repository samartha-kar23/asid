import {ComponentFixture, TestBed} from '@angular/core/testing';
import {AppComponent} from './app.component';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {ToasterModule} from 'angular2-toaster';
import {AddRlMappingComponent} from './add-rl-mapping/add-rl-mapping.component';
import {FetchMappingComponent} from './fetch-mapping/fetch-mapping.component';
import {FormsModule} from '@angular/forms';
import {WindowRefService} from './windowRef.service';
import {environment} from '../environments/environment';


describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let httpClient: HttpTestingController;
  let windowRef;

  beforeEach((() => {

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, ToasterModule.forRoot()],
      declarations: [AppComponent, FetchMappingComponent, AddRlMappingComponent],
      providers: [
        {provide: WindowRefService, useClass: MockWindowRef}
      ]
    });
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    httpClient = TestBed.get(HttpTestingController);
    windowRef = TestBed.get(WindowRefService);

  }));

  it('should create the app', () => {
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });


  it('should display admin page when session is authenticated and authorised', async () => {
    // given
    mockHttpRequest('GET', '/userdetails').flush('successful');
    await fixture.whenStable();

    // when
    fixture.detectChanges();

    // then
    expect(component.isAuthenticated).toBeTruthy();
    expect(component.isAuthorized).toBeTruthy();
    expect(component.loggedInUserId).toBeTruthy();
  });

  it('should display admin page when session is not authenticated', async () => {
    // given
    mockHttpRequest('GET', '/userdetails').flush('error', {
      status: 401,
      statusText: 'Unauthorized'
    });
    await fixture.whenStable();

    // when
    fixture.detectChanges();

    // then
    expect(component.isAuthenticated).toBeFalsy();
    expect(component.loggedInUserId).toBeFalsy();
    expect(windowRef.nativeWindow.location.href).toContain(environment.mappingServiceBaseURL);
  });

  it('should logout user when logs out', async function () {

    component.isAuthenticated = true;
    mockHttpRequest('GET', '/userdetails').flush('tonyStark@marvel.com');

    component.logoutUser();
    await fixture.whenStable();
    mockHttpRequest('GET', '/logout-user').flush('success');

    expect(component.isAuthenticated).toBeFalsy();
    expect(component.loggedInUserId).toBeNull();
    expect(windowRef).toBeDefined();
    expect(windowRef.nativeWindow.location.href).toBe(environment.mappingServiceBaseURL);

  });


  it('should not redirect to home page when logout fails', async function () {

    component.isAuthenticated = true;
    mockHttpRequest('GET', '/userdetails').flush('tonyStark@marvel.com');

    component.logoutUser();
    await fixture.whenStable();
    mockHttpRequest('GET', '/logout-user').flush('error', {
      status: 401,
      statusText: 'Unauthorized'
    });

    expect(component.isAuthenticated).toBe(true);
    expect(component.loggedInUserId).toBe('tonyStark@marvel.com');
    expect(windowRef).toBeDefined();
    expect(windowRef.nativeWindow.location.href).not.toBe(environment.mappingServiceBaseURL);

  });

  it('should not display admin page when user is not authorized', async () => {

    mockHttpRequest('GET', '/userdetails').flush('error', {
      status: 403,
      statusText: 'Unauthorized'
    });
    await fixture.whenStable();

    fixture.detectChanges();

    expect(component.isAuthenticated).toBeTruthy();
    expect(component.isAuthorized).toBeFalsy();

  });


  class MockWindowRef {
    constructor() {
    }

    fakeWindow = {
      location: {href: 'http://default_dummy_url'}
    };

    get nativeWindow(): any {
      return this.fakeWindow;
    }
  }

  function mockHttpRequest(methodType: string, data: string) {
    const req = httpClient.match(req => req.url.match(data).length > 0);
    expect(req.length).toBe(1);
    expect(req[0].request.method).toBe(methodType);
    return req[0];
  }

});

