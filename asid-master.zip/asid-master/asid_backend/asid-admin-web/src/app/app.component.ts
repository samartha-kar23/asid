import {Component, OnInit} from '@angular/core';
import {environment} from '../environments/environment';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {WindowRefService} from './windowRef.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'D!AS - ASID Mapping Management Portal';

  rlMappingDownloadUrl = environment.mappingServiceBaseURL.concat('/rlmappingdata');
  loggedInUserId: string;
  isAuthenticated: boolean;
  isAuthorized = true;

  constructor(private httpclient: HttpClient, private windowRef: WindowRefService) {
  }

  ngOnInit() {
    const url = environment.mappingServiceBaseURL.concat('/userdetails');
    this.httpclient.get<string>(url, {withCredentials: true, responseType: 'text' as 'json'}).subscribe(
      (loggedInUserId) => {
        this.isAuthenticated = true;
        this.loggedInUserId = loggedInUserId;
      },
      (error: HttpErrorResponse) => {
        this.isAuthenticated = false;
        this.loggedInUserId = null;

        if (error.status === 403) {
          this.isAuthenticated = true;
          this.isAuthorized = false;
        } else {
          this.navigateToHome();
        }
      });
  }

  private navigateToHome() {
    this.windowRef.nativeWindow.location.href = environment.mappingServiceBaseURL;
  }

  logoutUser() {
    const url = environment.mappingServiceBaseURL.concat('/logout-user');
    this.httpclient
      .get(url, {withCredentials: true, responseType: 'text' as 'json'})
      .subscribe(() => {
        },
        error => console.error((error)),
        () => {
          this.isAuthenticated = false;
          this.loggedInUserId = null;
          this.navigateToHome();
        });
  }

}
