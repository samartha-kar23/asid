// Ignore IDE errors for this file

const environment = require('yargs').argv.environment;
const isProd = require('yargs').argv.prod;

const targetPath = `./src/environments/environment.${environment}.ts`;
const envConfigFile = `
export const environment = {
  production: ${isProd},
  mappingServiceBaseURL:  '${process.env.MAPPING_SERVICE_URL}'
};
`;
require('fs').writeFile(targetPath, envConfigFile, function (err) {
  if (err) {
    console.log(err);
  }

  console.log(`Output generated at ${targetPath}`);
});
