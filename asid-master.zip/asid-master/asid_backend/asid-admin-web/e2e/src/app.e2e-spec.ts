import {AppPage} from './app.page';
import {browser, by, element, promise, protractor} from 'protractor';

const TEST_WAIT_TIME = 150000;
function waitForLoginPage() {
  browser.driver.wait(function () {
    return browser.driver.getCurrentUrl().then(function (url) {
      return url.includes('https://identity');
    });
  }, TEST_WAIT_TIME);

  browser.driver.wait(function () {
    return browser.driver.findElement(by.name('email')).isDisplayed().then( () => true).catch(() =>  false);
  }, TEST_WAIT_TIME);
}

function waitForLoginPageToGoAway() {
  browser.driver.wait(function () {
    return browser.driver.getCurrentUrl().then(function (url) {
      return !(url.includes('https://identity'));
    });
  }, TEST_WAIT_TIME);
}

function logIn(page: AppPage) {
  page.getUserNameInputBox().sendKeys(process.env.E2E_IDKIT_USER);
  page.getPasswordInputBox().sendKeys(process.env.E2E_IDKIT_PASS);
  return page.getLoginButton().click();
}


function logInWithUnauthorziedUser(page: AppPage) {
  page.getUserNameInputBox().sendKeys(process.env.E2E_IDKIT_UNAUTHORIZED_USER);
  page.getPasswordInputBox().sendKeys(process.env.E2E_IDKIT_UNAUTHORIZED_PASS);
  page.getLoginButton().click();
}

function waitForMainFeatureToAppear(someFunc: () => promise.Promise<boolean>) {
  browser.wait(protractor.ExpectedConditions.presenceOf(element(by.name('span-input-label'))), TEST_WAIT_TIME);
  browser.driver.wait(function () {
    return someFunc();
  }, TEST_WAIT_TIME);
}

function waitForErrorToAppear(someFunc: () => promise.Promise<boolean>) {
  browser.wait(protractor.ExpectedConditions.presenceOf(element(by.className('alert alert-danger'))), TEST_WAIT_TIME);
  browser.driver.wait(function () {
    return someFunc();
  }, TEST_WAIT_TIME);
}


describe('ASID manage mapping  Web Application', () => {
  let page: AppPage = new AppPage();

  describe('before logging in', () => {
    beforeEach(() => {
      browser.driver.manage().deleteAllCookies();
    });

    it('should have idkit login page at the start', () => {
      browser.waitForAngularEnabled(false);
      page.navigateToHome();
      waitForLoginPage();
      expect(browser.driver.getCurrentUrl()).toContain('https://identity');
      expect(browser.isElementPresent(by.css('le-welcome-message')));
      expect(browser.isElementPresent(by.name('userCredentialsForm')));
      expect(browser.isElementPresent(by.name('email')));
      expect(browser.isElementPresent(by.name('password')));
      expect(browser.isElementPresent(by.id('submit-button')));
    });
    afterAll(async () => {
      await browser.restart();
    });
  });

  describe('On successful login', () => {
    beforeAll(() => {
      browser.driver.manage().deleteAllCookies();
      browser.waitForAngularEnabled(false);
      page.navigateToHome();
      waitForLoginPage();
      expect(browser.driver.getCurrentUrl()).toContain('https://identity');
      logIn(page);
      browser.waitForAngularEnabled(true);
      waitForLoginPageToGoAway();
      page.navigateToHome();
      waitForMainFeatureToAppear(() => page.isWelcomeMessageElementPresent());
    });
    describe('on homepage', () => {
      it('should display welcome message', () => {
        expect(page.getParagraphText()).toEqual('D!AS - ASID Mapping Management Portal');
      });

      it('should verify all required HTML elements on the dashboard', () => {
        expect(page.getAsidHeadText()).toEqual('Enter Id :');
        expect(page.getAsidInputBoxElement().isDisplayed).toBeTruthy();
        expect(page.getAsidSubmitButtonElement().isDisplayed).toBeTruthy();
        expect(page.getInternalClassificationImage()).toBeTruthy();
        expect(page.getLogOutButton().isDisplayed).toBeTruthy();
        expect(page.getDownloadAnchorElement().isDisplayed).toBeTruthy();
        expect(page.getDownloadAnchorElement().getAttribute('href')).toContain('/rlmappingdata');
      });
    });

    describe('on homepage to validate CRUD operations ', () => {
      const rlId1 = 'rlid1';
      const rlId2 = 'rlid2';
      const asid = 'asid';

      function addMappings() {
        page.getASIDInputBoxForNewEntryElement().sendKeys(asid);
        page.getRLIdInputBoxForNewEntryElement().sendKeys(rlId1);
        page.getAddButtonElement().sendKeys(protractor.Key.ENTER);

        page.getASIDInputBoxForNewEntryElement().clear();
        page.getRLIdInputBoxForNewEntryElement().clear();

        page.getASIDInputBoxForNewEntryElement().sendKeys(asid);
        page.getRLIdInputBoxForNewEntryElement().sendKeys(rlId2);
        page.getAddButtonElement().sendKeys(protractor.Key.ENTER);

        page.navigateToHome();
        waitForMainFeatureToAppear(() => page.isWelcomeMessageElementPresent());
      }

      it('should add record in mapping table when user presses add button with valid records', () => {
        // given two entries are added
        addMappings();

        // Validating table for ASID and RLId presence
        page.getAsidInputBoxElement().sendKeys(asid);
        page.getAsidSubmitButtonElement().sendKeys(protractor.Key.ENTER);
        expect(page.isASIDTableElementPresent()).toBeTruthy();

        page.getRLIdInputBoxElement().sendKeys(rlId1);
        page.getRLIdSubmitButtonElement().sendKeys(protractor.Key.ENTER);
        expect(page.isRLIdTableElementPresent()).toBeTruthy();
      });

      it('should delete record in mapping table when user presses delete button on a specific mapping row in RL ID search or ASID Search',
        () => {
          addMappings();

          page.getRLIdInputBoxElement().sendKeys(rlId1);
          page.getRLIdSubmitButtonElement().click();

          waitForMainFeatureToAppear(() => page.isRLIdTableElementPresent());
          page.getDeleteButtonForRLIdElement().then((deleteButton) => {
            deleteButton.click();
          });
          page.acceptAlert();
          // refresh table and delete second

          page.getAsidInputBoxElement().sendKeys(asid);
          page.getAsidSubmitButtonElement().click();
          waitForMainFeatureToAppear(() => page.isASIDTableElementPresent());
          page.getDeleteButtonForAsidElement().then((deleteButton) => {
            deleteButton.click();
          });
          page.acceptAlert();
        });
    });

    afterAll(() => {
      browser.restart();
    });
  });

  describe('For UnAuthorized User', () => {
    beforeAll(() => {
      browser.driver.manage().deleteAllCookies();
      page = new AppPage();
      browser.waitForAngularEnabled(false);
      page.navigateToHome();
      waitForLoginPage();
      expect(browser.driver.getCurrentUrl()).toContain('https://identity');
      logInWithUnauthorziedUser(page);
      waitForLoginPageToGoAway();
      browser.waitForAngularEnabled(true);
      page.navigateToHome();
      waitForErrorToAppear(() => page.isWelcomeMessageElementPresent());
    });

    describe('on homepage', () => {
      it('should display welcome message', () => {
        expect(page.getParagraphText()).toEqual('D!AS - ASID Mapping Management Portal');
      });

      it('should display an error message with Admin email Id', () => {
        expect(page.getAlertDialogBox().isDisplayed).toBeTruthy();
        expect(page.getAlertTitle()).toEqual('Not A Member.');
        expect(page.getDefaultAlertMessage()).toEqual('Please contact to asid.it.teamuser.vwag.r.wob@volkswagen.de to get an access!');
        expect(page.getLogOutButton().isDisplayed).toBeTruthy();
      });
    });

    afterAll(() => {
      browser.restart();
    });
  });

  describe('on logout', () => {
    beforeAll(() => {
      browser.waitForAngularEnabled(false);
      page = new AppPage();
      page.navigateToHome();
      waitForLoginPage();
      expect(browser.driver.getCurrentUrl()).toContain('https://identity');
      logIn(page);
      waitForLoginPageToGoAway();
      page.navigateToHome();
      browser.waitForAngularEnabled(true);
      waitForMainFeatureToAppear(() => page.isWelcomeMessageElementPresent());
    });

    it('should display identity kit login page after logout', () => {
      browser.waitForAngularEnabled(false);
      page.getLogOutButton().then((button) => {
        button.click();
      });
      waitForLoginPage();
      expect(page.getUserNameInputBox().isDisplayed).toBeTruthy();
      expect(page.getPasswordInputBox().isDisplayed).toBeTruthy();
      expect(browser.driver.getCurrentUrl()).toContain('https://identity');
      expect(browser.isElementPresent(by.name('logout_button'))).toBeFalsy();
    });
  });
});

