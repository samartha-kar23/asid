import {browser, by, element} from 'protractor';
import {By} from 'selenium-webdriver';

export class AppPage {
  navigateToHome() {
    return browser.get('/');
  }

  isWelcomeMessageElementPresent() {
    return element(by.name('welcome_message')).isPresent();
  }

  getParagraphText() {
    return element(by.name('welcome_message')).getText();
  }

  getAsidInputBoxElement() {
    return element(by.name('asid_to_rlId_mapping')).element(by.name('input-extId')).getWebElement();
  }

  getAsidHeadText() {
    return element(by.name('asid_to_rlId_mapping')).element(by.name('span-input-label')).getText();
  }

  getAsidSubmitButtonElement() {
    return element(by.name('asid_to_rlId_mapping')).element(by.name('button-submit-id')).getWebElement();
  }

  getASIDTableElement() {
    return element(by.name('asid_to_rlId_mapping')).element(by.name('table_mapping')).getWebElement();
  }

  isASIDTableElementPresent() {
    return element(by.name('asid_to_rlId_mapping')).element(by.name('table_mapping')).isPresent();
  }

  getRLIdInputBoxElement() {
    return element(by.name('rlId_to_asid_mapping')).element(by.name('input-extId')).getWebElement();
  }

  getRLIdHeadText() {
    return element(by.name('rlId_to_asid_mapping')).element(by.name('span-input-label')).getText();
  }

  getRLIdSubmitButtonElement() {
    return element(by.name('rlId_to_asid_mapping')).element(by.name('button-submit-id')).getWebElement();
  }
  getRLIdTableElement() {
    return element(by.name('rlId_to_asid_mapping')).element(by.name('table_mapping')).getWebElement();
  }

  isRLIdTableElementPresent() {
    return element(by.name('rlId_to_asid_mapping')).element(by.name('table_mapping')).isPresent();
  }

  getDownloadAnchorElement() {
    return element(by.name('anchor_download_mapping')).getWebElement();
  }

  getRLIdInputBoxForNewEntryElement() {
    return element(by.name('add_new_rlmapping')).element(by.name('input-enter-rlid')).getWebElement();
  }

  getASIDInputBoxForNewEntryElement() {
    return element(by.name('add_new_rlmapping')).element(by.name('input-enter-asid')).getWebElement();
  }

  getAddButtonElement() {
    return element(by.name('add_new_rlmapping')).element(by.name('button-add-mapping')).getWebElement();
  }

  getDeleteButtonForAsidElement() {
    return this.getASIDTableElement().findElement(by.name('delete-record'));
  }

  getDeleteButtonForRLIdElement() {
    return this.getRLIdTableElement().findElement(by.name('delete-record'));
  }

  getUserNameInputBox() {
    return element(By.name('email')).getWebElement();
  }


  getPasswordInputBox() {
    return element(by.name('password')).getWebElement();
  }

  getLoginButton() {
    return element(by.id('submit-button')).getWebElement();
  }

  acceptAlert() {
    browser.switchTo().alert().accept();
  }

  getLogOutButton() {
    return element(by.name('logout_button')).getWebElement();
  }

  getAlertDialogBox() {
    return element(by.className('alert alert-danger')).getWebElement();
  }

  getAlertTitle() {
    return element(by.name('alert_heading')).getText();
  }

  getDefaultAlertMessage() {
    return element(by.name('alert_message')).getText();
  }

  getInternalClassificationImage() {
      return element(by.name('Internal_Classification')).isPresent();
  }
}
