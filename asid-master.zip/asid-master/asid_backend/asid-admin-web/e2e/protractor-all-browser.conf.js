const { SpecReporter } = require('jasmine-spec-reporter');

exports.config = {
  allScriptsTimeout: 11000,
  specs: [
    './src/**/*.e2e-spec.ts'
  ],
  multiCapabilities: [{
    'browserName': 'chrome',
    chromeOptions: {
      args: [  "--headless", "--disable-gpu", "--window-size=1920,1080","--no-sandbox" ]
    }
  },{
    'browserName': 'firefox',
    'moz:firefoxOptions': {
      args: [ "--headless" ]
    }
  }],
  directConnect: true,
  baseUrl: process.env.ADMIN_WEB_URL || 'http://localhost:4200',
  framework: 'jasmine',
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 50000,
    print: function() {}
  },
  onPrepare() {
    require('ts-node').register({
      project: require('path').join(__dirname, './tsconfig.e2e.json')
    });
    jasmine.getEnv().addReporter(new SpecReporter({ spec: { displayStacktrace: true } }));

    console.log('**** Running tests on :- '+browser.baseUrl)
  }
};
