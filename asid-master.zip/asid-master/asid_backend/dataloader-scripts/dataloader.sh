#!/usr/bin/env bash

read -p 'Environment: ' env
read -p 'Database: ' dbname
read -p 'File path: ' file
read -p 'Table Name:' table_name

cf t -s $env
cf mysql $dbname -e "LOAD DATA LOCAL INFILE '$file' INTO TABLE $table_name CHARACTER SET UTF8 FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n'" --local-infile