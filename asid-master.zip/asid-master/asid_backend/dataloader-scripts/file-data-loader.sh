#!/usr/bin/env bash

#To run this script make sure you provide the root folder where all file content is present arrange in respective infomedia folders
#Also info media type and service name of cloud foundry has to be provided
# example : ./file-data-loader.sh /Users/asid/Desktop/ RL mysql_mapping

FILE_ROOT_FOLDER=${1}
INFO_MEDIA_TYPE=${2}
CF_SERVICE_NAME=${3}


IMAGE_FOLDER="$FILE_ROOT_FOLDER/$INFO_MEDIA_TYPE"
IMAGE_FOLDER_SEARCH="$IMAGE_FOLDER/*"

sudo mysql -e"
CREATE DATABASE IF NOT EXISTS UploadDB;
USE UploadDB;

DROP TABLE IF EXISTS file_content;
create table file_content(
	file_id varchar(255) not null primary key,
	file_data longblob null,
	file_type varchar(255) null,
	info_media_type varchar(255) null)charset=latin1;"


echo $IMAGE_FOLDER
echo '=================='

OIFS="$IFS"
IFS=$'\n'

for filename in `ls ${IMAGE_FOLDER}`
do
     cd ${IMAGE_FOLDER}
     FILE_TYPE=$(file -b --mime-type ${filename})
     sudo mysql -e"INSERT INTO UploadDB.file_content (file_id, file_data, file_type, info_media_type)
     VALUES ('"${filename%.*}"', LOAD_FILE('"${IMAGE_FOLDER}"/"${filename}"'), '"${FILE_TYPE}"', '"${INFO_MEDIA_TYPE}"');"

done

sudo mysqldump -t UploadDB file_content > ${FILE_ROOT_FOLDER}/${INFO_MEDIA_TYPE}.sql

echo "UPLOAD TO CLOUD ?"
read -p '[Y/N]: ' upload_to_cloud

if [ "${upload_to_cloud}" == "Y" ]; then
    echo "UPLOADING"
    cat ${FILE_ROOT_FOLDER}/${INFO_MEDIA_TYPE}.sql | cf mysql ${CF_SERVICE_NAME}
else
    echo "UPLOADING CANCELLED"
fi
