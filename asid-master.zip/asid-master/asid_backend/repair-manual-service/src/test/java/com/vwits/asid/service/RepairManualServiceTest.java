package com.vwits.asid.service;


import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.exception.*;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.entity.Scope;
import com.vwits.asid.utility.environment.EnvironmentProvider;
import com.vwits.asid.utility.i18n.LocalizationHelper;
import com.vwits.asid.utility.idkit.IdKitTokenReader;
import com.vwits.asid.utility.mapping.ReverseMappingServiceProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;

import static com.vwits.asid.service.RepairManualService.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class RepairManualServiceTest {

    private final String asid = "1234";
    private final String lang = "de-DE";
    private final String country = "DE";

    private final String vin = "vin";
    private final String rlId1 = "eng.10.2.1";
    private final String rlId2 = "abs.10.2.2";
    private final String rlId3 = "eng.10.2.3";
    private final String rlId5 = "IncorrectRLId";

    private final String dealerId = "dealerId";
    private String token = "token";
    @Mock
    private ReverseMappingServiceProvider mappingServiceProvider;
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private IdKitTokenReader idKitTokenReader;

    @Mock
    private EnvironmentProvider mockEnvProvider;

    @Mock
    private LocalizationHelper localizationHelper;

    @InjectMocks
    private RepairManualService repairManualService;
    private String e2GoDummyURL1;
    private String e2GoDummyURL2;
    private String e2GoDummyURL3;
    private String e2GoDummyURL4;
    private String e2GoDummyURL5;
    private String e2GoDummyURL6;

    private UriComponentsBuilder builder1;
    private UriComponentsBuilder builder2;
    private UriComponentsBuilder builder3;
    private UriComponentsBuilder builder4;
    private UriComponentsBuilder builder5;
    private UriComponentsBuilder builder6;


    private final String e2GoResponse = "<html>" +
            "  <head>" +
            "    <meta charset=\"utf-8\">" +
            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
            "  </head>" +
            "  <body>" +
            "   <h3>Menu Heading h3</h3>" +
            "   <div>" +
            "    <p>RL information</p>" + "<span>RL information</span>" +
            "     <div class=\"contentClass\"><div>Actual RL content</div></div>" +
            "     </div> " +
            "   <h2>Menu Heading h2</h2>" +
            "   </body>" +
            "</html>";


    String expectedSecurityText = "Sicherheitskopfzeilentext";
    String expectedTooltip = " Gegenwärtig werden Links nur innerhalb von VW Systemen unterstützt.";

    @Before
    public void setUp() {
        final String e2GoDummyBaseURL = "https://dummy-url";
        repairManualService.setElsa2GoUrl(e2GoDummyBaseURL);


        e2GoDummyURL1 = e2GoDummyBaseURL.concat("/api/repair-manual/").
                concat(GeneralUtility.modifyLanguageToISO(lang, country)).concat("/").concat(vin + "/").concat(rlId1 + "," + rlId2);
        e2GoDummyURL2 = e2GoDummyBaseURL.concat("/api/repair-manual/").
                concat(GeneralUtility.modifyLanguageToISO(lang, country)).concat("/").concat(vin + "/").concat(rlId2 + "," + rlId1 + "," + rlId3);
        e2GoDummyURL3 = e2GoDummyBaseURL.concat("/api/repair-manual/").
                concat(GeneralUtility.modifyLanguageToISO(lang, country)).concat("/").concat(vin + "/").concat(rlId3);
        e2GoDummyURL4 = e2GoDummyBaseURL.concat("/api/repair-manual/").
                concat(GeneralUtility.modifyLanguageToISO(lang, country)).concat("/").concat(vin + "/").concat(rlId2 + "," + rlId1);
        e2GoDummyURL5 = e2GoDummyBaseURL.concat("/api/repair-manual/").
                concat(GeneralUtility.modifyLanguageToISO(lang, country)).concat("/").concat(vin + "/").concat(rlId2 + "," + rlId3);
        e2GoDummyURL6 = e2GoDummyBaseURL.concat("/api/repair-manual/").
                concat(GeneralUtility.modifyLanguageToISO(lang, country)).concat("/").concat(vin + "/").concat(rlId5);


        builder1 = UriComponentsBuilder.fromHttpUrl(e2GoDummyURL1)
                .queryParam("dealerContexts", dealerId);
        builder2 = UriComponentsBuilder.fromHttpUrl(e2GoDummyURL2)
                .queryParam("dealerContexts", dealerId);
        builder3 = UriComponentsBuilder.fromHttpUrl(e2GoDummyURL3)
                .queryParam("dealerContexts", dealerId);
        builder4 = UriComponentsBuilder.fromHttpUrl(e2GoDummyURL4)
                .queryParam("dealerContexts", dealerId);
        builder5 = UriComponentsBuilder.fromHttpUrl((e2GoDummyURL5))
                .queryParam("dealerContexts", dealerId);

        builder6 = UriComponentsBuilder.fromHttpUrl((e2GoDummyURL6))
                .queryParam("dealerContexts", dealerId);

        when(idKitTokenReader.getToken()).thenReturn(token);
        when(mockEnvProvider.getStageName()).thenReturn(PRODUCTION_STAGE);
    }

    @Test
    public void shouldNotGenerateNewTokenForProdEnvironment() throws IOException, RepairManualException {
        when(mockEnvProvider.getStageName()).thenReturn(PRODUCTION_STAGE);
        when(mappingServiceProvider.getRlIds(asid, Scope.ALL)).thenReturn(Arrays.asList(rlId1, rlId2));

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(e2GoResponse, HttpStatus.OK));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.ALL, "dummy_token");

        verifyNoMoreInteractions(idKitTokenReader);
    }

    @Test
    public void shouldGenerateNewToken_OnNonProductionEnvironment() throws IOException, RepairManualException {
        when(mockEnvProvider.getStageName()).thenReturn("random");

        when(mappingServiceProvider.getRlIds(asid, Scope.ALL)).thenReturn(Arrays.asList(rlId1, rlId2));

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(e2GoResponse, HttpStatus.OK));

        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);

        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.ALL, "dummy_token");

        verify(idKitTokenReader, times(1)).getToken();
    }

    @Test
    public void shouldReturnRepairManualDTO_withCorrectE2GoResponse_WhenValidAfterSalesInfoProvided() throws IOException, RepairManualException {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("x-missing-ext-ids", "eng.10.2.1");

        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2, rlId3));

        HttpClientErrorException httpClientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null);

        when(restTemplate.exchange(eq(builder2.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(httpClientErrorException);

        when(restTemplate.exchange(eq(builder5.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(e2GoResponse, HttpStatus.OK));

        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.INDIRECT, "");

        assertEquals(asid, repairManualDTO.getHeader());
        assertEquals(2, repairManualDTO.getCount());
        assertNotNull(repairManualDTO.getChapters());
        assertEquals(1, repairManualDTO.getChapters().size());
        assertNotNull(repairManualDTO.getChapters().get(0));
        assertEquals(Scope.INDIRECT.getValue(), repairManualDTO.getChapters().get(0).getInfoLevel());
        assertEquals(asid, repairManualDTO.getChapters().get(0).getTitle());
    }

    @Test
    public void shouldReturnRepairManualDTO_withCorrectE2GoResponse_EvenWhenE2GoRespondsWith429() throws IOException, RepairManualException {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("x-missing-ext-ids", "eng.10.2.1");
        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2, rlId3));

        when(restTemplate.exchange(eq(builder2.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.TOO_MANY_REQUESTS)).thenReturn(new ResponseEntity<String>(e2GoResponse, HttpStatus.OK));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.INDIRECT, "");

        Method method = null;
        try {
            method = RepairManualService.class.getMethod("getRepairManualContentFromElsa2Go", String.class, String.class, String.class, String.class, String.class, Scope.class, String.class);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            fail();
        }

        assertEquals(asid, repairManualDTO.getHeader());
        assertEquals(3, repairManualDTO.getCount());
        assertNotNull(repairManualDTO.getChapters());
        assertEquals(1, repairManualDTO.getChapters().size());
        assertNotNull(repairManualDTO.getChapters().get(0));
        assertEquals(Scope.INDIRECT.getValue(), repairManualDTO.getChapters().get(0).getInfoLevel());
        assertEquals(asid, repairManualDTO.getChapters().get(0).getTitle());
    }

    @Test
    public void shouldReturnRepairManualDTO_WithDirectAndIndirectBothMappingFound_WhenValidAfterSalesInfoAndAllScopeIsProvided() throws IOException, RepairManualException {

        when(mappingServiceProvider.getRlIds(asid, Scope.ALL)).thenReturn(Arrays.asList(rlId1, rlId2));

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(e2GoResponse, HttpStatus.OK));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.ALL, "");

        assertEquals(asid, repairManualDTO.getHeader());
        assertEquals(2, repairManualDTO.getCount());
        assertEquals(1, repairManualDTO.getChapters().size());
        assertNotNull(repairManualDTO.getChapters().get(0));
        assertEquals(Scope.ALL.getValue(), repairManualDTO.getChapters().get(0).getInfoLevel());

    }

    @Test
    public void shouldReturnRepairManualDTO_WithDirectMappingFound_WhenValidAfterSalesInfoAndDirectScopeIsProvided() throws IOException, RepairManualException {

        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId1, rlId2));

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(e2GoResponse));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);
        // when:
        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");

        // then:
        assertEquals(asid, repairManualDTO.getHeader());
        assertEquals(2, repairManualDTO.getCount());
        assertNotNull(repairManualDTO.getChapters());
        assertEquals(1, repairManualDTO.getChapters().size());
        assertEquals(Scope.DIRECT.getValue(), repairManualDTO.getChapters().get(0).getInfoLevel());

    }

    @Test
    public void shouldReturnRepairManualDTO_WithInDirectMappingFound_WhenValidAfterSalesInfoAndIndirectScopeIsProvided() throws IOException, RepairManualException {

        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2));

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(e2GoResponse));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.INDIRECT, "");

        assertEquals(asid, repairManualDTO.getHeader());
        assertEquals(2, repairManualDTO.getCount());
        assertNotNull(repairManualDTO.getChapters());
        assertEquals(1, repairManualDTO.getChapters().size());
        assertEquals(Scope.INDIRECT.getValue(), repairManualDTO.getChapters().get(0).getInfoLevel());

    }

    @Test(expected = MappingNotFoundException.class)
    public void shouldReturnRepairManualDTO_WithDirectAndIndirectMappingNotFound_WhenValidAfterSalesInfoAndAllScopeIsProvided() throws IOException, RepairManualException {
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Collections.emptyList());
        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Collections.emptyList());

        when(restTemplate.exchange(eq(builder1.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(e2GoResponse));

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.ALL, "");
    }

    @Test(expected = DataFromE2GoNotFoundException.class)
    public void shouldReturnNothing_WhenE2GoDontHaveDataForDirectAndIndirectRlIDs_WhenValidAfterSalesInfoAndAllScopeIsProvided() throws IOException, RepairManualException {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("x-missing-ext-ids", rlId5);
        when(mappingServiceProvider.getRlIds(asid, Scope.ALL)).thenReturn(Arrays.asList(rlId5));

        when(restTemplate.exchange(eq(builder6.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null));

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.ALL, "");

    }

    @Test(expected = DataFromE2GoNotFoundException.class)
    public void shouldReturnNothing_WhenE2GoDontHaveDataForSpecificRlID_WhenValidAfterSalesInfoProvided() throws IOException, RepairManualException {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("x-missing-ext-ids", rlId3);
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId3));

        when(restTemplate.exchange(eq(builder3.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null));

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");
    }

    @Test(expected = LanguageNotFoundException.class)
    public void shouldReturnNothing_WhenE2GoDontSupportSpecifiedLanguage() throws IOException, RepairManualException {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("x-not-found-reason", "language");
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId3));

        when(restTemplate.exchange(eq(builder3.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null));

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");
    }

    @Test(expected = VinInvalidException.class)
    public void shouldReturnNothing_WhenInvalidVINIsProvided() throws IOException, RepairManualException {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("X-Not-Found-Reason", "vin");
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId3));

        when(restTemplate.exchange(eq(builder3.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null));

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");
    }

    @Test(expected = UnIdentifiedException.class)
    public void shouldReturnNothing_WhenExceptionOccursForUnknownReason() throws IOException, RepairManualException {
        HttpHeaders httpHeaders = new HttpHeaders();

        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId3));

        when(restTemplate.exchange(eq(builder3.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null));

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");
    }

    @Test
    public void shouldReturnRepairManualDTO_withCorrectE2GoResponseWithDeActivatedLinksAndToolTip_WhenValidAfterSalesInfoProvided() throws IOException, RepairManualException {
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId1, rlId2));

        String e2GoResponse = "<html>" +
                "  <head>" +
                "    <meta charset=\"utf-8\">" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
                "  </head>" +
                "  <body>" +
                "   <h3>Menu Heading</h3>" +
                "   <a href=\"sample\">sample_link</a>" +
                "    <p>RL for " + rlId1 + "</p>" +
                "  </body>" +
                "</html>";

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(e2GoResponse));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);
        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");

        repairManualDTO.getChapters().forEach(chapter -> {
            final String decodedChapterContent = new String(Base64.getDecoder().decode(chapter.getContent()));
            assertTrue(decodedChapterContent.contains("<a href"));
            assertTrue(decodedChapterContent.contains("onclick=\"return false;\""));
            assertTrue(decodedChapterContent.contains("title=\"" + expectedTooltip));
        });
    }

    @Test
    public void shouldReturnRepairManualDTO_withStyleDividerAboveHeader_WhenValidAfterSalesInfoProvided() throws IOException, RepairManualException {
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId1, rlId2));

        final String e2GoResponse = "<html>" +
                "  <head>" +
                "    <meta charset=\"utf-8\">" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
                "  </head>" +
                "  <body>" +
                "   <h3>Menu Heading</h3>" +
                "   <h2>Menu Heading 2</h2>" +
                "<a href=\"sample\">sample_link</a>" +
                "    <p>RL for " + rlId1 + "</p>" +
                "  </body>" +
                "</html>";

        final String dividerStyleName = "class=\"line-above-header\"";
        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(e2GoResponse));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);
        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");

        final String decodedChapterContent = new String(Base64.getDecoder().decode(repairManualDTO.getChapters().get(0).getContent()));

        assertTrue(decodedChapterContent.contains(dividerStyleName));
        assertEquals(1, StringUtils.countOccurrencesOf(decodedChapterContent, dividerStyleName));
    }

    @Test(expected = MappingNotFoundException.class)
    public void shouldReturnNull_whenNoMappingPresentForProvidedAsid() throws IOException, RepairManualException {
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(new ArrayList<>());
        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");
    }

    @Test
    public void shouldReturnSecurityHeaderTextInTheLanguageGivenAsInput() throws IOException, RepairManualException {

        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Arrays.asList(rlId1, rlId2));

        String e2GoResponse = "<html>" +
                "  <head>" +
                "    <meta charset=\"utf-8\">" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
                "  </head>" +
                "  <body>" +
                "   <h3>Menu Heading</h3>" +
                "<a href=\"sample\">sample_link</a>" +
                "    <p>RL for " + rlId1 + "</p>" +
                "  </body>" +
                "</html>";

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(e2GoResponse));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");

        repairManualDTO.getChapters().forEach(chapter -> {
            final String decodedChapterContent = new String(Base64.getDecoder().decode(chapter.getContent()));
            assertTrue(decodedChapterContent.contains(expectedSecurityText));

        });

    }

    @Test(expected = DealerUnauthorisedException.class)
    public void shouldReturnNotQualifiedErrorMessage_WhenE2GoReturns403_WithUnauthorizedDealerId() throws IOException, RepairManualException {

        String expectedUnauthorisedDealerIdText = "Ihre Händler-Nummer ist zur Anzeige nicht berechtigt.";

        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2, rlId3));

        HttpClientErrorException httpClientErrorException = new HttpClientErrorException(HttpStatus.FORBIDDEN, "Forbidden", ERROR_RESPONSE_FOR_UNAUTHORISED_DEALER_ID.getBytes(), null);

        when(restTemplate.exchange(eq(builder2.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(httpClientErrorException);

        when(localizationHelper.getMessage("unauthorized.dealer.message", lang)).thenReturn(expectedSecurityText);

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.INDIRECT, "");

        Method method = null;
        try {
            method = RepairManualService.class.getMethod("getRepairManualContentFromElsa2Go", String.class, String.class, String.class, String.class, String.class, Scope.class, String.class);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            fail();
        }

        repairManualDTO.getChapters().forEach(chapter -> {
            final String decodedChapterContent = new String(Base64.getDecoder().decode(chapter.getContent()));
            assertTrue(decodedChapterContent.contains(expectedUnauthorisedDealerIdText));


        });
    }

    @Test(expected = VinHandlingException.class)
    public void shouldReturnVinCannotBeHandledMessage_WhenE2GoReturns500_WithUnHandledVin() throws IOException, RepairManualException {

        String expectedUnhandledVinMessage = "Die angefragt FIN kann nicht verarbeitet werden.";

        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2, rlId3));

        HttpServerErrorException httpServerErrorException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server Error", ERROR_RESPONSE_FOR_UN_HANDLED_VIN.getBytes(), null);

        when(restTemplate.exchange(eq(builder2.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(httpServerErrorException);

        when(localizationHelper.getMessage("unhandled.vin.message", lang)).thenReturn(expectedSecurityText);

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.INDIRECT, "");

        Method method = null;
        try {
            method = RepairManualService.class.getMethod("getRepairManualContentFromElsa2Go", String.class, String.class, String.class, String.class, String.class, Scope.class, String.class);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            fail();
        }

        repairManualDTO.getChapters().forEach(chapter -> {
            final String decodedChapterContent = new String(Base64.getDecoder().decode(chapter.getContent()));
            assertTrue(decodedChapterContent.contains(expectedUnhandledVinMessage));


        });
    }

    @Test
    public void shouldReturnRepairManualDTO_withCorrectE2GoResponse_WhenValidAfterSalesInfoAndUnSupportedLangCountryProvided() throws IOException, RepairManualException {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("x-missing-ext-ids", "eng.10.2.1");

        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2, rlId3));

        HttpClientErrorException httpClientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null);

        when(restTemplate.exchange(eq(builder2.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(httpClientErrorException);

        when(restTemplate.exchange(eq(builder5.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(e2GoResponse, HttpStatus.OK));

        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        String unsupportedLanguage = "de";
        String unsupportedCountry = "XX";

        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, unsupportedLanguage, unsupportedCountry, Scope.INDIRECT, "");

        assertEquals(asid, repairManualDTO.getHeader());
        assertEquals(2, repairManualDTO.getCount());
        assertNotNull(repairManualDTO.getChapters());
        assertEquals(1, repairManualDTO.getChapters().size());
        assertNotNull(repairManualDTO.getChapters().get(0));
        assertEquals(Scope.INDIRECT.getValue(), repairManualDTO.getChapters().get(0).getInfoLevel());
        assertEquals(asid, repairManualDTO.getChapters().get(0).getTitle());
    }

    @Test(expected = LanguageNotFoundException.class)
    public void shouldReturnRepairManualDTO_withCorrectE2GoResponse_WhenValidAfterSalesInfoAndInvalidLangAndCountryProvided() throws IOException, RepairManualException {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("x-missing-ext-ids", "eng.10.2.1");

        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2, rlId3));

        HttpClientErrorException httpClientErrorException = new HttpClientErrorException(HttpStatus.NOT_FOUND, "", httpHeaders, null, null);

        when(restTemplate.exchange(eq(builder2.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(httpClientErrorException);

        when(restTemplate.exchange(eq(builder5.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<String>(e2GoResponse, HttpStatus.OK));

        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);

        String unsupportedLanguage = "xx";
        String unsupportedCountry = "XX";

        repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, unsupportedLanguage, unsupportedCountry, Scope.INDIRECT, "");
    }

    @Test
    public void shouldReturnRepairManualDTO_WithIndirectMapping_WhenRLIdListIsEmptyWithDirectScopeAndValidAfterSalesInfoAndDirectScopeIsProvided() throws IOException, RepairManualException {

        String expectedSubHeading = "Zu diesem Teil liegen keine Reparaturleitfäden vor. Die angezeigten Informationen könnten dennoch hilfreich sein.";
        when(mappingServiceProvider.getRlIds(asid, Scope.DIRECT)).thenReturn(Collections.emptyList());
        when(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT)).thenReturn(Arrays.asList(rlId1, rlId2));

        when(restTemplate.exchange(eq(builder4.build().toUri()), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ResponseEntity.ok(e2GoResponse));
        when(localizationHelper.getMessage("link.tooltip", lang)).thenReturn(expectedTooltip);
        when(localizationHelper.getMessage("security.header", new Object[]{expectedTooltip}, lang)).thenReturn(expectedSecurityText);
        when(localizationHelper.getMessage("indirect.mapping.text.when.direct.mapping.unavailable", lang)).thenReturn(expectedSubHeading);
        final RepairManualDTO repairManualDTO = repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, Scope.DIRECT, "");

        assertEquals(asid, repairManualDTO.getHeader());
        assertEquals(2, repairManualDTO.getCount());
        assertNotNull(repairManualDTO.getChapters());
        assertEquals(1, repairManualDTO.getChapters().size());
        assertEquals(Scope.DIRECT.getValue(), repairManualDTO.getChapters().get(0).getInfoLevel());

    }
}
