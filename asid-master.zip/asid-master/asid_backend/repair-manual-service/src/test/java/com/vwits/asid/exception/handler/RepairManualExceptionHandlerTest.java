package com.vwits.asid.exception.handler;

import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.exception.*;
import com.vwits.asid.utility.RepairManualUtility;
import com.vwits.asid.utility.entity.Scope;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.i18n.LocalizationHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RepairManualExceptionHandlerTest {

    @InjectMocks
    private RepairManualExceptionHandler repairManualExceptionHandler;

    @Mock
    private LocalizationHelper localizationHelper;

    private final String asid = "asid";
    private String language = "de-DE";

    @Test
    public void handleContentNotFoundException() {

        final String MESSAGE_NO_CONTENT_DE = "Die angefragte Teile/Fahrzeug Kombination liefert keinen Reparaturleitfaden";

        final String EXPECTED_RESPONSE_FOR_NO_CONTENT_DE = RepairManualUtility.getHtmlContentForException(MESSAGE_NO_CONTENT_DE, "Content Not Found");

        when(localizationHelper.getMessage("repair.manual.no.content", language)).thenReturn(MESSAGE_NO_CONTENT_DE);


        final ContentNotFoundException contentNotFoundException = new DataFromE2GoNotFoundException("NoContentFoundFromE2Go", asid, Scope.DIRECT, language);

        // when:
        final ResponseEntity<RepairManualDTO> responseEntity = repairManualExceptionHandler.handleContentNotFoundException(contentNotFoundException);

        // then:
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(asid, responseEntity.getBody().getHeader());
        assertEquals(EXPECTED_RESPONSE_FOR_NO_CONTENT_DE, GeneralUtility.decodeBase64ToString(responseEntity.getBody().getChapters().get(0).getContent()));
    }

    @Test
    public void handleLanguageNotFoundException() {

        language = "de-ab";

        final String MESSAGE_LANGUAGE_NOT_FOUND = "The requested language is not available, please try an other language.";
        final String EXPECTED_RESPONSE_FOR_LANGUAGE_NOT_FOUND = RepairManualUtility.getHtmlContentForException(MESSAGE_LANGUAGE_NOT_FOUND, "Language Not Found");

        when(localizationHelper.getMessage("repair.manual.language.not.found", language)).thenReturn(MESSAGE_LANGUAGE_NOT_FOUND);

        final LanguageNotFoundException languageNotFoundException = new LanguageNotFoundException("languageNotFound", asid, Scope.DIRECT, language);

        // when:
        final ResponseEntity<RepairManualDTO> responseEntity = repairManualExceptionHandler.handleLanguageNotFoundException(languageNotFoundException);

        // then:
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(asid, responseEntity.getBody().getHeader());
        assertEquals(EXPECTED_RESPONSE_FOR_LANGUAGE_NOT_FOUND, GeneralUtility.decodeBase64ToString(responseEntity.getBody().getChapters().get(0).getContent()));
    }

    @Test
    public void handleVinIsInvalidException() {

        final String MESSAGE_VIN_IS_INVALID = "Provided VIN is Invalid";
        final String EXPECTED_RESPONSE_FOR_VIN_IS_INVALID = RepairManualUtility.getHtmlContentForException(MESSAGE_VIN_IS_INVALID, "VIN is Invalid");

        when(localizationHelper.getMessage("repair.manual.vin.is.invalid", language)).thenReturn(MESSAGE_VIN_IS_INVALID);

        final VinInvalidException vinInvalidException = new VinInvalidException("Invalid VIN", asid, Scope.DIRECT, language);

        // when:
        final ResponseEntity<RepairManualDTO> responseEntity = repairManualExceptionHandler.handleVinInvalidException(vinInvalidException);

        // then:
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(asid, responseEntity.getBody().getHeader());
        assertEquals(EXPECTED_RESPONSE_FOR_VIN_IS_INVALID, GeneralUtility.decodeBase64ToString(responseEntity.getBody().getChapters().get(0).getContent()));
    }

    @Test
    public void handleTimeoutException() {

        final String MESSAGE_TIMEOUT_EXCEPTION = "The Repair Manual System is not responding. The support is informed. Please try again later.";
        final String EXPECTED_RESPONSE_FOR_TIMEOUT_EXCEPTION = RepairManualUtility.getHtmlContentForException(MESSAGE_TIMEOUT_EXCEPTION, "Request Timeout occurred");

        when(localizationHelper.getMessage("repair.manual.timeout", language)).thenReturn(MESSAGE_TIMEOUT_EXCEPTION);

        final RepairManualTimeoutException repairManualTimeoutException = new RepairManualTimeoutException("Request Timeout occurred", asid, Scope.DIRECT, language);

        // when:
        final ResponseEntity<RepairManualDTO> responseEntity = repairManualExceptionHandler.handleTimeoutException(repairManualTimeoutException);

        // then:
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(asid, responseEntity.getBody().getHeader());
        assertEquals(EXPECTED_RESPONSE_FOR_TIMEOUT_EXCEPTION, GeneralUtility.decodeBase64ToString(responseEntity.getBody().getChapters().get(0).getContent()));
    }

    @Test
    public void handleUnidentifiedException() {

        final String MESSAGE_UNIDENTIFIED_EXCEPTION = "Unknown error for this view. The service is informed about this issue.";
        final String EXPECTED_RESPONSE_FOR_UNIDENTIFIED_EXCEPTION = RepairManualUtility.getHtmlContentForException(MESSAGE_UNIDENTIFIED_EXCEPTION, "Unknown Error occurred");

        when(localizationHelper.getMessage("unidentified.exception", language)).thenReturn(MESSAGE_UNIDENTIFIED_EXCEPTION);

        final UnIdentifiedException unIdentifiedException = new UnIdentifiedException("Unknown Error occurred", asid, Scope.DIRECT, language);

        // when:
        final ResponseEntity<RepairManualDTO> responseEntity = repairManualExceptionHandler.handleUnIdentifiedException(unIdentifiedException);

        // then:
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(asid, responseEntity.getBody().getHeader());
        assertEquals(EXPECTED_RESPONSE_FOR_UNIDENTIFIED_EXCEPTION, GeneralUtility.decodeBase64ToString(responseEntity.getBody().getChapters().get(0).getContent()));
    }

    @Test
    public void handleBadRequestException() {
        // given:
        final Set<? extends ConstraintViolation<?>> constraintViolations = new HashSet<>();
        final ConstraintViolationException constraintViolationException = new ConstraintViolationException(constraintViolations);

        // when:
        final ResponseEntity responseEntity = repairManualExceptionHandler.handleConstraintViolationException(constraintViolationException);

        // then:
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void handleBadGatewayException() {
        // given:
        final HttpServerErrorException httpServerErrorException = new HttpServerErrorException(HttpStatus.BAD_GATEWAY);

        // when:
        final ResponseEntity responseEntity = repairManualExceptionHandler.handleHttpServerErrorException(httpServerErrorException);

        // then:
        assertEquals(HttpStatus.BAD_GATEWAY, responseEntity.getStatusCode());
    }

    @Test
    public void handleDealerUnauthorisedException() {

        final String MESSAGE_DEALER_UNAUTHORISED = "The Dealer Id is Unauthorised";
        final String EXPECTED_RESPONSE_FOR_UNAUTHORISED_DEALER = RepairManualUtility.getHtmlContentForException(MESSAGE_DEALER_UNAUTHORISED, "Unauthorised DealerId");

        when(localizationHelper.getMessage("unauthorized.dealer.message", language)).thenReturn(MESSAGE_DEALER_UNAUTHORISED);

        final DealerUnauthorisedException dealerUnauthorisedException = new DealerUnauthorisedException( asid, Scope.DIRECT, language);

        final ResponseEntity<RepairManualDTO> responseEntity = repairManualExceptionHandler.handleUnAuthorisedDealerIdException(dealerUnauthorisedException);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(asid, responseEntity.getBody().getHeader());
        assertEquals(EXPECTED_RESPONSE_FOR_UNAUTHORISED_DEALER, GeneralUtility.decodeBase64ToString(responseEntity.getBody().getChapters().get(0).getContent()));
    }

    @Test
    public void handleVinHandlingException() {

        final String MESSAGE_UNHANDLED_VIN = "The requested VIN could not be handled";
        final String EXPECTED_RESPONSE_FOR_UNHANDLED_VIN = RepairManualUtility.getHtmlContentForException(MESSAGE_UNHANDLED_VIN, "Unhandled Vin");

        when(localizationHelper.getMessage("unhandled.vin.message", language)).thenReturn(MESSAGE_UNHANDLED_VIN);

        final VinHandlingException vinHandlingException = new VinHandlingException( asid, Scope.DIRECT, language);

        final ResponseEntity<RepairManualDTO> responseEntity = repairManualExceptionHandler.handleVinHandlingException(vinHandlingException);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(asid, responseEntity.getBody().getHeader());
        assertEquals(EXPECTED_RESPONSE_FOR_UNHANDLED_VIN, GeneralUtility.decodeBase64ToString(responseEntity.getBody().getChapters().get(0).getContent()));
    }

}