package com.vwits.asid;

import com.vwits.asid.controller.RepairManualController;
import com.vwits.asid.entities.dto.Chapter;
import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.exception.RepairManualException;
import com.vwits.asid.service.RepairManualService;
import com.vwits.asid.utility.entity.Scope;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RepairManualControllerTest {

    private final String asid = "1234";
    private final String lang = "en";
    private final String country = "de";
    private final String brand = "V";
    private final String appName = "etka";
    private final String vin = "WVWZZZ3HZJE500162";

    private final String dealerId = "dealerId";
    //By default 1,  for direct mapping 1, for all mapping 0 and for indirect mapping 2.
    private final Scope scope = Scope.DIRECT;

    private RepairManualDTO repairManualDTO;

    @Mock
    private RepairManualService repairManualService;

    @InjectMocks
    private RepairManualController repairManualController;

    @Before
    public void setUp() {
        repairManualDTO = new RepairManualDTO();
    }

    @Test
    public void getRepairManualInfo_itShouldReturnRepairManualData() throws IOException, RepairManualException, ExecutionException, InterruptedException {
        // given:
        final String header = "Inspektion mit Ölwechsel durchführen";
        final Chapter repairManualInformationDAO0 = Chapter.builder().
                title("Title1").
                content("content1").
                contentType("svg").
                infoLevel(1).build();
        final Chapter repairManualInformationDAO1 = Chapter.builder().
                title("Title2").
                content("content2").
                contentType("png").
                infoLevel(2).build();

        repairManualDTO.setHeader(header);
        repairManualDTO.setCount(2);
        repairManualDTO.setChapters(Arrays.asList(repairManualInformationDAO0, repairManualInformationDAO1));

        final String dummy_token = "dummy_token";
        when(repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, scope, dummy_token)).thenReturn(repairManualDTO);

        // when:
        ResponseEntity repairManualInfo = repairManualController.getRepairManualInfo(asid, vin, lang, country, brand, dealerId, scope.getValue(), appName,dummy_token);

        // then:
        verify(repairManualService).getRepairManualContentFromElsa2Go(asid, vin, dealerId, lang, country, scope, dummy_token);

        assertEquals(HttpStatus.OK, repairManualInfo.getStatusCode());
        assertEquals(repairManualDTO, repairManualInfo.getBody());
    }
}
