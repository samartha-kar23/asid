package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;

public class VinInvalidException extends RepairManualException {
    public VinInvalidException(String message, String asid, Scope scope, String language) {
        super(message, asid, scope, language);
    }
}
