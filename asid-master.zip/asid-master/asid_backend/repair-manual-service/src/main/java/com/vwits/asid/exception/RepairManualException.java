package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;
import lombok.Getter;

@Getter
public class RepairManualException extends Exception {

    private final String asid;
    private final Scope scope;
    private final String language;

    public RepairManualException(String message, String asid, Scope scope, String language) {
        super(message);
        this.asid = asid;
        this.scope = scope;
        this.language = language;
    }

    public RepairManualException(String message) {
        super(message);
        this.asid = null;
        this.scope = null;
        this.language = null;
    }

    public RepairManualException(String message, Throwable cause, String asid, Scope scope, String language) {
        super(message, cause);
        this.asid = asid;
        this.scope = scope;
        this.language = language;
    }

    public RepairManualException(String asid, Scope scope, String language) {
        this.asid = asid;
        this.scope = scope;
        this.language = language;
    }
}
