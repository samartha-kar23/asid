package com.vwits.asid.utility.idkit;

import com.vwits.asid.utility.entity.Token;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;

@Component
public class IdKitTokenReader {

    private static final HttpHeaders HEADERS = new HttpHeaders();

    private static final MultiValueMap<String, String> REQUEST_PARAMETER_MAP = new LinkedMultiValueMap<>();

    @Autowired
    private Environment environment;
    @Autowired
    private RestTemplate restTemplate;
    private HttpEntity<MultiValueMap<String, String>> idKitTokenRequestEntity;

    public IdKitTokenReader(final Environment environment, final RestTemplate restTemplate) {
        this.environment = environment;
        this.restTemplate = restTemplate;
    }

    @PostConstruct
    public void initializeTokenRequest() {
        HEADERS.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        REQUEST_PARAMETER_MAP.add("client_secret", environment.getProperty("identitykit.client-secret"));
        REQUEST_PARAMETER_MAP.add("client_id", environment.getProperty("identitykit.client-id"));
        REQUEST_PARAMETER_MAP.add("grant_type", environment.getProperty("identitykit.grant-type"));

        idKitTokenRequestEntity = new HttpEntity<>(REQUEST_PARAMETER_MAP, HEADERS);
    }

    public String getToken() {
        final String idKitTokenEndpoint = environment.getProperty("identitykit.token-endpoint");
        final ResponseEntity<Token> response = restTemplate.postForEntity(idKitTokenEndpoint, idKitTokenRequestEntity, Token.class);
        return response.getBody().getAccessToken();
    }
}
