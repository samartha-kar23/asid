package com.vwits.asid.entities.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class RepairManualDTO {
    private String header;
    private int count;
    private List<Chapter> chapters;
}
