package com.vwits.asid.service;

import com.vwits.asid.entities.dto.Chapter;
import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.exception.DataFromE2GoNotFoundException;
import com.vwits.asid.exception.DealerUnauthorisedException;
import com.vwits.asid.exception.LanguageNotFoundException;
import com.vwits.asid.exception.MappingNotFoundException;
import com.vwits.asid.exception.RepairManualException;
import com.vwits.asid.exception.UnIdentifiedException;
import com.vwits.asid.exception.VinHandlingException;
import com.vwits.asid.exception.VinInvalidException;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.entity.Scope;
import com.vwits.asid.utility.environment.EnvironmentProvider;
import com.vwits.asid.utility.i18n.LocalizationHelper;
import com.vwits.asid.utility.idkit.IdKitTokenReader;
import com.vwits.asid.utility.mapping.ReverseMappingServiceProvider;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.vwits.asid.utility.GeneralUtility.convertStringToBase64;
import static com.vwits.asid.utility.constants.ASIDAppConstants.ALL_SUPPORTED_LANGUAGES_BY_E2GO;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Service
@Slf4j
public class RepairManualService {

    public static final String PRODUCTION_STAGE = "production";
    public static final String ERROR_RESPONSE_FOR_UNAUTHORISED_DEALER_ID = "ErrorRightsVIN";
    public static final String ERROR_RESPONSE_FOR_UN_HANDLED_VIN = "Cannot map transmissionCode";
    private static final String UN_AUTHORISED_DEALER_ID_TEXT = "Dealer is UnAuthorised";
    private static final String UN_HANDLED_VIN_TEXT = "Vin is Unhandled";
    private static final String X_NOT_FOUND_REASON_CONSTANT = "X-Not-Found-Reason";
    private boolean isIndirectMapping;

    private static String htmlTemplate;

    static {
        try {
            File file = ResourceUtils.getFile("classpath:repair-manual-response-template.html");
            byte[] allBytes = Files.readAllBytes(file.toPath());
            htmlTemplate = new String(allBytes);
        } catch (IOException e) {
            // Exception Ignored.
        }
    }

    @Value("${elsa2go.url}")
    private String elsa2GoUrl;
    @Autowired
    private ReverseMappingServiceProvider mappingServiceProvider;
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private IdKitTokenReader idKitTokenReader;
    @Autowired
    private LocalizationHelper localizationHelper;
    @Autowired
    private EnvironmentProvider envProvider;


    public void setElsa2GoUrl(String elsa2GoUrl) {
        this.elsa2GoUrl = elsa2GoUrl;
    }

    public RepairManualDTO getRepairManualContentFromElsa2Go(String asid, String vin, String dealerId, String language, String country, Scope scope, String token) throws RepairManualException {
        final String langCountry = getLanguage(language, country);
        if (langCountry == null) {
            throw new LanguageNotFoundException("Language not found for lang " + language + " and country " + country, asid, scope, langCountry);
        }
        final List<String> rlIdList = new ArrayList<>();
        final List<Chapter> chapterList = new ArrayList<>();

        try {
            rlIdList.addAll(mappingServiceProvider.getRlIds(asid, scope));
            if (scope == Scope.DIRECT && rlIdList.isEmpty()) {
                isIndirectMapping = true;
                rlIdList.addAll(mappingServiceProvider.getRlIds(asid, Scope.INDIRECT));
            }

        } catch (Exception e) {
            throw new UnIdentifiedException("Unknown error occurred", asid, scope, langCountry);
        }

        if (rlIdList.isEmpty()) {
            throw new MappingNotFoundException("No mapping found for asid " + asid, asid, scope, langCountry);
        }

        String html = "";

        Collections.sort(rlIdList);
        String localToken = updateToken(token);

        try {
            html = createChaptersForScope(vin, dealerId, langCountry, rlIdList, localToken);
        } catch (Exception repairManualException) {
            switch (repairManualException.getMessage()) {
                case "language":
                    throw new LanguageNotFoundException("Language not found for lang " + language + " and langCountry " + langCountry, asid, scope, langCountry);
                case "vin":
                    throw new VinInvalidException("Vin is invalid", asid, scope, langCountry);
                case UN_AUTHORISED_DEALER_ID_TEXT:
                    throw new DealerUnauthorisedException(asid, scope, language);
                case UN_HANDLED_VIN_TEXT:
                    throw new VinHandlingException(asid, scope, language);
                default:
                    throw new UnIdentifiedException("Unknown error occurred for asid " + asid, asid, scope, langCountry);

            }
        }

        if (html.isEmpty()) {
            throw new DataFromE2GoNotFoundException("No content received from e2go for asid " + asid, asid, scope, langCountry);
        }

        chapterList.add(getChapter(asid, html, scope.getValue()));

        return RepairManualDTO.builder()
                .header(asid)
                .count(rlIdList.size())
                .chapters(chapterList)
                .build();
    }

    private String getLanguage(String language, String country) {
        String langCountry = GeneralUtility.modifyLanguageToISO(language, country);
        if (!ALL_SUPPORTED_LANGUAGES_BY_E2GO.contains(langCountry)) {
            String lang = langCountry.split("-")[0];
            for (String supportedLang : ALL_SUPPORTED_LANGUAGES_BY_E2GO) {
                if (lang.equals("de")) {
                    return "de-DE";
                } else if (lang.equals("en")) {
                    return "en-GB";
                } else if (supportedLang.contains(lang)) {
                    return supportedLang;
                }
            }
            return null;
        }
        return langCountry;
    }

    private String createChaptersForScope(final String vin, final String dealerId, final String langCountry, final List<String> rlIdList, String localToken) throws RepairManualException {
        int titleCount = 0;
        final int firstHeader = 1;

        boolean isSingleChapterCreated = false;

        final Document finalDocument = Jsoup.parse(htmlTemplate);
        Document document = getRlContent(vin, dealerId, langCountry, rlIdList, localToken);

        if (document != null) {
            Elements titles = document.select("h3, h2");

            Elements tempTitles = new Elements();

            Element divElement = new Element("div");
            divElement.addClass("radio-toolbar");

            for (Element element : titles) {
                final String titleText = element.html();
                titleCount++;
                String contentId = "content_" + titleCount;

                Element inputElement = new Element("input");
                inputElement.attr("type", "radio");
                inputElement.attr("id", "menu_" + titleCount);
                inputElement.attr("name", "menu");
                inputElement.attr("onclick", "window.location.href = '#" + contentId + "';");

                Element labelElement = new Element("label");

                labelElement.attr("for", "menu_" + titleCount);

                String updatedText = removeInnerHtmlTags(titleText);
                labelElement.appendText(updatedText);

                Element hrElement = new Element("hr");
                hrElement.attr("class", "horizontal-line");

                labelElement.appendTo(inputElement);
                hrElement.appendTo(inputElement);

                if (titleCount == 1) {
                    inputElement.attr("checked");
                }
                divElement.append(inputElement.outerHtml());

                element.attr("id", contentId);
                if (titleCount != firstHeader) {
                    element.addClass("line-above-header");
                    tempTitles.addClass("line-below-menu-header ");
                }
                isSingleChapterCreated = true;
            }
            tempTitles.add(divElement);

            final String bodyInnerHtml = document.body().html();
            finalDocument.select("div#menu_heading_wrapper").first().append(tempTitles.outerHtml());
            finalDocument.select("div#rl-contents").first().append(bodyInnerHtml);
            createDynamicHeaderText(finalDocument, langCountry);

            if(isIndirectMapping) {
                createDynamicSubHeader(finalDocument, langCountry);
                isIndirectMapping = false;
            }
        }
        return isSingleChapterCreated ? finalDocument.outerHtml() : "";
    }


    private String removeInnerHtmlTags(String titleText) {
        if (titleText.contains("<span class=\"component\">")) {
            titleText = titleText.replaceAll("<span class=\"component\">", "");
            titleText = titleText.replaceAll("</span>", "");
        }
        if (titleText.contains("<q>")) {
            titleText = titleText.replaceAll("<q>", "\"");
            titleText = titleText.replaceAll("</q>", "\"");
        }
        if (titleText.contains("&nbsp;")) {
            titleText = titleText.replaceAll("&nbsp;", " ");
        }
        return titleText;
    }

    private String convertListToString(List<String> listOfRLId) {
        return listOfRLId.stream().
                map(Object::toString).
                collect(Collectors.joining(","));
    }

    private Chapter getChapter(final String asid, final String rlContent, final int scope) {
        return Chapter.builder().
                contentType("text/html")
                .title(asid)
                .content(convertStringToBase64(rlContent))
                .infoLevel(scope).build();
    }

    private Document getRlContent(final String vin, final String dealerId, String langCountry, List<String> rlIdList, String localToken) throws RepairManualException {
        Document document = null;

        final String rlIds = convertListToString(rlIdList);

        StringBuilder e2GoURL = new StringBuilder().append(elsa2GoUrl).append("/api/repair-manual/").append(langCountry).append("/").append(vin).append("/").append(rlIds);

        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("dealerContexts", dealerId);

        ResponseEntity<String> repairManualE2GoResponse = null;
        try {
            repairManualE2GoResponse = makeRestCallToE2Go(e2GoURL.toString(), queryParams, localToken);

            if (repairManualE2GoResponse.getStatusCode() == HttpStatus.OK) {

                document = deactivateLinkAndCreateDynamicHeaderFromElsa2GoResponse(repairManualE2GoResponse.getBody(), langCountry);

            }

        } catch (HttpClientErrorException e) {
            if (e.getStatusCode() == HttpStatus.TOO_MANY_REQUESTS) {
                return getRlContent(vin, dealerId, langCountry, rlIdList, localToken);
            }

            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {

                final HttpHeaders headers = e.getResponseHeaders();
                final String missingExtIDs = headers.getFirst("x-missing-ext-ids");
                if (missingExtIDs != null) {
                    rlIdList.removeAll(Arrays.asList(missingExtIDs.split(",")));
                    if (!rlIdList.isEmpty()) {
                        return getRlContent(vin, dealerId, langCountry, rlIdList, localToken);
                    }
                } else if (headers.getFirst(X_NOT_FOUND_REASON_CONSTANT) != null && !headers.getFirst(X_NOT_FOUND_REASON_CONSTANT).isEmpty()) {
                    throw new RepairManualException(headers.getFirst(X_NOT_FOUND_REASON_CONSTANT));
                } else {
                    throw new RepairManualException("");
                }
            }
            if (e.getStatusCode() == HttpStatus.FORBIDDEN && e.getResponseBodyAsString().contains(ERROR_RESPONSE_FOR_UNAUTHORISED_DEALER_ID)) {
                throw new DealerUnauthorisedException(UN_AUTHORISED_DEALER_ID_TEXT);
            }

        } catch (HttpServerErrorException e) {
            if (e.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR && e.getResponseBodyAsString().contains(ERROR_RESPONSE_FOR_UN_HANDLED_VIN)) {
                throw new VinHandlingException(UN_HANDLED_VIN_TEXT);
            }
        }
        return document;
    }

    private void createDynamicHeaderText(Document doc, String language) {

        final String tooltip = localizationHelper.getMessage("link.tooltip", language);
        final String secHeaderForLang = localizationHelper.getMessage("security.header", new Object[]{tooltip}, language);
        final Element securityHeader = doc.getElementsByClass("headerText").first();
        securityHeader.text(secHeaderForLang);
    }

    private void createDynamicSubHeader(Document doc, String language) {
        Element divElement =new Element("div");
        divElement.addClass("sub-header-bar");
        final String subHeading = localizationHelper.getMessage("indirect.mapping.text.when.direct.mapping.unavailable", language);
        Element spanElement = divElement.appendElement("span");
        spanElement.text(subHeading);

        Elements headerBarElement = doc.getElementsByClass("header-bar");
        headerBarElement.after(divElement.outerHtml());

    }

    private Document deactivateLinkAndCreateDynamicHeaderFromElsa2GoResponse(final String e2GoResponse, final String language) {
        final Document doc = Jsoup.parse(e2GoResponse);
        final Elements elements = doc.select("a[href]");
        elements.attr("onclick", "return false;");
        final String tooltip = localizationHelper.getMessage("link.tooltip", language);
        elements.attr("title", tooltip);
        return doc;
    }

    private ResponseEntity<String> makeRestCallToE2Go(String url, MultiValueMap<String, String> queryParams, String localToken) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParams(queryParams);
        URI uri = builder.build().toUri();
        logUrl(uri);
        HttpEntity<String> entity = new HttpEntity<>(createHeader(localToken));
        return restTemplate.exchange(uri, HttpMethod.GET, entity, String.class);
    }

    private void logUrl(URI uri) {
        String[] uriParts = uri.toString().split("/");
        final int vinIndex = 6;
        String vin = uriParts[vinIndex];
        if (vin.length() > 6) {
            uriParts[vinIndex] = vin.substring(0, vin.length() - 6).concat("XXXXXX");
        }
        log.info("E2Go URL :{} ", String.join("/", uriParts));
    }

    private HttpHeaders createHeader(String token) {
        HttpHeaders headers = new HttpHeaders();

        headers.set(AUTHORIZATION, token);
        return headers;
    }

    private String updateToken(String token) {
        if (envProvider.getStageName().equalsIgnoreCase(PRODUCTION_STAGE)) {
            return token;
        }
        return "Bearer ".concat(idKitTokenReader.getToken());
    }
}

