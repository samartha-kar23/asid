package com.vwits.asid.controller;


import com.newrelic.api.agent.NewRelic;
import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.exception.RepairManualException;
import com.vwits.asid.exception.RepairManualTimeoutException;
import com.vwits.asid.service.RepairManualService;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.entity.Scope;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.util.concurrent.*;

import static com.vwits.asid.utility.constants.ASIDAppConstants.REPAIR_INFO_PATH;
import static com.vwits.asid.utility.constants.ASIDAppConstants.REPAIR_MANUAL_TIMEOUT;

@RestController
@Validated
public class RepairManualController {

    @Autowired
    private RepairManualService repairManualService;

    private void setupNewRelicParams(String vin, String asid, String language, String country, String brand, String dealerId, int scope, String appName) {
        NewRelic.setTransactionName("Web", "repair_manual");
        NewRelic.addCustomParameter("dealerId", dealerId);
        NewRelic.addCustomParameter("scope", scope);
        NewRelic.addCustomParameter("asid", asid);
        NewRelic.addCustomParameter("language", language);
        NewRelic.addCustomParameter("country", country);
        NewRelic.addCustomParameter("brand", brand);
        NewRelic.addCustomParameter("salestype", GeneralUtility.extractSalesTypeFromVIN(vin));
        NewRelic.addCustomParameter("appname", appName);
    }

    @GetMapping(path = REPAIR_INFO_PATH)
    @ApiOperation(value = "This API is used to fetch Repair Manual information.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = String.class, responseContainer = "List")})
    public ResponseEntity getRepairManualInfo(@ApiParam(value = "After Sales Id, e.g. 915X8", example = "915X8") @RequestParam @NotBlank String asid,
                                              @ApiParam(value = "Vehicle Identification Number , e.g. WVWZZZ3HZJE123456", example = "WVWZZZ3HZJE123456") @RequestParam @NotBlank String vin,
                                              @ApiParam(value = "Language, e.g. de-DE", example = "de-DE") @RequestParam(name = "lang") @NotBlank String language,
                                              @ApiParam(value = "Country, e.g. de", example = "de") @RequestParam @NotBlank String country,
                                              @ApiParam(value = "Brand , e.g. V", example = "V") @RequestParam @NotBlank String brand,
                                              @ApiParam(value = "Dealer Id, e.g. ASIDTESTS", example = "ASIDTESTS") @RequestParam(name = "dealerid") String dealerId,
                                              @ApiParam(value = "Scope 0-Both direct & indirect Mapping 1- Direct mapping 2- Indirect mapping, e.g. 1", example = "1") @RequestParam(required = false, name = "scope", defaultValue = "1") @Min(value = 0) @Max(value = 2) int scopeValue,
                                              @ApiParam(value = "App Name, e.g. devs ", example = "devs") @RequestParam(name = "appname") @NotBlank String appName, @RequestHeader("Authorization") String token) throws RepairManualException, ExecutionException, InterruptedException {

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        setupNewRelicParams(vin, asid, language, country, brand, dealerId, scopeValue, appName);

        final Scope scope = Scope.getByValue(scopeValue);
        Callable<RepairManualDTO> callable = () -> repairManualService.getRepairManualContentFromElsa2Go(asid, vin, dealerId, language, country, scope, token);

        Future<RepairManualDTO> future = executorService.submit(callable);

        ResponseEntity<RepairManualDTO> result;
        try {
            result = ResponseEntity.ok(future.get(REPAIR_MANUAL_TIMEOUT, TimeUnit.SECONDS));
        } catch (TimeoutException e) {
            throw new RepairManualTimeoutException("Timeout occurred for asid " + asid, asid, scope, language);
        }
        return result;
    }
}
