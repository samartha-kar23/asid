package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;

public class DealerUnauthorisedException extends RepairManualException {

    public DealerUnauthorisedException(String asid, Scope scope, String language) {
        super(asid, scope, language);
    }

    public DealerUnauthorisedException(String message) {
        super(message);
    }
}
