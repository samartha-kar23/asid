package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;
import lombok.Getter;

@Getter
public class DataFromE2GoNotFoundException extends ContentNotFoundException {

    public DataFromE2GoNotFoundException(String message, String asid, Scope scope, String language) {
        super(message, asid, scope, language);
    }
}
