package com.vwits.asid.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vwits.asid.entities.dto.Chapter;
import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.RepairManualUtility;
import com.vwits.asid.utility.entity.Scope;
import com.vwits.asid.utility.i18n.LocalizationHelper;
import com.vwits.idkit.asid.utility.config.auth.DealerBlacklistService;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

import static com.vwits.asid.utility.constants.ASIDAppConstants.DEALER_ID_PARAMETER_NAME;

public class RepairManualDealerIdAuthFilter extends OncePerRequestFilter {
    private final DealerBlacklistService dealerBlacklistService;
    private final LocalizationHelper localizationHelper;

    public RepairManualDealerIdAuthFilter(DealerBlacklistService dealerBlacklistService, LocalizationHelper localizationHelper) {
        this.dealerBlacklistService = dealerBlacklistService;
        this.localizationHelper = localizationHelper;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        String dealerId = httpServletRequest.getParameter(DEALER_ID_PARAMETER_NAME);
        String asid = httpServletRequest.getParameter("asid");

        String scopeValue = httpServletRequest.getParameter("scope");
        Scope scope;
        if (scopeValue == null || scopeValue.isEmpty()) {
            scope = Scope.DIRECT;
        } else {
            scope = Scope.getByValue(Integer.parseInt(scopeValue));
        }
        String language = httpServletRequest.getParameter("lang");
        String infoMediaType = httpServletRequest.getRequestURI().length() > 1 ? httpServletRequest.getRequestURI().substring(1) : "";
        if (dealerId == null || dealerId.isEmpty() || (dealerBlacklistService.isDealerBlacklisted(dealerId, infoMediaType))) {

            RepairManualDTO response = createRepairManualResponse(asid, scope, language);

            byte[] responseToSend = restResponseBytes(response);
            httpServletResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
            httpServletResponse.getOutputStream().write(responseToSend);
        } else {
            filterChain.doFilter(httpServletRequest, httpServletResponse);
        }
    }

    private byte[] restResponseBytes(RepairManualDTO eErrorResponse) throws IOException {
        String serialized = new ObjectMapper().writeValueAsString(eErrorResponse);
        return serialized.getBytes();
    }

    private RepairManualDTO createRepairManualResponse(String asid, Scope scope, String language) {
        final String message = localizationHelper.getMessage("repair.manual.dealer.id.is.invalid", language);

        final String content = RepairManualUtility.getHtmlContentForException(message, "DEALER ID is Invalid");

        final Chapter chapter = Chapter.builder()
                .contentType("text/html")
                .content(GeneralUtility.convertStringToBase64(content))
                .title(asid)
                .infoLevel(scope.getValue())
                .build();

        return RepairManualDTO.builder()
                .count(0)
                .header(asid)
                .chapters(Arrays.asList(chapter))
                .build();
    }
}
