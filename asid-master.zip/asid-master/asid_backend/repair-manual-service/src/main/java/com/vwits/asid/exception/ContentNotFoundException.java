package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;
import lombok.Getter;

@Getter
public class ContentNotFoundException extends RepairManualException {
    public ContentNotFoundException(String message, String asid, Scope scope, String language) {
        super(message, asid, scope, language);
    }
}
