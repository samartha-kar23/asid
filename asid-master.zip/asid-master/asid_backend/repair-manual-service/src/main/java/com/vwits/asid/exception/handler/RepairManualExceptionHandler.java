package com.vwits.asid.exception.handler;

import com.vwits.asid.entities.dto.Chapter;
import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.exception.*;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.RepairManualUtility;
import com.vwits.asid.utility.i18n.LocalizationHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpServerErrorException;

import javax.validation.ConstraintViolationException;
import java.util.Arrays;

@Slf4j
@ControllerAdvice
public class RepairManualExceptionHandler {

    @Autowired
    private LocalizationHelper localizationHelper;

    @ExceptionHandler({ContentNotFoundException.class})
    public ResponseEntity<RepairManualDTO> handleContentNotFoundException(final ContentNotFoundException contentNotFoundException) {
        final String message = localizationHelper.getMessage("repair.manual.no.content", contentNotFoundException.getLanguage());
        final String content = RepairManualUtility.getHtmlContentForException(message, "Content Not Found");
        return ResponseEntity.ok().body(getRepairManualDTO(contentNotFoundException, content));
    }


    @ExceptionHandler({LanguageNotFoundException.class})
    public ResponseEntity<RepairManualDTO> handleLanguageNotFoundException(final LanguageNotFoundException languageNotFoundException) {
        final String message = localizationHelper.getMessage("repair.manual.language.not.found", languageNotFoundException.getLanguage());
        final String content = RepairManualUtility.getHtmlContentForException(message, "Language Not Found");
        return ResponseEntity.ok().body(getRepairManualDTO(languageNotFoundException, content));
    }

    @ExceptionHandler({VinInvalidException.class})
    public ResponseEntity<RepairManualDTO> handleVinInvalidException(final VinInvalidException vinInvalidException) {
        final String message = localizationHelper.getMessage("repair.manual.vin.is.invalid", vinInvalidException.getLanguage());
        final String content = RepairManualUtility.getHtmlContentForException(message, "VIN is Invalid");
        return ResponseEntity.ok().body(getRepairManualDTO(vinInvalidException, content));
    }

    @ExceptionHandler({RepairManualTimeoutException.class})
    public ResponseEntity<RepairManualDTO> handleTimeoutException(final RepairManualTimeoutException repairManualTimeoutException) {
        final String message = localizationHelper.getMessage("repair.manual.timeout", repairManualTimeoutException.getLanguage());
        final String content = RepairManualUtility.getHtmlContentForException(message, "Request Timeout occurred");
        return ResponseEntity.status(HttpStatus.OK).body(getRepairManualDTO(repairManualTimeoutException, content));
    }


    @ExceptionHandler({DealerUnauthorisedException.class})
    public ResponseEntity<RepairManualDTO> handleUnAuthorisedDealerIdException(final DealerUnauthorisedException dealerUnAuthorisedException ) {
        final String message = localizationHelper.getMessage("unauthorized.dealer.message", dealerUnAuthorisedException.getLanguage());
        final String content = RepairManualUtility.getHtmlContentForException(message, "Unauthorised DealerId");
        return ResponseEntity.ok().body(getRepairManualDTO(dealerUnAuthorisedException, content));
    }

    @ExceptionHandler({VinHandlingException.class})
    public ResponseEntity<RepairManualDTO> handleVinHandlingException(final VinHandlingException vinHandlingException ) {
        final String message = localizationHelper.getMessage("unhandled.vin.message", vinHandlingException.getLanguage());
        final String content = RepairManualUtility.getHtmlContentForException(message, "Unhandled Vin");
        return ResponseEntity.ok().body(getRepairManualDTO(vinHandlingException, content));
    }

    @ExceptionHandler({UnIdentifiedException.class})
    public ResponseEntity<RepairManualDTO> handleUnIdentifiedException(final UnIdentifiedException unidentifiedException ) {
        final String message = localizationHelper.getMessage("unidentified.exception", unidentifiedException.getLanguage());
        final String content = RepairManualUtility.getHtmlContentForException(message, "Unknown Error occurred");
        return ResponseEntity.ok().body(getRepairManualDTO(unidentifiedException, content));
    }

    private RepairManualDTO getRepairManualDTO(final RepairManualException repairManualException, final String content) {
        final Chapter chapter = Chapter.builder()
                .contentType("text/html")
                .content(GeneralUtility.convertStringToBase64(content))
                .title(repairManualException.getAsid())
                .infoLevel(repairManualException.getScope().getValue())
                .build();

        return RepairManualDTO.builder()
                .count(0)
                .header(repairManualException.getAsid())
                .chapters(Arrays.asList(chapter))
                .build();
    }

    // throws when javax.constraint violated in the repair manual controller
    @ExceptionHandler(value = {ConstraintViolationException.class})
    public ResponseEntity handleConstraintViolationException(ConstraintViolationException exception) {
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = {HttpServerErrorException.class})
    public ResponseEntity handleHttpServerErrorException(HttpServerErrorException exception) {
        return new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
    }

}
