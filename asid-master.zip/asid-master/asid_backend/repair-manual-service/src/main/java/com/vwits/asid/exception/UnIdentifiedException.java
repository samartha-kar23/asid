package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;

public class UnIdentifiedException extends RepairManualException {
    public UnIdentifiedException(String message, String asid, Scope scope, String language) {
        super(message, asid, scope, language);
    }
}
