package com.vwits.asid.filter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import vwg.digitallab.identitykit.clients.oauth2incoming.config.PlatformSecurityConfig;
import vwg.digitallab.identitykit.clients.oauth2incoming.config.PlatformSecurityConfigurer;

@Configuration
@ComponentScan("com.vwits.idkit.asid.utility.config.proxy")
@Import(DealerIdAuthenticationAdapter.class)
public class RepairManualSecurityConfig {

    @Value("${identitykit.whitelisted-client:none}")
    private String[] whitelistedClient;

    @Bean
    @Primary
    public PlatformSecurityConfig platformSecurityConfig() {
        PlatformSecurityConfigurer platformSecurityConfigurer = PlatformSecurityConfigurer
                .newBuilder()
                .enableOAuth2()
                .enableCsrf()
                .disableExternalAuthorization();
        for (String client : whitelistedClient) {
            platformSecurityConfigurer.addWhitelistedClient(client);
        }
        return platformSecurityConfigurer.build();
    }
}
