package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;

public class LanguageNotFoundException extends RepairManualException {
    public LanguageNotFoundException(String message, String asid, Scope scope, String language) {
        super(message, asid, scope, language);
    }
}
