package com.vwits.asid.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.SecurityConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


import java.util.Arrays;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.Collections.singletonList;
import static springfox.documentation.builders.PathSelectors.any;

@Configuration
@EnableSwagger2
@Profile("Swagger")
public class RepairManualSwaggerConfiguration extends WebMvcConfigurationSupport {

    @Bean
    public Docket api() {
        String swaggerToken = "token";
        return new Docket(DocumentationType.SWAGGER_2)
                .globalOperationParameters(singletonList(
                        new ParameterBuilder()
                                .name("Authorization")
                                .modelRef(new ModelRef("String"))
                                .parameterType("header")
                                .required(true)
                                .hidden(true)
                                .defaultValue("Bearer " + swaggerToken).build()))
                .groupName("Swagger Specification for Repair Manual Service")
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.vwits.asid.controller"))
                .paths(any())
                .build()
                .useDefaultResponseMessages(false)
                .globalResponseMessage(RequestMethod.GET, newArrayList(new ResponseMessageBuilder()
                                .code(204)
                                .message("No Content")
                                .build(), new ResponseMessageBuilder()
                                .code(401)
                                .message("UnAuthorised Access").build(),
                        new ResponseMessageBuilder()
                                .code(400)
                                .message("Bad Request").build()))
                .apiInfo(apiInfo())
                .securitySchemes(Arrays.asList(securityScheme()));
    }


    @Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("Repair Manual Service").
                description("Repair Manual Service gets data from E2GO and provide the information for various Repair Manuals").version("1.0.1").build();
    }
    @Bean
    public SecurityConfiguration security() {
        return SecurityConfigurationBuilder.builder()
                .clientId("")
                .clientSecret("")
                .scopeSeparator(" ")
                .useBasicAuthenticationWithAccessCodeGrant(false)
                .build();
    }

    private OAuth securityScheme() {
        List<GrantType> grantTypes = newArrayList();
        GrantType passwordCredentialsGrant = new ResourceOwnerPasswordCredentialsGrant("https://identity-sandbox.vwgroup.io/oidc/v1/token");
        grantTypes.add(passwordCredentialsGrant);
        return new OAuth("oauth2", Arrays.asList(scopes()), grantTypes);
    }

    private AuthorizationScope[] scopes() {
        AuthorizationScope[] scopes = {
                new AuthorizationScope("read", "for read operations"),
                new AuthorizationScope("write", "for write operations")};
        return scopes;
    }


}

