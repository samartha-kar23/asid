package com.vwits.asid.filter;

import com.vwits.asid.utility.i18n.LocalizationHelper;
import com.vwits.idkit.asid.utility.config.auth.DealerBlacklistService;
import com.vwits.idkit.asid.utility.config.newrelic.NewRelicRequestFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.client.RestTemplate;
import vwg.digitallab.identitykit.clients.oauth2incoming.oauth2.OAuth2AccessTokenFilter;
import vwg.digitallab.identitykit.clients.oauth2incoming.oauth2.RequestParser;

@Configuration
@ComponentScan("vwg.digitallab.identitykit.clients.oauth2incoming")
@Order(Ordered.HIGHEST_PRECEDENCE)
@Profile("!local")
public class DealerIdAuthenticationAdapter extends WebSecurityConfigurerAdapter {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AuthenticationProvider oauth2AuthProvider;

    @Autowired
    private RequestParser requestParser;

    @Autowired
    private LocalizationHelper localizationHelper;

    @Value("${internal.auth.service.url}")
    private String dealerIdBlacklistingServiceUrl;


    private static final String[] AUTH_WHITELIST = {
            "/swagger-resources/**",
            "/swagger-ui.html",
            "/v2/api-docs",
            "/webjars/**"
    };

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        final OAuth2AccessTokenFilter oAuth2Filter = new OAuth2AccessTokenFilter(oauth2AuthProvider, requestParser);
        http
                .addFilterBefore(oAuth2Filter, BasicAuthenticationFilter.class)
                .addFilterBefore(new NewRelicRequestFilter(), oAuth2Filter.getClass())
                .addFilterAfter(new RepairManualDealerIdAuthFilter(new DealerBlacklistService(
                        dealerIdBlacklistingServiceUrl, restTemplate),localizationHelper), BasicAuthenticationFilter.class)
                .exceptionHandling()
                .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)).and()
                .authorizeRequests().anyRequest().authenticated();
    }



    @Override
    public void configure(WebSecurity web) {
        web.ignoring()
                .antMatchers(AUTH_WHITELIST);
    }
}
