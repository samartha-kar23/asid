package com.vwits.asid.exception;

import com.vwits.asid.utility.entity.Scope;

public class VinHandlingException extends RepairManualException {

    public VinHandlingException(String message) {
        super(message);
    }

    public VinHandlingException(String asid, Scope scope, String language) {
        super(asid, scope, language);
    }
}
