package com.vwits.asid.utility;

public class RepairManualUtility {

    private RepairManualUtility() {
    }

    public static String getHtmlContentForException(String message, String title){
        return "<!DOCTYPE html> <html lang=\"en\"><head><title>".concat(title).concat("</title></head><body><div align=\"center\"><h3>").concat(message).concat("</h3></div></body></html>");

    }
}
