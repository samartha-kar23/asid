package com.vwits.asid.integTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.junit.WireMockClassRule;
import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.utility.GeneralUtility;
import com.vwits.asid.utility.RepairManualUtility;
import com.vwits.asid.utility.environment.TestEnvironmentProvider;
import com.vwits.asid.utility.testutils.SpringTestWithMockIDKit;
import com.vwits.asid.utility.testutils.entity.Token;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static com.vwits.asid.service.RepairManualService.ERROR_RESPONSE_FOR_UNAUTHORISED_DEALER_ID;
import static com.vwits.asid.service.RepairManualService.ERROR_RESPONSE_FOR_UN_HANDLED_VIN;
import static com.vwits.asid.service.RepairManualService.PRODUCTION_STAGE;
import static com.vwits.asid.utility.constants.ASIDAppConstants.REPAIR_INFO_PATH;
import static com.vwits.asid.utility.environment.TestEnvironmentProvider.NON_PRODUCTION_STAGE;
import static com.vwits.asid.utility.testutils.IntegTestHelper.getMockTokenForIdKit;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@SpringTestWithMockIDKit
@ActiveProfiles({"test","NoAuth"})
@AutoConfigureMockMvc
public class RepairManualControllerIntegrationTest {

    @ClassRule
    public static WireMockClassRule mappingServiceMockRule = new WireMockClassRule(8447);
    @ClassRule
    public static WireMockClassRule idKitMockRule = new WireMockClassRule(8448);
    @ClassRule
    public static WireMockClassRule e2GoMockRule = new WireMockClassRule(8449);
    @ClassRule
    public static WireMockClassRule dealerBlacklistMockRule = new WireMockClassRule(8450);

    private final MultiValueMap<String, String> requestParams = new LinkedMultiValueMap<>();

    private final ObjectMapper mapper = new ObjectMapper();
    private final String rlIdWithData = "eng.10.1.1";
    private final String rlIdReturning5xx = "eng.10.1.4";
    private final String rlIdWithoutData = "eng.10.1.2";
    private final String rlIdWithInvalidDealerId = "rlIdWithInvalidDealerId";
    private final String blankRlId = "";

    private final String asid = "100X1001";
    private final String asidWithInvalidDealerId = "asidWithInvalidDealerId";
    private final String unHandledVIN = "unHandledVIN";
    private final String asidReturning5xx = "100X1003";
    private final String asidWithMultipleExtIds = "100X1002";
    private final String asidWithMultipleExtIdsReturning5xx = "100X1004";
    private final String authorizedDealerId = "DEU05025V";
    private final String asidWithoutMapping = "asidWithoutMapping";
    private final String asidWithoutRLdata = "asidWithoutRLData";
    private String asidTimeout = "asidForTimeout";
    private String asidUnknownError = "asidUnknownError";

    @Rule
    public WireMockClassRule mappingServiceMock = mappingServiceMockRule;
    @Rule
    public WireMockClassRule idKitMock = idKitMockRule;
    @Rule
    public WireMockClassRule e2GoMock = e2GoMockRule;
    @Rule
    public WireMockClassRule dealerBlackListFilterMock = dealerBlacklistMockRule;

    @Autowired
    private MockMvc mvc;

    @Autowired
    private TestEnvironmentProvider testEnvironmentProvider;
    private String token;
    private String blacklistedDealerId = "blacklistedDealerId";
    private String imageURLEmbedded;
    private String unauthorizedDealerId = "unauthorizedDealerId";

    @Before
    public void init() throws JsonProcessingException {
        token = getMockTokenForIdKit();
        testEnvironmentProvider.setEnvironment(PRODUCTION_STAGE);
        requestParams.add("asid", asid);
        requestParams.add("lang", "en");
        requestParams.add("country", "GB");
        requestParams.add("mkb", "K12");
        requestParams.add("gkb", "75K");
        requestParams.add("modelyear", "2010");
        requestParams.add("prnumber", "K097A1MLBLKJ");
        requestParams.add("brand", "SUPERB");
        requestParams.add("vt", "abc123");
        requestParams.add("extid", "esy.27.1.1");
        requestParams.add("appname", "devs");
        requestParams.add("vin", "vin");
        requestParams.add("dealerid", authorizedDealerId);
        requestParams.add("scope", "1");

        imageURLEmbedded = "http://localhost:8451/s3";

        stubAllWireMock();
    }


    @Test
    public void getRepairManualInfo_ShouldProvideNoContent_WhenMappingDataIsNotPresent() throws Exception {
        final String MESSAGE_NO_CONTENT_EN = "The given part/vehicle combination did not return any repair manuals.";
        final String EXPECTED_RESPONSE_FOR_NO_CONTENT_EN = RepairManualUtility.getHtmlContentForException(MESSAGE_NO_CONTENT_EN, "Content Not Found");
        requestParams.set("asid", asidWithoutMapping);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(OK.value())).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);

        assertEquals(asidWithoutMapping, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_NO_CONTENT_EN, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void getRepairManualInfo_ShouldProvideNoContent_WithMessageInDE_WhenRepairManualDataIsNotPresent() throws Exception {
        requestParams.set("asid", asidWithoutRLdata);
        requestParams.set("lang", "de-DE");

        final String MESSAGE_NO_CONTENT_DE = "Die angefragte Teile/Fahrzeug Kombination liefert keinen Reparaturleitfaden";
        final String EXPECTED_RESPONSE_FOR_NO_CONTENT_DE = RepairManualUtility.getHtmlContentForException(MESSAGE_NO_CONTENT_DE, "Content Not Found");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(OK.value())).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);

        assertEquals(asidWithoutRLdata, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());

        assertEquals(EXPECTED_RESPONSE_FOR_NO_CONTENT_DE, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void getRepairManualInfo_ShouldReturn200StatusCode_WhenNotSupportedLangIsProvided() throws Exception {
        final String MESSAGE_LANGUAGE_NOT_FOUND = "The requested language is not available, please try another language.";
        final String EXPECTED_RESPONSE_FOR_LANGUAGE_NOT_FOUND = RepairManualUtility.getHtmlContentForException(MESSAGE_LANGUAGE_NOT_FOUND, "Language Not Found");
        requestParams.set("asid", asidWithoutRLdata);
        requestParams.set("lang", "ab-AB");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(OK.value())).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);

        assertEquals(asidWithoutRLdata, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_LANGUAGE_NOT_FOUND, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void getRepairManualInfo_ShouldReturn200StatusCodeWithAppropriateMessage_WhenInvalidVINIsProvided() throws Exception {
        final String MESSAGE_VIN_IS_INVALID = "Provided VIN is Invalid";
        final String EXPECTED_RESPONSE_FOR_VIN_IS_INVALID = RepairManualUtility.getHtmlContentForException(MESSAGE_VIN_IS_INVALID, "VIN is Invalid");
        requestParams.set("asid", asidWithoutRLdata);
        requestParams.set("vin", "invalidVIN");


        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(OK.value())).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);

        assertEquals(asidWithoutRLdata, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_VIN_IS_INVALID, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void getRepairManualInfo_ShouldReturn200StatusCodeWithAppropriateMessage_WhenProcessingTimeIsMoreThan8Seconds() throws Exception {
        final String MESSAGE_TIMEOUT_EXCEPTION = "The Repair Manual System is not responding. The support is informed. Please try again later.";
        final String EXPECTED_RESPONSE_FOR_TIMEOUT_EXCEPTION = RepairManualUtility.getHtmlContentForException(MESSAGE_TIMEOUT_EXCEPTION, "Request Timeout occurred");
        requestParams.set("asid", asidTimeout);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();

        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.OK.value())).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);

        assertEquals(asidTimeout, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_TIMEOUT_EXCEPTION, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void getRepairManualInfo_ShouldReturn200StatusCodeWithAppropriateMessage_WhenUnidentifiedExceptionIsThrown() throws Exception {
        final String MESSAGE_UNIDENTIFIED_EXCEPTION = "Unknown error for this view. The service is informed about this issue.";
        final String EXPECTED_RESPONSE_FOR_UNKNOWN_ERROR = RepairManualUtility.getHtmlContentForException(MESSAGE_UNIDENTIFIED_EXCEPTION, "Unknown Error occurred");
        requestParams.set("asid", asidUnknownError);


        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(OK.value())).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);

        assertEquals(asidUnknownError, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_UNKNOWN_ERROR, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void shouldProvideValidContent_WhenE2GoProvidesData() throws Exception {

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();

        final String urlTemplate = uriComponents.toUriString();

        final MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.TEXT_HTML_VALUE))
                .andExpect(status().isOk()).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);
        final String expectedTooltip = "Currently links are not supported.";

        assertEquals(asid, repairManualDTOResponse.getHeader());
        assertEquals(1, repairManualDTOResponse.getCount());
        assertEquals(1, repairManualDTOResponse.getChapters().get(0).getInfoLevel());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(1, repairManualDTOResponse.getChapters().size());
        assertNotNull(repairManualDTOResponse.getChapters().get(0));
        repairManualDTOResponse.getChapters().forEach(chapter -> {
            final String decodedChapterContent = new String(Base64.getDecoder().decode(chapter.getContent()));
            assertTrue(decodedChapterContent.contains("onclick=\"return false;\""));
            assertTrue(decodedChapterContent.contains("title=\"" + expectedTooltip));

            //Asserting HTML Menu Tags
            assertTrue(decodedChapterContent.contains("<div class=\"radio-toolbar\">"));
            assertTrue(decodedChapterContent.contains("<input type=\"radio\" id=\"menu_1\" name=\"menu\" onclick=\"window.location.href = '#content_1';\">"));
            assertTrue(decodedChapterContent.contains("<label for=\"menu_1\">"));
            assertTrue(decodedChapterContent.contains("<hr class=\"horizontal-line\">"));
            //Validating inner tags inside menu label
            assertTrue(decodedChapterContent.contains("Menu Heading without span \" and without qoutes\" "));
        });

    }

    @Test
    public void shouldProvideValidContent_WhenUnsupportedCountryProvided() throws Exception {
        requestParams.set("lang","en");
        requestParams.set("country","XX");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();

        final String urlTemplate = uriComponents.toUriString();

        final MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.TEXT_HTML_VALUE))
                .andExpect(status().isOk()).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);
        final String expectedTooltip = "Currently links are not supported.";

        assertEquals(asid, repairManualDTOResponse.getHeader());
        assertEquals(1, repairManualDTOResponse.getCount());
        assertEquals(1, repairManualDTOResponse.getChapters().get(0).getInfoLevel());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(1, repairManualDTOResponse.getChapters().size());
        assertNotNull(repairManualDTOResponse.getChapters().get(0));
        repairManualDTOResponse.getChapters().forEach(chapter -> {
            final String decodedChapterContent = new String(Base64.getDecoder().decode(chapter.getContent()));
            assertTrue(decodedChapterContent.contains("onclick=\"return false;\""));
            assertTrue(decodedChapterContent.contains("title=\"" + expectedTooltip));

            //Asserting HTML Menu Tags
            assertTrue(decodedChapterContent.contains("<div class=\"radio-toolbar\">"));
            assertTrue(decodedChapterContent.contains("<input type=\"radio\" id=\"menu_1\" name=\"menu\" onclick=\"window.location.href = '#content_1';\">"));
            assertTrue(decodedChapterContent.contains("<label for=\"menu_1\">"));
            assertTrue(decodedChapterContent.contains("<hr class=\"horizontal-line\">"));
            //Validating inner tags inside menu label
            assertTrue(decodedChapterContent.contains("Menu Heading without span \" and without qoutes\" "));
        });

    }

    @Test
    public void shouldProvideValidContent_WhenE2GoProvidesData_Dev() throws Exception {

        //Multiple environment Testing
        //for (String env:Arrays.asList(NON_PRODUCTION_STAGE,PRODUCTION_STAGE)) {
        testEnvironmentProvider.setEnvironment(NON_PRODUCTION_STAGE);

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();

        final String urlTemplate = uriComponents.toUriString();

        final MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.TEXT_HTML_VALUE))
                .andExpect(status().isOk()).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);
        final String expectedTooltip = "Currently links are not supported.";

        assertEquals(asid, repairManualDTOResponse.getHeader());
        assertEquals(1, repairManualDTOResponse.getCount());
        assertEquals(1, repairManualDTOResponse.getChapters().get(0).getInfoLevel());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(1, repairManualDTOResponse.getChapters().size());
        assertNotNull(repairManualDTOResponse.getChapters().get(0));
        repairManualDTOResponse.getChapters().forEach(chapter -> {
            final String decodedChapterContent = new String(Base64.getDecoder().decode(chapter.getContent()));
            assertTrue(decodedChapterContent.contains("onclick=\"return false;\""));
            assertTrue(decodedChapterContent.contains("title=\"" + expectedTooltip));

            //Asserting HTML Menu Tags
            assertTrue(decodedChapterContent.contains("<div class=\"radio-toolbar\">"));
            assertTrue(decodedChapterContent.contains("<input type=\"radio\" id=\"menu_1\" name=\"menu\" onclick=\"window.location.href = '#content_1';\">"));
            assertTrue(decodedChapterContent.contains("<label for=\"menu_1\">"));
            assertTrue(decodedChapterContent.contains("<hr class=\"horizontal-line\">"));
            //Validating inner tags inside menu label
            assertTrue(decodedChapterContent.contains("Menu Heading without span \" and without qoutes\" "));
        });
        // }

    }

    @Test
    public void shouldReturnBadGatewayResponse_whenE2GoReturn5XXResponse() throws Exception {
        requestParams.set("country", "en");
        requestParams.set("asid", asidReturning5xx);
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();

        final String urlTemplate = uriComponents.toUriString();

        mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.TEXT_HTML_VALUE))
                .andExpect(status().is(HttpStatus.OK.value()));
    }

    @Test
    public void itShouldReturnForbidden403_whenDealerIdIsBlacklisted() throws Exception {
        final String MESSAGE_DEALER_ID_INVALID_EN = "Ihre Händler-Nummer ist zur Anzeige nicht berechtigt.";
        final String EXPECTED_RESPONSE_FOR_DEALER_ID_INVALID_EN = RepairManualUtility.getHtmlContentForException(MESSAGE_DEALER_ID_INVALID_EN, "DEALER ID is Invalid");
        requestParams.set("dealerid", blacklistedDealerId);
        requestParams.set("lang", "de-DE");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden()).andReturn();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(mvcResult.getResponse().getContentAsString(), RepairManualDTO.class);

        assertEquals(asid, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_DEALER_ID_INVALID_EN, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void itShouldReturn400BadRequest_whenMandatoryParameterIsEmpty() throws Exception {

        // when appname is blank
        requestParams.set("appname", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when lang is blank
        requestParams.set("appname", "devs");
        requestParams.set("lang", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when country is blank
        requestParams.set("lang", "de");
        requestParams.set("country", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when VIN is blank
        requestParams.set("country", "DE");
        requestParams.set("vin", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());

        // when asid is blank
        requestParams.set("vin", "vin");
        requestParams.set("asid", "");
        mvc.perform(get(getRequestParams(requestParams))
                .header(AUTHORIZATION, "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void getRepairManualInfo_ShouldReturn200StatusCode_WhenUnAuthorisedDealerIdIsProvided() throws Exception {

        requestParams.set("dealerid", unauthorizedDealerId);
        requestParams.set("asid", asidWithInvalidDealerId);
        final String MESSAGE_DEALER_UNAUTHORISED = "Your dealer number is not qualified.";
        final String EXPECTED_RESPONSE_FOR_UNAUTHORISED_DEALER = RepairManualUtility.getHtmlContentForException(MESSAGE_DEALER_UNAUTHORISED, "Unauthorised DealerId");

        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(OK.value())).andReturn();
        MockHttpServletResponse response = mvcResult.getResponse();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(response.getContentAsString(), RepairManualDTO.class);

        assertEquals(OK.value(), response.getStatus());
        assertEquals(asidWithInvalidDealerId, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_UNAUTHORISED_DEALER, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    @Test
    public void getRepairManualInfo_ShouldReturn200StatusCode_WhenUnhandledVinIsProvided() throws Exception {

        requestParams.set("vin", unHandledVIN);
        final String MESSAGE_UNHANDLED_VIN = "The requested VIN could not be handled.";
        final String EXPECTED_RESPONSE_FOR_UNHANDLED_VIN = RepairManualUtility.getHtmlContentForException(MESSAGE_UNHANDLED_VIN, "Unhandled Vin");


        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(requestParams).build();


        String urlTemplate = uriComponents.toUriString();
        MvcResult mvcResult = mvc.perform(get(urlTemplate)
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(OK.value())).andReturn();
        MockHttpServletResponse response = mvcResult.getResponse();

        final RepairManualDTO repairManualDTOResponse = mapper.readValue(response.getContentAsString(), RepairManualDTO.class);

        assertEquals(OK.value(), response.getStatus());
        assertEquals(asid, repairManualDTOResponse.getHeader());
        assertEquals(0, repairManualDTOResponse.getCount());
        assertNotNull(repairManualDTOResponse.getChapters());
        assertEquals(EXPECTED_RESPONSE_FOR_UNHANDLED_VIN, GeneralUtility.decodeBase64ToString(repairManualDTOResponse.getChapters().get(0).getContent()));
    }

    private String getRequestParams(MultiValueMap<String, String> params) {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(params).build();
        return uriComponents.toUriString();
    }

    private String getRlContent(String rlId) {
        final String dummyHTMLContent = "<html>" +
                "  <head>" +
                "    <meta charset=\"utf-8\">" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" +
                "  <link rel=\"stylesheet\" type=\"text/css\" href=\"assets/style.css\">" +
                "  </head>" +
                "  <body>" +
                "  <h3>Menu Heading <span class=\"component\"> without&nbsp;span <q> and without qoutes</q> </span> </h3>" +
                "<a href=\"sample\">sample_link</a>" +
                "<img class=\"picture\" src=\"" + imageURLEmbedded + "\"" +
                "    <p>RL for " + rlId + "</p>" +
                "  </body>" +
                "</html>";
        return dummyHTMLContent;
    }

    private void stubAllWireMock() throws JsonProcessingException {
        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asid))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(OK.value())
                                .withBody(mapper.writeValueAsString(Collections.singletonList(rlIdWithData)))
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidTimeout))
                        .willReturn(aResponse()
                                .withFixedDelay(10000)
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(OK.value())
                                .withBody(mapper.writeValueAsString(Collections.singletonList(rlIdWithData)))
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidReturning5xx))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidWithMultipleExtIds))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(OK.value())
                                .withBody(mapper.writeValueAsString(Arrays.asList(rlIdWithData, rlIdWithoutData)))
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidUnknownError))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(OK.value())
                                .withBody(mapper.writeValueAsString(Arrays.asList(blankRlId)))
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidWithMultipleExtIdsReturning5xx))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(OK.value())
                                .withBody(mapper.writeValueAsString(Arrays.asList(rlIdWithData, rlIdReturning5xx)))
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidWithoutRLdata))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(OK.value())
                                .withBody(mapper.writeValueAsString(Arrays.asList(rlIdWithoutData)))
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidWithInvalidDealerId))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(OK.value())
                                .withBody(mapper.writeValueAsString(Arrays.asList(rlIdWithInvalidDealerId)))
                        )
        );

        mappingServiceMock.stubFor(
                WireMock.get(urlPathMatching("/rlid"))
                        .withQueryParam("asid", equalTo(asidWithoutMapping))
                        .willReturn(aResponse()
                                .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                .withStatus(HttpStatus.NO_CONTENT.value())
                        )
        );


        idKitMock.stubFor(WireMock.post(anyUrl())
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withBody(new ObjectMapper().writeValueAsString(new Token().withAccessToken(token))
                        )));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-GB/" +unHandledVIN+ "/" + rlIdWithData))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .withBody(ERROR_RESPONSE_FOR_UN_HANDLED_VIN)
                ));


        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-GB/vin/" + rlIdWithData))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withStatus(OK.value())
                        .withBody(getRlContent(rlIdWithData))
                ));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-de/vin/" + rlIdReturning5xx))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())
                ));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-de/vin/" + rlIdWithoutData))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withHeader("x-missing-ext-ids", rlIdWithoutData)
                        .withStatus(HttpStatus.NOT_FOUND.value())
                ));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-de/vin/" + blankRlId))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withStatus(HttpStatus.NOT_FOUND.value())
                ));

        // for DE language no content message
        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/de-DE/vin/" + rlIdWithoutData))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withHeader("x-missing-ext-ids", rlIdWithoutData)
                        .withStatus(HttpStatus.NOT_FOUND.value())
                ));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/ab-AB/vin/" + rlIdWithoutData))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withHeader("X-Not-Found-Reason", "language")
                        .withStatus(HttpStatus.NOT_FOUND.value())
                ));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-GB/invalidVIN/" + rlIdWithoutData))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withHeader("X-Not-Found-Reason", "vin")
                        .withStatus(HttpStatus.NOT_FOUND.value())
                ));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-en/vin/" + rlIdWithData))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(authorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())

                ));

        e2GoMock.stubFor(WireMock.get(urlPathMatching("/api/repair-manual/en-GB/vin/" + rlIdWithInvalidDealerId))
                .withHeader(AUTHORIZATION, matching("Bearer " + token))
                .withQueryParam("dealerContexts", equalTo(unauthorizedDealerId))
                .willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.TEXT_HTML_VALUE)
                        .withStatus(HttpStatus.FORBIDDEN.value())
                        .withBody(ERROR_RESPONSE_FOR_UNAUTHORISED_DEALER_ID)
                ));


        dealerBlackListFilterMock.stubFor(WireMock.get(anyUrl())
                .withQueryParam("dealerid", equalTo(authorizedDealerId))
                .withQueryParam("infomediatype", equalTo("rlinfo")).willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(OK.value())
                        .withBody(FALSE.toString())));

        dealerBlackListFilterMock.stubFor(WireMock.get(anyUrl())
                .withQueryParam("dealerid", equalTo(blacklistedDealerId))
                .withQueryParam("infomediatype", equalTo("rlinfo")).willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(OK.value())
                        .withBody(TRUE.toString())));

        dealerBlackListFilterMock.stubFor(WireMock.get(anyUrl())
                .withQueryParam("dealerid", equalTo(unauthorizedDealerId))
                .withQueryParam("infomediatype", equalTo("rlinfo")).willReturn(aResponse()
                        .withHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .withStatus(OK.value())
                        .withBody(FALSE.toString())));
    }
}
