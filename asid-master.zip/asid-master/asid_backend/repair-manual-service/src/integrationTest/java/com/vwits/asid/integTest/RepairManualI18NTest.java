package com.vwits.asid.integTest;

import com.vwits.asid.utility.i18n.LocalizationHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

@SpringBootTest
@ActiveProfiles({"test","NoAuth"})
@RunWith(SpringRunner.class)
public class RepairManualI18NTest {

    @Autowired
    private LocalizationHelper localizationHelper;

    @Test
    public void test_RepairManualMessage() {
        // given:
        final String language = "de-DE";
        final String messageKey = "test.message";
        final String expectedMessage = "Hallo!! wie gehts?";

        // when:
        String actualMessage = localizationHelper.getMessage(messageKey,language);

        // then:
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void test_RepairManualMessage_WithPlaceholder() {
        // given:
        final String language = "de";
        final String messageKey = "welcome.info";
        final String expectedMessage = "Hallo xyz, Sie sind herzlich eingeladen, ASID. Dies ist eine englische Website.";

        // when:
        String actualMessage = localizationHelper.getMessage(messageKey, new Object[]{"xyz", "ASID"}, language);

        // then:
        assertEquals(expectedMessage, actualMessage);
    }
}
