package com.vwits.asid;

import com.vwits.asid.entities.dto.RepairManualDTO;
import com.vwits.asid.utility.environment.EnvironmentProvider;
import com.vwits.asid.utility.testutils.SubjectUrlProvider;
import com.vwits.asid.utility.testutils.entity.IdKitClientCredential;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import static com.vwits.asid.utility.GeneralUtility.getHttpEntityWithHeaderToken;
import static com.vwits.asid.utility.constants.ASIDAppConstants.REPAIR_INFO_PATH;
import static com.vwits.asid.utility.testutils.TokenUtil.getToken;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.INVALID_ASID;
import static com.vwits.asid.utility.testutils.constant.ASIDTestConstants.VALID_ASID;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RepairManualSystemTests {
    private static final String INVALID_SCOPE = "3";
    private static final String INVALID_VIN = "INVALIDVIN";
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    private IdKitClientCredential idKitCredential = new IdKitClientCredential();
    private String serviceURL = SubjectUrlProvider.provideSITSubjectUrl("repair-manual-service", false);
    private RestTemplate template = new RestTemplate();
    private MultiValueMap<String, String> testData;

    private String vin = "WVWZZZ3HZHE700166";
    private String unHandledVin = "WVWZZZ3HZJE501052";

    @Autowired
    private EnvironmentProvider environmentProvider;
    private String dealerid = "DEU05025V";

    @Before
    public void setUp() {
        testData = new LinkedMultiValueMap<>();
        testData.add("lang", "de");
        testData.add("country", "DE");
        testData.add("brand", "V");
        testData.add("appname", "etka");
        testData.add("vin", vin);
        testData.add("dealerid", dealerid);
        template = new RestTemplate();
    }

    @Test
    public void getRepairManualInfo_itShouldReturn200WithAppropriateReason_ifCalledWithCorrectTokenAndInValidASID() {
        testData.add("asid", INVALID_ASID);
        testData.set("scope", "1");
        String validToken = getToken(template, idKitCredential);

        ResponseEntity<RepairManualDTO> response = getRepairManualInformation(validToken, testData);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void getRepairManualInfo_itShouldGet200_ifCalledWithInCorrectLanguage() {
        testData.set("asid", VALID_ASID);
        testData.set("lang", "ab-AB");
        String validToken = getToken(template, idKitCredential);

        ResponseEntity<RepairManualDTO> response = getRepairManualInformation(validToken, testData);

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    @Test
    public void getRepairManualInfo_itShouldGet200_ifCalledWithInCorrectVIN() {
        testData.set("asid", VALID_ASID);
        testData.set("vin", INVALID_VIN);
        String validToken = getToken(template, idKitCredential);

        ResponseEntity<RepairManualDTO> response = getRepairManualInformation(validToken, testData);

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    @Test
    public void getRepairManualInfo_itShouldReturn400_ifCalledWithInCorrectScopeAndValidASID() {
        testData.add("asid", INVALID_ASID);
        testData.set("scope", INVALID_SCOPE);
        String validToken = getToken(template, idKitCredential);

        thrown.expect(HttpClientErrorException.BadRequest.class);
        thrown.expect(hasProperty("statusCode", is(HttpStatus.BAD_REQUEST)));
        thrown.expect(hasProperty("statusText", containsString("Bad Request")));

        ResponseEntity<RepairManualDTO> response = getRepairManualInformation(validToken, testData);
    }

    @Test
    public void getRepairManualInfo_itShouldReturn200AndInfoLevelValueShouldBe1_ifCalledWithScopeAndValidASID() {
        testData.add("asid", VALID_ASID);
        testData.set("scope", "1");
        String validToken = getToken(template, idKitCredential);

        ResponseEntity<RepairManualDTO> response = getRepairManualInformation(validToken, testData);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    @Test
    public void getRepairManualInfo_itShouldGet401_ifCalledWithIncorrectToken() {
        testData.add("asid", VALID_ASID);
        testData.set("scope", "1");
        String invalidToken = "dummy token";

        thrown.expect(HttpClientErrorException.class);
        thrown.expectMessage(containsString("401 Unauthorized"));
        thrown.expect(hasProperty("statusCode", is(HttpStatus.UNAUTHORIZED)));
        thrown.expect(hasProperty("statusText", containsString("Unauthorized")));

        getRepairManualInformation(invalidToken, testData);

    }

    @Test
    public void getRepairManualInfo_itShouldReturn403_whenDealerIdIsBlacklisted() {
        String authToken = getToken(template, idKitCredential);
        testData.add("asid", VALID_ASID);
        testData.set("scope", "1");
        testData.set("dealerid", "RLBL001");

        thrown.expect(HttpClientErrorException.class);
        thrown.expectMessage(containsString("403 Forbidden"));
        thrown.expect(hasProperty("statusCode", is(HttpStatus.FORBIDDEN)));
        thrown.expect(hasProperty("statusText", containsString("Forbidden")));

        getRepairManualInformation(authToken, testData);
    }

    @Test
    public void getRepairManualInfo_itShouldGet200_ifCalledWithUnAuthorisedDealerId() {
        testData.set("asid", VALID_ASID);
        testData.set("dealerid", "DEU78221A");
        String validToken = getToken(template, idKitCredential);

        ResponseEntity<RepairManualDTO> response = getRepairManualInformation(validToken, testData);

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    @Test
    public void getRepairManualInfo_itShouldReturn200_whenUnHandledVinIsPassed() {

        testData.add("asid", VALID_ASID);
        testData.set("vin", unHandledVin);
        String validToken = getToken(template, idKitCredential);

        ResponseEntity<RepairManualDTO> response = getRepairManualInformation(validToken, testData);
        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
    }

    private ResponseEntity<RepairManualDTO> getRepairManualInformation(String authToken, MultiValueMap<String, String> parameters) {
        UriComponents uriComponents = UriComponentsBuilder.newInstance()
                .path(REPAIR_INFO_PATH).queryParams(parameters).build();
        HttpEntity<String> request = getHttpEntityWithHeaderToken(authToken);
        return template.exchange(serviceURL + uriComponents.toUriString(), HttpMethod.GET, request, RepairManualDTO.class);
    }

    @Test
    public void testSwaggerUrl() {
        if (serviceURL.contains("acceptance")) {
            String url = serviceURL + "/v2/api-docs?group=Swagger Specification for Repair Manual Service";
            ResponseEntity<String> forEntity = template.getForEntity(url, String.class);
            assertEquals(HttpStatus.OK.value(), forEntity.getStatusCode().value());
        } else {
            assertTrue("Test case is not applicable for this environment, hence skipping it", true);
        }
    }

}
