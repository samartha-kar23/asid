# Thoughts on scaling
## General
```cf apps``` shows the number of running (and max) instances,  current memory and disk quota (in this order).
```cf app <appname>``` gives more detail, in the last section it will tell you the actual disk and memory consumption of the app.

From what we had configured it was all default values (1G Mem and 1G Disk), which left us with a 98% quota and not having more than 1 instance of every service running. So there was a need to scale things down.

## Scaling
Vertical scaling can be done by adjusting the memory and disk quota of each app. Think of a house that you build another level upon (therefore vertical).
```cf scale <appname> -k ddd``` Would set the disk space of every container to ddd where ddd means an integer followed by G,M,K (e.g. 256M)
```cf scale <appname> -m ddd``` Would set the memory space of every container to ddd where ddd means an integer followed by G,M,K (e.g. 256M) (read section "caveats")
Scaling horzontally means you just bring up another instance of your service that would do the same work in parallel. Think of build a second house of the same size (therefore horizontal).
```cf scale <appname> -i d``` would tell cf how many running instances it should provide. d is an integer that defines the number of instances, it should never be less then 2. We can if we are really desperate go with 1 on acceptance. I would not recommend to have one on dev as well, because then we will not see if we get some problems with being stateless while developing.

## Caveats
Our apps will not start when defining less then 1G of memory. This is because of the way CF computes the used memory. This is indicated by a logline like

`2018-08-09T11:57:30.65+0530 [APP/PROC/WEB/0] ERR Cannot calculate JVM memory configuration: There is insufficient memory remaining for heap. Memory available for allocation 512M is less than allocated memory 620522K (-XX:ReservedCodeCacheSize=240M, -XX:MaxDirectMemorySize=10M, -XX:MaxMetaspaceSize=108522K, -Xss1M * 250 threads)`
You can override these settings.
Read also: [https://community.pivotal.io/s/article/Insufficient-Memory-when-Using-Java-Buildpack-Version-40-and-Above]

To fix this we can override the computed memory settings by specifying Java options on the environment.
```cf set-env data-importer-service JAVA_OPTS -Xss256k``` will set stack size: so the amount of data that can be pushed to the stack for every thread will be smaller. This can have impact on heavily recursive apps. You will witness StackOverflowExceptions if defined too small.
```cf set-env data-importer-service JAVA_OPTS -XX:ReservedCodeCacheSize=140M\ -Xss256k``` ReservedCodeCacheSize (and additionally the stack size) is set to 140M. In respect to Java8 in defaults to 240M which is imho quite heavy (in Java 7 it was 48M). Read also [https://stackoverflow.com/questions/7513185/what-are-reservedcodecachesize-and-initialcodecachesize] for the errors you should see when defined too small.
After a restage that memory consumption shrinks to a quota of 256M

If you witness one of the errors described:
- Either toy around with the numbers in Xss and XX:ReservedCacheCodeSize
- or switch back to the default by
```cf unset-env data-importer-service JAVA_OPTS```
then you have to scale annew:
```cf scale <appname> -m 1G```
and then you can restage:
cf restage data-importer-service
Every memory error that is occurring then is your own, you can keep it :)

## Script support
There is a script to setup scaling:
scaling.sh %1 %2 %3 will assume you are logged in, that it will introduce settings for the service defined as %1. It will set %2 as DiskQuota and %3 as Memory quota. If your App fails to start: Define JAVA_OPTS as described.
